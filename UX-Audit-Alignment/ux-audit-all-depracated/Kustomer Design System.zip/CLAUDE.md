# Kustomer Design System — Project Instructions

This file is loaded automatically for every chat in this project. It defines the rules every design and prototype must follow.

---

## 🔒 Lock Files (Zero-Tolerance Enforcement)

Before producing any output, read and apply these in order:

1. **`docs/design-system-lock.md`** — top-level governance: fonts, logo, colors, components, asset handling
2. **`docs/typography-lock.md`** — typography is a governed system, not a creative area
3. **`docs/layout-lock.md`** — every page uses the fixed three-column structure
4. **`design.md`** — consolidated reference (tokens, scales, patterns)

These are **non-negotiable**. Do not improvise, approximate, or override for aesthetic reasons.

---

## 📐 Always-Apply Design Rules

These files apply to every design, every chat. Read them alongside the locks:

| File | Purpose |
|---|---|
| **`principles.md`** | Foundational design mindset (clarity, hierarchy, predictability) |
| **`rules.md`** | Non-negotiable design rules (1 primary action, required states, fail conditions) |
| **`patterns.md`** | Approved patterns (dashboard, form, table, AI surface, empty state) |
| **`outputs.md`** | Output format rules (design generation, review, UX specs, AI feature design) |
| **`ai-design.md`** | AI surface design — automation-first thinking, trust architecture, state coverage, copy rules |

### UX Copy Reference (`docs/ux-copy/`)

Reference material for writing or reviewing UX copy. Auto-loaded for copy work; consult when relevant.

- `training-guide.md` — master UX copy reference
- `error-handling.md` — error copy taxonomy + rules
- `risk-analysis.md` — risk framework + levels
- `lifecycle-phases.md` — agentic lifecycle copy
- `decision-vs-information.md` — decision vs info copy
- `preview-testing-eval.md` — preview/shadow mode rules
- `trust-best-practices.md` — trust checklist
- `conversion-best-practices.md` — conversion principles
- `engagement-best-practices.md` — engagement principles
- `ai-agent-heuristics.md` — AI agent heuristics

---

## Core Rules

### Typography
- Use **Inter** only for product UI (Fraunces only for marketing display)
- Use ONLY `--text-*` and `--leading-*` tokens — never hardcode sizes or weights
- Heading hierarchy is semantic: H1 > H2 > H3 > H4
- H1 appears once per page (page title only)
- Never invent new sizes, weights, or intermediate heading levels
- Never use legacy `--fs-*` tokens in new product UI
- See `docs/typography-lock.md` for the full token tables and validation checklist

### Layout
- Every page uses the fixed structure: **left sidebar nav · main content · optional right panel**
- App background `#F7F8FA`, surfaces `#FFFFFF`, subtle gray borders only
- No marketing-style layouts, hero spacing, or oversized whitespace
- No floating or overlapping panels
- No decorative gradients or visual effects outside the token system
- See `docs/layout-lock.md` for full rules

### Color
- Use only tokens from `colors_and_type.css` — never approximate hex values
- Full ramps available: Gray, Blue, Purple, Red, Yellow, Green, Teal (steps 10–130)

### Components
- Prefer `komponentsV2/` over native HTML or legacy `komponents/`
- Compose from existing primitives; do not invent new patterns

### Assets
- Reference logo and icon files exactly as-is — never recreate, simplify, or redraw

---

## Available Skills

Custom prompt-driven skills live in `skills/`. To run one, ask me to "run the [skill name] skill" and I'll load and apply it.

| Skill | File | Purpose |
|---|---|---|
| **UX Audit** | `skills/ux-audit.md` | Comprehensive UX architecture audit — flows, missing states, edge cases, accessibility, priority matrix |
| **Design Audit** | `skills/design-audit.md` | 15-point design quality audit with PASS / FAIL verdict |
| **IA Design** | `skills/ia-design.md` | Information architecture & UX design for a product/feature — Notion + Linear inspired, agentic-aware |
| **Tour Copy** | `skills/tour-copy.md` | Write or audit UX copy for site tours, feature tours, onboarding walkthroughs, coach marks, and hotspots |
| **Email Copy** | `skills/email-copy.md` | Generate transactional, lifecycle, product update, and marketing emails — persona-aware, AI-trust focused |
| **Trial Lifecycle Emails** | `skills/trial-lifecycle-emails.md` | Free trial email sequence (5 stages) tuned for agentic software — Welcome → First Win → Depth → Urgency → Post-Trial |
| **Senior UX Writer Review** | `skills/senior-ux-writer-review.md` | 10-point staff-level rubric for reviewing UX copy with ship-ready / needs revision / blocking verdict |
| **Quick Design Revision (Obi-Wan)** | `skills/quick-design-revision-obiwan.md` | Fast screenshot-based design revision — triggered by "help me, Obi-Wan, you're my only hope" |

---

## When in doubt
1. Reuse the closest existing token — never invent
2. Check the relevant lock file
3. Ask before adding new patterns, sections, or layouts
