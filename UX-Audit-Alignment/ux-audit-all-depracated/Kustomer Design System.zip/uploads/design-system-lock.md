# 🔒 Design System Lock (Strict Enforcement)

This file defines **non-negotiable rules** for design system fidelity.
No interpretation, approximation, or creativity is allowed at the brand/system layer.

---

## 1. Fonts (Non-Negotiable)
- ONLY use approved fonts:
  - Primary: [INSERT FONT NAME]
  - Secondary: [INSERT FONT NAME]
- Do NOT substitute fonts under any circumstance
- Do NOT infer or approximate fonts

❌ Fail if:
- Any other font is used

---

## 2. Logo Usage (Critical)
- ONLY use provided logo asset exactly as-is
- Do NOT:
  - recreate
  - simplify
  - reinterpret SVG paths
  - generate a new logo
- Always reference the original file directly

❌ Fail if:
- Logo is modified in any way
- Logo is re-rendered instead of reused

---

## 3. Colors (Token-Based Only)
- ONLY use defined color tokens
- Do NOT:
  - approximate hex values
  - generate new shades
  - adjust opacity arbitrarily

❌ Fail if:
- Any color is not from the system

---

## 4. Components
- ONLY use existing components from the system
- Do NOT invent new components unless explicitly allowed

If missing:
- Compose from existing primitives
- Do NOT create net-new patterns

---

## 5. Spacing / Typography
- Must follow defined scale (no arbitrary values)
- No “close enough” sizing

---

## 6. Asset Handling Rule
- All provided assets (SVG, icons, logos) must be:
  → referenced, not interpreted

Meaning:
- Use exact files (e.g., <img src="logo.svg">)
- Do NOT rewrite SVG code
- Do NOT simplify or redraw assets

---

## 7. Zero-Tolerance Policy

A design FAILS immediately if:
- Fonts are incorrect
- Logo is modified or regenerated
- Colors are off-token
- Components are invented

---

## 8. Enforcement

Before returning ANY output:
- Validate against this file
- If any violation exists → fix before output
- Do NOT return partially compliant designs
