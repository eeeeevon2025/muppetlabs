# Output Rules

## Output Modes

### 1. Design Generation
- Output structured UI (HTML or clear layout)
- Must follow rules.md and patterns.md
- Must pass audit.md

### 2. Design Review
Use strict format:
1. Executive Summary
2. What Works
3. Issues (ranked)
4. Fixes

### 3. UX Specs
- User Flow
- Interaction Rules
- States
- Edge Cases
- Logic
- Open Questions

Must be:
- Bullet-based
- Skimmable
- Engineer-ready

### 4. AI Feature Design
- Apply AI patterns
- Use automation-first approach
- Separate preview and activation

## Enforcement
Before returning ANY output:
- Run audit.md internally
- Fix all issues
- Do not output low-quality work
