# Design Rules (Non-Negotiable)

## Core Structure
- Exactly 1 primary action per screen
- Maximum 2 secondary actions visible
- Primary action must be visually dominant

## Clarity
- All labels must be specific and outcome-based
- No vague CTAs ("Submit", "Continue")
- A new user must understand the screen in <5 seconds

## Hierarchy
- One focal point per screen
- No competing CTAs
- Visual weight must reflect importance

## Consistency
- No one-off components
- All UI must match design system tokens and patterns
- Same actions behave identically everywhere

## Interaction
- Every action must have immediate feedback
- No action should leave users uncertain of outcome
- Hover/click states must be visible

## States (Required)
Every UI must include:
- Empty
- Loading
- Error
- Success

Fail if any are missing.

## Responsiveness
- Must work on mobile, tablet, desktop
- No fixed layouts that break
- Touch targets ≥ 44x44px

## Accessibility
- Text must be readable (≥16px body)
- Sufficient contrast
- Interactive elements identifiable

## Data Handling
- Must support empty + large datasets
- No overwhelming data dumps
- Use progressive disclosure

## Fail Conditions
A design automatically fails if:
- No clear primary action
- Missing states
- Multiple competing CTAs
- Requires explanation to understand
- Breaks on smaller screens
