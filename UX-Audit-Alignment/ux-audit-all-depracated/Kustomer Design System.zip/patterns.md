# Design Patterns

## Dashboard Pattern
- Top: System status (most important)
- Middle: Key metrics (3–5 max)
- Bottom: Detailed data / controls

Fail if:
- More than one primary question is answered
- Metrics overwhelm the user

---

## Form Pattern
Structure:
1. Purpose (what this does)
2. Inputs (minimal fields)
3. Defaults (pre-filled where possible)
4. Action (single primary CTA)

Rules:
- Minimize inputs
- Use autofill wherever possible
- Group logically

---

## Table Pattern
- Default: summarized view
- Expand: detailed data
- Must include:
  - Sorting
  - Filtering (if dataset >10 items)

Fail if:
- Raw data overload
- No way to refine results

---

## AI Surface Pattern

### Types
1. Ambient (no UI)
2. Suggestive (inline suggestions)
3. Configurable (rules + setup)
4. Agentic (approval + monitoring)

### Rules
- Default to automation
- UI is fallback, not primary
- Always show scope before execution
- Always allow override

Fail if:
- User does work AI could do
- No preview before activation
- Scope is unclear

---

## Empty State Pattern
Must include:
- What will appear
- When it appears
- One clear next step

Avoid:
- “No data yet”
