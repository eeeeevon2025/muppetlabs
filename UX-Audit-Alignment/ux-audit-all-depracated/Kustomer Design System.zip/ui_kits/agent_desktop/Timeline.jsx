// Conversation pane — light, with handoff summary card matching reference
const Timeline = ({ onSend }) => {
  return (
    <div style={{
      flex: 1, display: "flex", flexDirection: "column",
      background: "#fff", minWidth: 0,
    }}>
      {/* Top bar */}
      <div style={{
        height: 44, padding: "0 16px",
        borderBottom: "1px solid var(--gray-30)",
        display: "flex", alignItems: "center", gap: 10, flexShrink: 0,
      }}>
        <KAvatar name="Pink Bike" size={22} color="var(--red-50)"/>
        <span style={{ fontSize: 13, fontWeight: 600, color: "var(--gray-120)" }}>Pink Bike</span>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 8 }}>
          {/* Reaction summary chips */}
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 4,
            padding: "2px 8px", borderRadius: 999,
            background: "var(--red-15)", fontSize: 11, color: "var(--gray-115)",
          }}>😡 1</span>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 4,
            padding: "2px 8px", borderRadius: 999,
            background: "var(--yellow-20)", fontSize: 11, color: "var(--gray-115)",
          }}>😐 0</span>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 4,
            padding: "2px 8px", borderRadius: 999,
            background: "var(--green-15)", fontSize: 11, color: "var(--gray-115)",
          }}>✓ 0</span>
          <span style={{ width: 1, height: 16, background: "var(--gray-30)", margin: "0 4px" }}/>
          <button style={{ background: "transparent", border: 0, cursor: "pointer", padding: 4, color: "var(--gray-95)" }}><Icon name="user" size={16}/></button>
          <button style={{ background: "transparent", border: 0, cursor: "pointer", padding: 4, color: "var(--gray-95)" }}><Icon name="lock" size={16}/></button>
          <button style={{ background: "transparent", border: 0, cursor: "pointer", padding: 4, color: "var(--gray-95)" }}><Icon name="more" size={16}/></button>
          <button style={{ background: "transparent", border: 0, cursor: "pointer", padding: 4, color: "var(--gray-95)" }}><Icon name="sidePanel" size={16}/></button>
        </div>
      </div>

      {/* Filter row */}
      <div style={{
        padding: "8px 16px", borderBottom: "1px solid var(--gray-30)",
        display: "flex", alignItems: "center", gap: 16, justifyContent: "center",
        fontSize: 12, color: "var(--gray-95)",
      }}>
        {["All", "Any Brand", "Any Status", "Any Date", "Any Attributes"].map((f, i) => (
          <button key={f} style={{
            background: "transparent", border: 0, cursor: "pointer", padding: "2px 4px",
            fontSize: 12, color: "var(--gray-100)", display: "inline-flex", alignItems: "center", gap: 4,
            fontFamily: "var(--font-sans)",
          }}>
            {f} <Icon name="chevronDown" size={11}/>
          </button>
        ))}
      </div>

      {/* Conversation body */}
      <div style={{
        flex: 1, overflow: "auto", padding: "16px 16px 12px",
        display: "flex", flexDirection: "column", gap: 12,
      }}>
        {/* Add note button left */}
        <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
          <button title="Add" style={{
            width: 24, height: 24, borderRadius: 6, border: "1px solid var(--gray-30)",
            background: "#fff", cursor: "pointer", color: "var(--gray-95)",
            display: "flex", alignItems: "center", justifyContent: "center",
            flexShrink: 0,
          }}><Icon name="plus" size={12}/></button>

          {/* Conversation card */}
          <div style={{
            flex: 1, border: "1px solid var(--gray-30)", borderRadius: 10,
            background: "#fff", overflow: "hidden",
          }}>
            {/* Card header */}
            <div style={{
              padding: "10px 14px", borderBottom: "1px solid var(--gray-30)",
              display: "flex", alignItems: "center", gap: 10,
            }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "var(--gray-120)" }}>
                  Hey there I need some help with an order that I placed a few days ago.
                </div>
                <div style={{ fontSize: 11.5, color: "var(--gray-95)", marginTop: 2, display: "flex", alignItems: "center", gap: 6 }}>
                  <Icon name="chevronDown" size={11}/>
                  Inquired about recent order status and assistance needed…
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <button style={{ width: 26, height: 26, borderRadius: 6, border: 0, background: "transparent", color: "var(--gray-95)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="clock" size={14}/></button>
                <button style={{ width: 26, height: 26, borderRadius: 6, border: 0, background: "transparent", color: "var(--gray-95)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="check" size={14}/></button>
                <button style={{ width: 26, height: 26, borderRadius: 6, border: 0, background: "transparent", color: "var(--gray-95)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="more" size={14}/></button>
                <span style={{
                  display: "inline-flex", alignItems: "center", gap: 4,
                  padding: "3px 10px", borderRadius: 999,
                  background: "var(--red-15)", color: "var(--red-90)",
                  fontSize: 11, fontWeight: 600,
                }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--red-70)" }}/>
                  Open
                </span>
              </div>
            </div>

            {/* Tag row */}
            <div style={{
              padding: "8px 14px", display: "flex", alignItems: "center", gap: 8,
              borderBottom: "1px solid var(--gray-30)",
            }}>
              <span style={{ fontSize: 11, color: "var(--gray-90)" }}>6 days ago</span>
              <span style={{ width: 1, height: 12, background: "var(--gray-40)" }}/>
              <SoftPill bg="var(--green-15)" fg="var(--green-90)">😊 Satisfied</SoftPill>
              <SoftPill bg="var(--blue-15)" fg="var(--blue-90)" closable>New</SoftPill>
              <SoftPill bg="#FCE4EC" fg="#AD2D5B" closable>Update Info</SoftPill>
              <SoftPill bg="#FCE4EC" fg="#AD2D5B" plus>Add Tag</SoftPill>
            </div>

            {/* Messages */}
            <div style={{ padding: "14px 14px 16px", display: "flex", flexDirection: "column", gap: 14 }}>
              {/* Inbound bot/system message */}
              <div style={{
                background: "#F3F2FF", borderRadius: 10, padding: "10px 14px",
                fontSize: 12.5, color: "var(--gray-115)", lineHeight: 1.5,
                alignSelf: "stretch",
              }}>
                I'm unable to continue with the verification process at this time, so I cannot transfer you to a human agent or assist further with your request. If you have any general questions or need assistance that doesn't require account access, please let me know — I'm here to help!
              </div>
              <div style={{
                fontSize: 11, color: "var(--gray-90)",
                display: "flex", alignItems: "center", gap: 6, justifyContent: "flex-end",
              }}>
                <Icon name="clock" size={11}/> Apr 21, 1:17:18 PM
              </div>
              <div style={{ fontSize: 11, color: "var(--gray-90)", textAlign: "right", marginTop: -8 }}>
                Shaun self-assigned · Apr 21, 1:17:17 PM
              </div>
              <div style={{ fontSize: 11, color: "var(--gray-90)", textAlign: "right", marginTop: -8 }}>
                Handoff Summary
              </div>

              {/* Handoff Summary card */}
              <HandoffSummary/>
            </div>

            {/* Footer with Reply / Note + Show more */}
            <div style={{
              padding: "8px 14px", borderTop: "1px solid var(--gray-30)",
              display: "flex", alignItems: "center", gap: 14,
            }}>
              <button style={{
                background: "transparent", border: 0, cursor: "pointer", padding: "4px 0",
                fontSize: 12.5, fontWeight: 600, color: "var(--gray-115)",
                display: "inline-flex", alignItems: "center", gap: 5,
              }}>
                <Icon name="reply" size={14}/> Reply
              </button>
              <button style={{
                background: "transparent", border: 0, cursor: "pointer", padding: "4px 0",
                fontSize: 12.5, fontWeight: 500, color: "var(--gray-95)",
                display: "inline-flex", alignItems: "center", gap: 5,
              }}>
                <Icon name="note" size={14}/> Note
              </button>
              <button style={{
                marginLeft: "auto", background: "transparent", border: 0, cursor: "pointer",
                fontSize: 12, color: "var(--blue-70)", fontWeight: 500,
              }}>Show more</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const SoftPill = ({ children, bg, fg, closable, plus }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: 4,
    padding: "2px 8px", borderRadius: 999,
    background: bg, color: fg,
    fontSize: 11, fontWeight: 500,
  }}>
    {plus && <span style={{ fontSize: 11, fontWeight: 700 }}>+</span>}
    {children}
    {closable && <span style={{ fontSize: 10, opacity: 0.7, cursor: "pointer", marginLeft: 2 }}>×</span>}
  </span>
);

const HandoffSummary = () => (
  <div style={{
    background: "#FAF8FF", border: "1px solid #E8DFFF",
    borderLeft: "3px solid var(--purple-65)",
    borderRadius: 8, padding: "12px 14px",
    display: "flex", flexDirection: "column", gap: 8,
  }}>
    <div style={{
      display: "flex", alignItems: "center", gap: 6,
      fontSize: 12, fontWeight: 600, color: "var(--purple-95)",
    }}>
      <Icon name="sparkles" size={13} color="var(--purple-70)"/>
      Handoff Summary
    </div>
    <ul style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: "var(--gray-115)", lineHeight: 1.55 }}>
      <li>Customer requested assistance with an order placed a few days ago</li>
      <li>Unable to proceed with verification process and therefore unable to access or modify order information</li>
      <li>Customer requested transfer to a human agent which could not be fulfilled due to verification issues</li>
      <li>No notable action taken</li>
    </ul>
    <div style={{ marginTop: 4 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: "var(--gray-115)" }}>Follow Up Needed</div>
      <div style={{ fontSize: 12, color: "var(--gray-100)" }}>Follow-ups complete.</div>
    </div>
    <div>
      <div style={{ fontSize: 12, fontWeight: 600, color: "var(--gray-115)" }}>Relevant Details</div>
      <div style={{ fontSize: 12, color: "var(--gray-100)" }}>
        Priority: 3 - The priority level of the customer interaction.
      </div>
    </div>
  </div>
);

Object.assign(window, { Timeline, SoftPill, HandoffSummary });
