# Kustomer Agent Desktop — UI Kit

Hi-fi recreation of the Kustomer agent workspace. The agent desktop is where CX reps spend most of their day: a three-pane layout with a left nav rail, a center Timeline / inbox, and a right customer-context panel featuring AI Copilot.

## Structure
- `index.html` — interactive click-thru demo. Sign in, pick a conversation, send a reply, watch AI Copilot suggest something.
- `AppShell.jsx` — three-pane layout
- `Sidebar.jsx` — left rail (logo, global search, inbox nav, queues)
- `InboxList.jsx` — conversation list (center pane when no convo is selected)
- `Timeline.jsx` — conversation timeline (center pane when a convo is open)
- `Composer.jsx` — reply composer with channel switcher
- `CustomerPanel.jsx` — right pane (customer card, orders, attributes)
- `AICopilot.jsx` — periwinkle AI assist panel with suggested replies + summarize
- `primitives.jsx` — Button, Badge, Avatar, Pill, Icon

## Notes
Designed against the publicly observable Kustomer visual language (Cream canvas, Ink nav, Yellow primary accents, Periwinkle reserved for AI surfaces). Real product color tokens should be swapped in once verified against internal Figma.
