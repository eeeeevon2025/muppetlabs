// Right context panel — Copilot/Insights/Signals tabs, light styling
const CustomerPanel = () => {
  const [tab, setTab] = React.useState("insights");
  return (
    <aside style={{
      width: 320, background: "#fff", borderLeft: "1px solid var(--gray-30)",
      display: "flex", flexDirection: "column", flexShrink: 0,
      fontFamily: "var(--font-sans)",
    }}>
      {/* Tabs */}
      <div style={{
        height: 44, padding: "0 14px",
        display: "flex", alignItems: "center", gap: 4,
        borderBottom: "1px solid var(--gray-30)",
      }}>
        {[
          { id: "copilot",  label: "Copilot",  icon: "sparkles" },
          { id: "insights", label: "Insights", icon: null },
          { id: "signals",  label: "Signals",  icon: "signals" },
        ].map(t => {
          const isActive = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              padding: "5px 11px", borderRadius: 999, border: 0, cursor: "pointer",
              fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600,
              background: isActive ? "var(--gray-120)" : "transparent",
              color: isActive ? "#fff" : "var(--gray-100)",
              display: "inline-flex", alignItems: "center", gap: 5,
            }}>
              {t.icon && <Icon name={t.icon} size={12}/>}
              {t.label}
            </button>
          );
        })}
        <button title="Close" style={{
          marginLeft: "auto", width: 24, height: 24, borderRadius: 6, border: 0,
          background: "transparent", cursor: "pointer", color: "var(--gray-95)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}><Icon name="close" size={14}/></button>
      </div>

      <div style={{ flex: 1, overflow: "auto" }}>
        {/* Conversation insights */}
        <Section title="Conversation insights">
          <div style={{
            padding: "10px 14px", border: "1px solid var(--gray-30)",
            borderRadius: 8, margin: "0 14px",
            display: "flex", flexDirection: "column", gap: 4,
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
              <div style={{ flex: 1, fontSize: 12.5, fontWeight: 600, color: "var(--gray-120)", lineHeight: 1.4 }}>
                Hey there I need some help with an order that I placed a few d…
              </div>
              <button style={{ background: "transparent", border: 0, cursor: "pointer", padding: 2, color: "var(--gray-95)" }}><Icon name="edit" size={12}/></button>
            </div>
            <div style={{ fontSize: 11, color: "var(--gray-90)" }}>Conversation Updated 6 Days Ago</div>
            <button style={{ background: "transparent", border: 0, cursor: "pointer", color: "var(--blue-70)", fontSize: 12, fontWeight: 500, padding: 0, alignSelf: "flex-start", marginTop: 2 }}>
              Show More
            </button>
          </div>
        </Section>

        <CollapsibleRow label="Conversation Sentiment"/>

        {/* Shopify */}
        <Section
          title="Shopify"
          right={
            <>
              <button style={{ background: "transparent", border: 0, cursor: "pointer", padding: 2, color: "var(--gray-95)" }}><Icon name="edit" size={12}/></button>
              <button style={{ background: "transparent", border: 0, cursor: "pointer", padding: 2, color: "var(--gray-95)" }}><Icon name="chevronUp" size={12}/></button>
            </>
          }
        >
          <div style={{ padding: "0 14px 4px" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              border: "1px solid var(--gray-30)", borderRadius: 8,
              padding: "7px 10px", marginBottom: 14,
            }}>
              <Icon name="search" size={13} color="var(--gray-90)"/>
              <span style={{ fontSize: 12, color: "var(--gray-90)", flex: 1 }}>
                Search for an order (e.g., variant, SKU)
              </span>
              <Icon name="search" size={13} color="var(--gray-95)"/>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: "var(--gray-120)" }}>Orders</span>
              <span style={{ fontSize: 11, color: "var(--gray-90)" }}>0 total</span>
            </div>
            <EmptyOrders/>
          </div>
        </Section>

        <Section title="Drafts">
          <div style={{ padding: "0 14px 18px", fontSize: 12, color: "var(--gray-95)" }}>
            There are no draft orders for this customer.
          </div>
        </Section>
      </div>
    </aside>
  );
};

const Section = ({ title, right, children }) => (
  <div style={{ padding: "12px 0", borderBottom: "1px solid var(--gray-30)" }}>
    <div style={{
      display: "flex", alignItems: "center", gap: 6,
      padding: "0 14px 8px",
    }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: "var(--gray-120)", flex: 1 }}>{title}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 4 }}>{right}</div>
    </div>
    {children}
  </div>
);

const CollapsibleRow = ({ label }) => (
  <button style={{
    width: "100%", padding: "12px 14px",
    display: "flex", alignItems: "center", gap: 8,
    background: "transparent", border: 0, borderBottom: "1px solid var(--gray-30)",
    cursor: "pointer", textAlign: "left", color: "var(--gray-120)",
    fontSize: 12, fontWeight: 600, fontFamily: "var(--font-sans)",
  }}>
    <span style={{ flex: 1 }}>{label}</span>
    <Icon name="chevronDown" size={12} color="var(--gray-95)"/>
  </button>
);

const EmptyOrders = () => (
  <div style={{
    display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
    padding: "10px 0 14px",
  }}>
    <svg viewBox="0 0 120 70" width="120" height="70" fill="none">
      <rect x="14" y="14" width="92" height="52" rx="6" fill="#F4F2FF" stroke="#D9D2F5" strokeWidth="1"/>
      <rect x="22" y="22" width="76" height="6" rx="3" fill="#E0DAF5"/>
      <path d="M22 56 L42 38 L58 50 L78 30 L98 56 Z" fill="#D9D2F5" opacity="0.6"/>
      <circle cx="86" cy="30" r="4" fill="#B9B0E8"/>
    </svg>
    <div style={{ fontSize: 11.5, color: "var(--gray-95)", textAlign: "center" }}>
      This customer doesn't have any orders yet.
    </div>
  </div>
);

Object.assign(window, { CustomerPanel, Section, CollapsibleRow, EmptyOrders });
