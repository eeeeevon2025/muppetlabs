// Sidebar — narrow icon rail (matches Kustomer light-mode reference)
const Sidebar = ({ active, onNav }) => {
  const top = [
    { id: "home",      icon: "home" },
    { id: "inbox",     icon: "inbox", count: 4, activeColor: true },
    { id: "lists",     icon: "lists" },
    { id: "reports",   icon: "barChart" },
    { id: "ai",        icon: "sparkles" },
    { id: "apps",      icon: "grid", count: 2 },
    { id: "settings",  icon: "settings" },
  ];
  const bottom = [
    { id: "search",    icon: "search" },
    { id: "kb",        icon: "book" },
    { id: "notifs",    icon: "bell" },
    { id: "help",      icon: "help" },
  ];

  const Item = ({ it }) => {
    const isActive = active === it.id;
    return (
      <button onClick={() => onNav && onNav(it.id)} title={it.id} style={{
        position: "relative",
        width: 36, height: 36, borderRadius: 8, border: 0,
        background: isActive ? "var(--gray-25)" : "transparent",
        cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
        color: isActive ? "var(--gray-120)" : "var(--gray-95)",
      }}>
        <Icon name={it.icon} size={18} strokeWidth={1.7}/>
        {it.count != null && (
          <span style={{
            position: "absolute", top: -2, right: -2,
            minWidth: 16, height: 16, padding: "0 4px",
            borderRadius: 999, background: "var(--blue-70)", color: "#fff",
            fontSize: 10, fontWeight: 700,
            display: "flex", alignItems: "center", justifyContent: "center",
            border: "2px solid #fff",
          }}>{it.count}</span>
        )}
      </button>
    );
  };

  return (
    <aside style={{
      width: 56, background: "#fff", borderRight: "1px solid var(--gray-30)",
      display: "flex", flexDirection: "column", alignItems: "center",
      padding: "10px 0", flexShrink: 0,
    }}>
      {/* Yellow K logo squircle */}
      <div style={{
        width: 32, height: 32, borderRadius: 8,
        background: "var(--yellow-60)", display: "flex", alignItems: "center", justifyContent: "center",
        marginBottom: 14,
      }}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--gray-120)" strokeWidth="2.4" strokeLinecap="round">
          <path d="M7 9 q2 -3 4 0"/><path d="M13 9 q2 -3 4 0"/>
          <path d="M8 14 q4 5 8 0"/>
        </svg>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 4, flex: 1 }}>
        {top.map(it => <Item key={it.id} it={it}/>)}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {bottom.map(it => <Item key={it.id} it={it}/>)}
        <div style={{ marginTop: 6 }}>
          <KAvatar name="V" size={28} color="var(--gray-120)"/>
        </div>
      </div>
    </aside>
  );
};

Object.assign(window, { Sidebar });
