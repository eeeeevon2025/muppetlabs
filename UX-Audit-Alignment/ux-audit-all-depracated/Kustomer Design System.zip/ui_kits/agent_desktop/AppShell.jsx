// Main app shell + interactive state
const AppShell = () => {
  const [selected, setSelected] = React.useState("c1");
  const [active, setActive] = React.useState("inbox");
  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden", background: "var(--gray-15)" }}>
      <Sidebar active={active} onNav={setActive}/>
      <InboxList selected={selected} onSelect={setSelected}/>
      <Timeline onSend={() => {}}/>
      <CustomerPanel/>
    </div>
  );
};

Object.assign(window, { AppShell });
