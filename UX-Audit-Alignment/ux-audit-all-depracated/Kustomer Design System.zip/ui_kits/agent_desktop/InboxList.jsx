// "Currently viewing" inbox panel — light, conversation cards w/ channel dots
const SAMPLE_CONVERSATIONS = [
  { id: "c0", name: "Automation Test Customer Shopt…",
    preview: "Shoptalk: I've checked the eligibili…", date: "4/9/26",
    channel: "chat", initials: "AA", color: "var(--gray-95)" },
  { id: "c1", name: "Black Anchor",
    preview: "Shaun: Hey! Thanks so much for…", date: "4/10/25",
    channel: "chat", initials: "BA", color: "var(--gray-100)", unread: 4 },
  { id: "c2", name: "Aditya Test2",
    preview: "Closing Summary Issue Inquired a…", date: "3/25/25",
    channel: "email", initials: "AT", color: "var(--purple-70)" },
  { id: "c3", name: "Pink Bike",
    preview: "Handoff Summary Customer requ…", date: "4/21",
    channel: "chat", initials: "PB", color: "var(--red-50)", active: true },
];

const channelDotColor = (ch) => ({
  chat:  "var(--teal-90)",
  email: "var(--blue-70)",
  sms:   "var(--green-50)",
  voice: "var(--red-40)",
})[ch] || "var(--gray-70)";

const InboxList = ({ selected, onSelect }) => {
  return (
    <div style={{
      width: 260, background: "#fff", borderRight: "1px solid var(--gray-30)",
      display: "flex", flexDirection: "column", flexShrink: 0,
    }}>
      {/* Header */}
      <div style={{
        padding: "12px 14px 10px", display: "flex", alignItems: "center", gap: 8,
        borderBottom: "1px solid var(--gray-30)",
      }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: "var(--gray-120)" }}>Currently viewing</div>
        <button title="Add" style={{
          marginLeft: "auto", width: 22, height: 22, borderRadius: 6, border: 0,
          background: "transparent", cursor: "pointer", color: "var(--gray-95)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Icon name="userPlus" size={14}/>
        </button>
        <button title="Close" style={{
          width: 22, height: 22, borderRadius: 6, border: 0,
          background: "transparent", cursor: "pointer", color: "var(--gray-95)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <Icon name="close" size={14}/>
        </button>
      </div>

      {/* Conversation cards */}
      <div style={{ flex: 1, overflow: "auto", padding: "4px 8px" }}>
        {SAMPLE_CONVERSATIONS.map(c => {
          const isActive = c.active || selected === c.id;
          return (
            <button key={c.id} onClick={() => onSelect && onSelect(c.id)} style={{
              width: "100%", display: "flex", gap: 10, padding: "10px 8px",
              background: isActive ? "var(--gray-25)" : "transparent",
              border: 0, borderRadius: 8,
              cursor: "pointer", textAlign: "left", marginBottom: 2,
              fontFamily: "var(--font-sans)",
            }}>
              {/* Initials avatar with channel dot */}
              <div style={{ position: "relative", flex: "0 0 28px" }}>
                <div style={{
                  width: 28, height: 28, borderRadius: "50%",
                  background: c.color, color: "#fff",
                  fontSize: 11, fontWeight: 600,
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>{c.initials}</div>
                <span style={{
                  position: "absolute", right: -2, bottom: -2,
                  width: 10, height: 10, borderRadius: "50%",
                  background: channelDotColor(c.channel),
                  border: "2px solid #fff",
                }}/>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontSize: 12.5, fontWeight: 600, color: "var(--gray-120)",
                  whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                }}>{c.name}</div>
                <div style={{
                  fontSize: 11.5, color: "var(--gray-95)", marginTop: 1,
                  whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                }}>{c.preview}</div>
                <div style={{ fontSize: 10.5, color: "var(--gray-80)", marginTop: 2 }}>{c.date}</div>
              </div>
              {c.unread && (
                <span style={{
                  alignSelf: "flex-start", marginTop: 4,
                  minWidth: 16, height: 16, padding: "0 5px",
                  borderRadius: 999, background: "var(--blue-70)", color: "#fff",
                  fontSize: 10, fontWeight: 700,
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>{c.unread}</span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

Object.assign(window, { InboxList, SAMPLE_CONVERSATIONS, channelDotColor });
