# SaaS Email Copywriting

> Generate high-performing product and marketing emails for a SaaS support/ops platform. Optimize for: trust, clear next steps, correct mental models around AI/automation, and persona relevance.

---

## Inputs to collect first

Before drafting, identify:

1. **Audience persona**
   - **Agent (rep):** works tickets daily — wants speed + clarity
   - **Agent admin:** configures routing/automation — wants control + safety
   - **Decision maker:** cares about outcomes, risk, ROI, credibility

2. **Email type**
   - Transactional (security/billing/account)
   - Lifecycle (onboarding/activation/trial/renewal)
   - Product update (release/change notice)
   - Marketing campaign (webinar/case study/promo/newsletter)
   - Operational alert (incident, degradation, delivery failure)

3. **Lifecycle phase** — Onboarding / Preview / Enable-Go Live / Live / Failure-Recovery

4. **Desired action** — the one primary CTA

5. **Truth constraints** — What is guaranteed true? Optional? Conditional?

**If any are missing**, default to: Persona: Agent admin · Phase: Enable / Go Live · Risk: Medium · Goal: Review and take one setup step.

---

## Golden Rules (Non-Negotiable)

1. **Subject must match the body.** No bait.
2. **One primary action.** Secondary links allowed but de-emphasized.
3. **State consequences for decision copy.** Especially for AI/routing, permissions, billing.
4. **Use product language exactly.** Feature names, labels, page names must match UI.
5. **Be specific, not enthusiastic.** No hype, no exclamation points in system-style emails.
6. **Reduce ambiguity around AI.** Never imply autonomy where it's not true.

---

## Email Taxonomy + What "Good" Means

### 1. Transactional (highest trust requirement)
Examples: password reset, verification, invoice, receipt, permission change.
- Success: completion, fewer tickets, low spam complaints
- Tone: direct, calm, security-forward
- Must include: "If you didn't request this…"

### 2. Lifecycle (activation, adoption, retention)
Examples: "finish setup," "you're close," "trial ending," "usage summary."
- Success: next-step completion, activation, retention
- Tone: helpful, contextual, minimal pressure

### 3. Product updates (announce/change)
Examples: new feature, workflow change, deprecation, pricing updates.
- Success: informed users, adoption, reduced surprise
- Tone: factual, benefits tied to real work
- Must include if impactful: who is affected + when + what changes

### 4. Marketing campaigns (value-first)
Examples: webinar, case study, newsletter, reactivation.
- Success: qualified clicks, downstream conversion, low unsubscribes
- Tone: value-forward, credible, skimmable

### 5. Failure/Recovery (incident, degradation)
- Success: reduced confusion, support deflection, regained trust
- Tone: accountable, precise, next update timing

---

## Subject Line Best Practices

> Long-term opens come from accurate expectation-setting, not tricks.

### Rules
- Lead with the user's reality: action required, status, timing
- Put the most informative words first
- Avoid: ALL CAPS, excessive punctuation, "RE:", vague urgency

### Strong subject patterns by persona

**Agents (reps)**
- "New: Faster triage with [feature]"
- "Your weekly queue summary"

**Agent admins**
- "Action required: Review routing before deploy"
- "Your AI automation is ready to deploy"

**Decision makers**
- "See last month's deflection and handle time"
- "New controls for AI routing risk"

### Preheader rules
- Add new info (don't repeat subject)
- Often answer: "What happens if I ignore this?"

---

## Body Copy Structure (works across types)

Recommended format (linear):
1. What this is (1 sentence)
2. Why it matters (1 sentence)
3. What to do next (CTA)
4. Details (optional bullets)
5. Fallback / support path (as needed)

### Skimmability requirements
- 1–2 line paragraphs
- Bullets for lists
- No more than 2 links before the CTA
- CTA is specific: verb + object ("Review routing rules")

### CTA guidance
- Use **one primary CTA**
- CTA should reflect an outcome, not a vague action
  - ✅ "Review smart routing rules"
  - ❌ "Learn more"

---

## Persona-Specific Voice

### Agent (rep)
- **Cares about:** speed, clarity, fewer steps, less rework
- **Emphasize:** "what changed in my workflow," "what's faster," "what to do now"
- **Avoid:** admin setup details, governance language

### Agent admin
- **Cares about:** control, predictability, safety, auditability
- **Emphasize:** scope, conditions, "nothing changes until…", rollback/disable if true
- **Avoid:** vague claims about AI autonomy

### Decision maker
- **Cares about:** outcomes, risk posture, credibility, cost
- **Emphasize:** measurable impact, governance, adoption signals, timeline
- **Avoid:** deep configuration steps

---

## AI + Automation Copy Rules (High-Stakes)

When AI is involved, classify the email as:
- **Information copy** (no execution): explain without implying action is happening
- **Decision copy** (user is enabling/approving): must name scope + consequence + responsibility

### Required phrases to include (when true)
- "Nothing goes live until you deploy."
- "Only tickets that match your routing rules are handled by AI."
- "Tickets that don't match go to a human agent."

> Never say "AI will handle tickets" without stating match rules and fallback.

---

## Templates

### Template: Agent admin — Go live setup
```
Subject: Review smart routing before you deploy
Preheader: Confirm which tickets AI can handle and where the rest go.

You're ready to deploy your AI automation.

Smart routing controls which tickets AI handles — everything else routes to a human agent.

CTA: Review routing rules

[Optional bullets: identity, trigger status, key exclusions]
Support: link to docs / contact
```

### Template: Agent — Workflow update
```
Subject: New: [feature] reduces time spent on [task]
Preheader: Here's what changed and how it works in your queue.

[What's new — 1 sentence]
[Why it matters in daily work — 1 sentence]

CTA: See what's changed

[Optional: "What stays the same"]
```

### Template: Decision maker — Monthly impact summary
```
Subject: Your AI support summary for [Month]
Preheader: Deflection, handle time, and top automation outcomes.

[1–2 headline metrics — truthful, sourced]
[What drove changes]

CTA: View full report

[Optional: "Recommended next step" (single)]
```

---

## Quality Checklist (before finalizing)

- [ ] Does the subject match the first screen of the email?
- [ ] Can a user skim in 10 seconds and know what to do?
- [ ] Is there one primary CTA?
- [ ] If AI/automation: did we state match scope + fallback?
- [ ] Is this tailored to the persona (no irrelevant detail)?
- [ ] Are there any claims we can't prove? Remove them.

---

## Output Format

When generating an email, always provide:

1. **Subject** (3 options)
2. **Preheader** (1 option)
3. **Email body** (plain text, skimmable)
4. **Primary CTA label**
5. **Notes** (only if needed: assumptions, missing info, compliance constraints)
