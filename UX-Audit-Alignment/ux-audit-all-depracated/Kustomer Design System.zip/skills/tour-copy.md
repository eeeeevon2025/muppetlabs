UX Copy Knowledge Base: Site Tours and Feature Tours
====================================================

Purpose
-------

This document defines how the GPT should write and evaluate UX copy for site tours, feature tours, onboarding walkthroughs, coach marks, hotspots, guided setup, and contextual product education.

Tour copy exists to help users understand:

*   What this feature or area is for
    
*   Why it matters now
    
*   What the user can do next
    
*   What will or will not happen if they continue
    

Tours must reduce uncertainty, not decorate the interface. Copy should help users build an accurate mental model quickly, with as little interruption as possible.

Use this document alongside the core UX copy principles: clarity, brevity, usefulness, action orientation, consistency, and plain language.

1\. Core Principles for Tour Copy
=================================

1.1 Teach through doing, not explaining
---------------------------------------

Tours should guide users toward meaningful action. Avoid long conceptual explanations before the user has context.

Prefer:

> Create your first ruleStart with a trigger, then choose what happens next.

Avoid:

> Rules are powerful workflow automation objects that help your team streamline operational processes.

Why: Users scan before they read. Tour copy should be short, front-loaded, and immediately useful.

1.2 Show value before mechanics
-------------------------------

Start with the outcome, then explain the control.

Prefer:

> Track recurring issuesAnomalies show unusual changes in ticket volume, reply time, or customer sentiment.

Avoid:

> This page contains anomaly detection settings and data visualizations.

1.3 Keep the user in control
----------------------------

Tours must not imply that the product has taken action unless it actually has.

Prefer:

> Review suggested replies before enabling automation.

Avoid:

> Your AI agent is ready to handle replies.

This is especially important for AI-assisted, automated, or agentic workflows. Copy must clearly distinguish suggestion, preview, configuration, and execution.

1.4 Use tours to orient, not persuade
-------------------------------------

Tour copy should not oversell. Avoid marketing claims inside operational UI.

Prefer:

> Use this dashboard to monitor open issues and response trends.

Avoid:

> Unlock powerful insights that transform your support operations.

2\. When to Use a Tour
======================

Use a site or feature tour when the user needs orientation before they can act confidently.

Good use cases:

*   First-time onboarding
    
*   New feature introduction
    
*   Complex workflow setup
    
*   Admin configuration
    
*   AI or automation preview
    
*   Empty state education
    
*   Migration or UI change orientation
    

Avoid tours when:

*   A label or helper text would solve the problem
    
*   The user is trying to complete an urgent task
    
*   The tour repeats obvious UI labels
    
*   The tour compensates for confusing product structure
    
*   The user must read many steps before doing anything
    

If a tour requires excessive explanation, flag the issue as a product design problem. Copy should not carry broken information architecture or unclear interaction design.

3\. Tour Copy Structure
=======================

Each tour step should usually include:

1.  **Heading**: Names the value or object
    
2.  **Body**: Explains what the user can do or learn here
    
3.  **CTA**: Sets an accurate expectation for the next action
    

Recommended pattern
-------------------

**Heading**Outcome or object

**Body**What this helps the user do, in one short sentence

**CTA**Specific next step

Example:

> **Monitor quality trends**See where conversations are improving, declining, or need review.**View dashboard**

4\. Tour Step Types
===================

4.1 Orientation step
--------------------

Use when introducing a page, section, or feature area.

Recommended structure:

> **Welcome to \[area\]**Use this space to \[primary outcome\].**Start tour**

Example:

> **Welcome to Quality**Use this space to track conversation trends, review anomalies, and improve support quality.**Start tour**

Avoid:

> **Let’s explore your powerful new quality experience**

4.2 Object explanation step
---------------------------

Use when explaining a specific UI element or concept.

Recommended structure:

> **\[Object name\]**\[What it does or what it shows.\]**Next**

Example:

> **Quality monitors**Monitors track conversations that match the conditions you choose.**Next**

Avoid:

> **Here’s where the magic happens**

4.3 Action guidance step
------------------------

Use when the user should do something after reading.

Recommended structure:

> **\[Action outcome\]**\[What happens when they take the action.\]**\[Verb + object\]**

Example:

> **Create a monitor**Choose the conversations you want to track, then review matching results.**Create monitor**

Avoid generic CTAs like:

*   Continue
    
*   Submit
    
*   Proceed
    
*   Let’s go
    

Buttons, links, and labels are promises. Users should be able to predict the outcome before clicking.

4.4 Preview or shadow-mode step
-------------------------------

Use when showing what the system would do without taking action.

Required language:

*   Use “would”
    
*   Make it clear no action was taken
    
*   Encourage review, not approval
    
*   Avoid execution verbs like “sent,” “resolved,” or “closed”
    

Prefer:

> **Preview suggested replies**See how the agent would respond before it sends anything to customers.

Avoid:

> **Review what the agent resolved**

Preview states must build trust without implying live execution. If preview copy could be mistaken for real action, treat it as blocking.

4.5 Enable or go-live step
--------------------------

Use when the tour leads to activation, publishing, automation, or customer-visible behavior.

Required copy must name:

*   What will happen
    
*   Who or what it affects
    
*   Whether the action is reversible
    
*   Who remains responsible
    

Example:

> **Enable automatic replies**The agent will reply to matching customer emails without review. You can pause it at any time.**Enable replies**

Avoid:

> **You’re ready to go live**

Enablement copy is decision copy. It must name consequences, scope, and responsibility.

4.6 Completion step
-------------------

Use when the tour ends and the user should know what to do next.

Recommended structure:

> **You’re ready to \[next action\]**\[Clear next step or safe reassurance.\]**\[Primary action\]**

Example:

> **You’re ready to create a monitor**Start by choosing the conversations you want to track. You can edit the monitor later.**Create monitor**

Avoid:

> **All set! You’re a pro now**

Professional SaaS tours should reinforce competence, not perform delight.

5\. Lifecycle Rules for Tours
=============================

Tour copy must match the user’s lifecycle phase.

Onboarding
----------

Goal: Build understanding and reduce fear.

Use:

*   Simple concepts
    
*   Safety and reversibility
    
*   Clear next steps
    
*   Low-pressure language
    

Avoid:

*   Strong claims
    
*   Execution language
    
*   Over-precision
    
*   Long explanations
    

Example:

> **Set up your workspace**Add the basics now. You can adjust these settings later.

Preview / Shadow
----------------

Goal: Prove usefulness without risk.

Use:

*   Conditional language
    
*   “Would have” framing
    
*   Review-oriented CTAs
    
*   Clear no-action language
    

Example:

> **See what the agent would suggest**These examples show how the agent interprets recent conversations. Nothing is sent.

Enable / Go Live
----------------

Goal: Force clarity and informed consent.

Use:

*   Explicit consequences
    
*   Scope and limits
    
*   Strong, specific CTAs
    
*   Calm, direct tone
    

Example:

> **Turn on automation**This rule will apply to new tickets that match these conditions. You can pause it at any time.

Live / Production
-----------------

Goal: Reinforce predictability and control.

Use:

*   Current state
    
*   What is active or paused
    
*   Where to edit, pause, or review
    

Example:

> **Automation is active**This rule runs when new tickets match the selected conditions.

Failure / Recovery
------------------

Goal: Restore confidence and guide action.

Use:

*   What happened
    
*   Why, when helpful
    
*   What to do next
    
*   No blame
    

Example:

> **Tour could not load**Refresh the page to try again. Your settings were not changed.

Lifecycle phase should determine tone, precision, and safeguards.

6\. Risk Rules for Tours
========================

Most tours are low-risk because they explain rather than execute. Risk increases when the tour includes decisions, activation, automation, permissions, data changes, or customer-visible actions.

Low-risk tour copy
------------------

Use for read-only education, UI orientation, or reversible personal preferences.

Example:

> **Customize your view**Choose which columns appear in this table.

No warning needed.

Medium-risk tour copy
---------------------

Use for workflow configuration, internal settings, or user-triggered automation.

Example:

> **Create a routing rule**Choose the conditions and destination before the rule starts assigning tickets.

Name scope and action clearly.

High-risk tour copy
-------------------

Use for AI agents, customer-visible automation, billing, permissions, access, irreversible actions, or recurring background execution.

Example:

> **Enable customer replies**The agent will send replies to matching customers without review. You can pause replies from settings.

High-risk copy must name consequences, scope, and reversibility. If any one risk signal is high, treat the overall moment as high risk.

7\. Decision Copy vs Information Copy in Tours
==============================================

Information copy
----------------

Information copy explains, previews, or describes without causing real impact.

It should:

*   Be calm and explanatory
    
*   Avoid implying execution
    
*   Use conditional framing when appropriate
    
*   Keep the user oriented
    

Example:

> **Suggested next steps**The agent can recommend actions based on recent conversations.

Decision copy
-------------

Decision copy asks the user to approve, enable, publish, send, delete, or trigger a meaningful change.

It must:

*   Name what will happen
    
*   Name scope and impact
    
*   State reversibility or lack of it
    
*   Use a specific CTA
    
*   Slow the user down when risk is high
    

Example:

> **Publish this tour**Everyone with access to Support will see this tour the next time they open the dashboard.**Publish tour**

If decision copy lacks consequence clarity, treat it as blocking.

8\. AI and Automation Tour Rules
================================

When tours introduce AI, agents, recommendations, or automation, apply stricter rules.

Tour copy must explain:

*   What the agent can do
    
*   What triggers it
    
*   Whether it suggests or acts
    
*   Whether users can review before execution
    
*   How users can pause, edit, undo, or override
    
*   What happens if the agent fails
    

Prefer:

> **Review agent suggestions**The agent suggests replies based on conversation history. It does not send anything until you approve.

Avoid:

> **Let the agent handle your conversations**

Do not use anthropomorphic language. Avoid words that imply intent, emotion, judgment, or human-like reasoning.

Avoid:

*   The agent knows
    
*   The agent understands
    
*   The agent thinks
    
*   The agent handles it for you
    
*   Your assistant takes care of this
    

Prefer:

*   The agent suggests
    
*   The agent sends
    
*   The agent applies
    
*   The agent checks
    
*   The agent uses
    

Agent behavior must be predictable from the copy alone.

9\. CTA Standards for Tours
===========================

Tour CTAs must be specific, accurate, and proportional to risk.

Low-risk CTAs
-------------

Good:

*   Start tour
    
*   Next
    
*   Got it
    
*   Show me
    
*   View dashboard
    
*   Try it
    

Use only when no real change happens.

Medium-risk CTAs
----------------

Good:

*   Create monitor
    
*   Save settings
    
*   Review rule
    
*   Test automation
    
*   Preview replies
    

These should describe the next meaningful step.

High-risk CTAs
--------------

Good:

*   Enable automatic replies
    
*   Publish tour
    
*   Send to customers
    
*   Apply to all teams
    
*   Delete rule
    
*   Disable automation
    

High-risk CTAs must not be vague.

Avoid:

*   Continue
    
*   Confirm
    
*   Proceed
    
*   Finish
    
*   Done
    
*   Looks good
    

Conversion should never override clarity, informed consent, or consequence awareness.

10\. Tone Standards
===================

Tour copy should be:

*   Neutral
    
*   Calm
    
*   Professional
    
*   Direct
    
*   Helpful
    
*   Outcome-first
    

Avoid:

*   Exclamation points
    
*   Emojis
    
*   Cutesy language
    
*   Marketing hype
    
*   Forced enthusiasm
    
*   Humor in risky moments
    
*   “Magic” or “smart” claims
    

Prefer competence over delight.

Good:

> **Your monitor is ready**It will start tracking new matching conversations now.

Bad:

> **Nice work! Your monitor is ready to work its magic!**

11\. Length Guidelines
======================

Tour steps should be short enough to scan without slowing the user down.

Recommended limits:

*   Heading: 2–6 words
    
*   Body: 1 sentence, 8–20 words
    
*   CTA: 1–4 words
    

Longer copy is acceptable only when:

*   The action is risky
    
*   The user needs consequence clarity
    
*   The tour introduces AI or automation
    
*   The user is about to enable, publish, send, delete, or apply changes broadly
    

Do not hide critical information in tooltips, fine print, or “Learn more.”

12\. Progressive Disclosure Rules
=================================

Do not explain everything at once.

Use progressive disclosure when:

*   The feature has advanced settings
    
*   The user needs orientation before details
    
*   The user can safely learn by doing
    
*   The explanation would interrupt task flow
    

Prefer:

> **Set conditions**Choose which conversations this monitor tracks.

Then later:

> **Add filters**Narrow results by team, topic, priority, or channel.

Avoid:

> **Set conditions**Conditions determine how monitors identify conversations by evaluating selected filters, thresholds, metadata, teams, topics, priority, channels, and other properties.

Over-explaining early increases doubt and cognitive load.

13\. Empty State Tour Copy
==========================

Use empty states to start the user’s first meaningful action.

Recommended structure:

> **No \[objects\] yet**\[What the object helps the user do.\]**\[Create object\]**

Example:

> **No monitors yet**Create a monitor to track conversations that match specific quality signals.**Create monitor**

Avoid:

> **Looks empty here**

Empty states should not be cute. They should orient and move the user forward.

14\. Hotspot and Coach Mark Copy
================================

Hotspots and coach marks should explain one thing only.

Good:

> **Filter by team**Show results for one team or compare teams across the same period.

Bad:

> **Filters**Use filters to customize this dashboard and get more granular insights based on your business needs.

Rules:

*   One concept per hotspot
    
*   No repeated UI label unless clarification is needed
    
*   No generic “Learn more about this feature”
    
*   No tour step should block core task completion unless necessary
    

15\. Progress and Completion
============================

Tours should show progress when the flow has more than 2 steps.

Prefer milestone language:

> Step 2 of 4

Use completion states that feel conclusive:

> **Tour complete**You can reopen this tour from Help.

Avoid ambiguous completion:

> **You’re all caught up**

Users should know whether they finished the tour, dismissed it, or need to do something next.

16\. Dismissal and Restart Copy
===============================

Users must be able to leave a tour without fear.

Good dismissal copy:

> **Skip tour**You can restart it later from Help.

For higher-risk or setup-dependent tours:

> **Exit setup tour?**Your changes are saved. You can continue setup later from Settings.

Avoid:

> **Are you sure you want to abandon this?**

Dismissal copy should not shame or pressure the user.

17\. Error and Failure Copy for Tours
=====================================

Every tour error must explain:

1.  What happened
    
2.  What to do next
    
3.  Whether user work or settings were affected
    

Example:

> **Tour could not load**Refresh the page to try again. Your settings were not changed.

Example:

> **Step unavailable**You do not have permission to view this setting. Ask an admin for access.

Avoid:

> **Something went wrong**

Generic error messages are not acceptable.

18\. Bad Patterns to Flag
=========================

Flag tour copy that:

*   Repeats what is already obvious on screen
    
*   Uses internal product language
    
*   Uses metaphors instead of concrete labels
    
*   Overpromises outcomes
    
*   Hides consequences behind vague CTAs
    
*   Implies automation when the user is only previewing
    
*   Sounds celebratory in serious workflows
    
*   Requires users to read too much before acting
    
*   Introduces a new term without defining it
    
*   Uses different terms for the same object across steps
    
*   Pushes users toward activation without informed consent
    

Treat these as blocking when the tour involves AI, automation, permissions, customer communication, data, billing, access, or irreversible changes.

19\. Recommended Output Format for the GPT
==========================================

When asked to write tour copy, return:

Assumptions
-----------

State inferred user, goal, lifecycle phase, and risk level.

Recommended tour copy
---------------------

Provide the actual copy in a clean table or grouped by step.

Each step should include:

*   Step name
    
*   Heading
    
*   Body
    
*   CTA
    

Notes
-----

Call out only material issues, such as:

*   Risk mismatch
    
*   Unclear scope
    
*   Vague CTA
    
*   Preview vs execution confusion
    
*   Product design issue copy cannot solve
    

20\. Example Output
===================

Assumptions
-----------

User: Admin setting up quality monitoringGoal: Understand the Quality area and create a first monitorLifecycle phase: OnboardingRisk: Medium, because monitor setup may affect team workflows but does not directly contact customers

Recommended tour copy
---------------------

StepHeadingBodyCTA1Welcome to QualityTrack conversation trends, review anomalies, and find areas that need attention.Start tour2View performance trendsUse the dashboard to see how quality changes across teams and time periods.Next3Create monitorsMonitors track conversations that match the conditions you choose.Next4Review anomaliesAnomalies show unusual changes that may need investigation.Next5Create your first monitorStart by choosing the conversations and signals you want to track.Create monitor

Notes
-----

“Quality” should stay consistent across the flow. Do not switch between “quality,” “performance,” and “monitoring” unless those are distinct product concepts.

21\. Final Evaluation Checklist
===============================

Before returning tour copy, verify:

*   The first step explains why the tour matters
    
*   Each step teaches one concept only
    
*   CTAs describe the outcome
    
*   The copy does not repeat obvious UI labels
    
*   The copy distinguishes preview from execution
    
*   AI or automation behavior is explicit
    
*   Risk level matches confirmation strength
    
*   Consequences are named before activation
    
*   Users know whether they can skip, edit, pause, undo, or restart
    
*   The tone is calm, professional, and direct
    
*   No copy is compensating for a confusing product design
    

Final anchor test:

> Can a busy admin understand what this feature does, what happens next, and whether it is safe to proceed without rereading?