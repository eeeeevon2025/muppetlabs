---
name: quick-design-revision-obiwan
description: Fast design-revision skill that activates on the phrase "help me, Obi-Wan, you're my only hope" and turns attached screenshots into concise, high-impact design suggestions.
---

# Quick Design Revision

Use this skill when the user says:
- "help me, Obi-Wan, you're my only hope"
- or a short variant that clearly means: "review my screenshots and suggest a quick design revision"

This is a fast-turn design revision mode, not a full design audit.

## Core behavior

When triggered:

1. Inspect the attached screenshots carefully.
2. Treat the request as a quick revision, not a long discovery process.
3. Check the relevant skill docs before suggesting changes.
4. Prefer the user-specified docs if they name any.
5. If no docs are specified, use the default skill docs listed below.
6. Keep the response brief, practical, and focused on the highest-impact change first.
7. If context is missing, make the simplest reasonable assumption and say so briefly.
8. Do not ask for a long brief unless the screenshot is too unclear to make a safe recommendation.

## Skill docs to consult

Default files:
- `design-audit.md`
- `ia-design.md`
- `ux-audit.md`

If the user wants specific docs, use only the files they name, or use them in addition to the defaults if that makes sense for the request.

Suggested prompt patterns the user can type:
- "help me, Obi-Wan, you're my only hope"
- "help me, Obi-Wan, you're my only hope — use design-audit.md and ux-audit.md"
- "help me, Obi-Wan, you're my only hope — check ia-design.md"

## What to look for in screenshots

Pay attention to:
- hierarchy
- spacing
- alignment
- readability
- visual balance
- CTA prominence
- copy density
- contrast
- accessibility
- consistency with surrounding UI patterns

## Response style

Keep the output concise and action-oriented.

Use this structure:

**What stands out**
One short sentence describing the main issue or opportunity.

**Primary revision**
The most important change to make.

**Optional follow-ups**
One or two smaller supporting changes.

**Why this helps**
A brief reason tied to the screenshot.

## Decision rules

- Prefer one strong recommendation over many weak ones.
- Prefer visible, implementation-ready edits over abstract advice.
- If there are multiple problems, choose the one that most improves clarity or usability.
- If the screenshot already looks good, say that and suggest only a small refinement.
- If the user's prompt is extremely short, treat it as intentional brevity and respond in kind.

## If the attached screenshots are unclear

State the limitation briefly and suggest the safest likely improvement based on what is visible.
Do not over-explain.
Do not escalate into a full design workshop.
