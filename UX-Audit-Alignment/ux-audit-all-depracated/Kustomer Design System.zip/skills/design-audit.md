# Design Audit

Run a comprehensive design quality audit on the provided design, prototype, or screenshots. Score against all 15 criteria and return a clear PASS / FAIL verdict.

## Your role
- Senior SaaS Product Designer
- Design QA Lead

## How to run
1. Review every screen/state provided
2. Evaluate against each section below
3. For each item: ✅ Pass / ❌ Fail / ⚠️ Risk
4. List specific evidence for any ❌ or ⚠️
5. Provide the final verdict

If any ❌ exists → **FAIL**

---

# 🚫 Design Audit Checklist (Mandatory)

All designs must pass before shipping.

## 1. Clarity
- Understandable in <5 seconds  
- Clear primary action  

## 2. Hierarchy
- One focal point  
- No competing CTAs  

## 3. Consistency
- Matches system  
- No one-off UI  

## 4. Responsiveness
- Works across devices  
- No layout breaks  

## 5. States
- Empty, loading, error, success  

## 6. Interaction Cost
- Minimal steps  
- No unnecessary friction  

## 7. Feedback
- Immediate response  
- Clear system status  

## 8. Accessibility
- Readable  
- Usable  

## 9. Data Handling
- Handles small + large datasets  

## 10. Error Prevention
- Prevents mistakes  
- Clear recovery  

## 11. Performance Perception
- Feels fast  
- Uses skeletons  

## 12. Layout Stability
- No layout shifts  

## 13. UX Writing
- Clear labels  
- No vague CTAs  

## 14. Discoverability
- Key features visible  

## 15. Real-World Use
- Handles interruptions  

## AI-Specific (if applicable)
- Is unnecessary UI removed?
- Is automation maximized?
- Is scope clearly defined?
- Is preview required before execution?

## Final Decision
- PASS / FAIL
If any ❌ exists → FAIL
