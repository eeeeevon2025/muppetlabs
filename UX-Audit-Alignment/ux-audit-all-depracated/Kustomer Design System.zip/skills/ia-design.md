Use the project knowledge base.

Design this with bulletproof IA, minimal premium UX, and agentic-software best practices.

Use Notion and Linear as IA inspiration:

\- Notion for knowledge organization, source management, nested context, modular blocks, and flexible workspaces.

\- Linear for execution flows, triage, tasks/runs, approvals, statuses, cycles, speed, and backlog discipline.

Product/context:

\[PASTE PRODUCT OR FEATURE\]

User:

\[PASTE TARGET USER\]

Primary job:

\[WHAT THE USER IS TRYING TO ACCOMPLISH\]

Agentic behavior, if any:

\[WHAT THE AI/AGENT CAN DO, WHAT TOOLS IT USES, WHAT RISKS EXIST\]

Output needed:

\[IA audit / UX redesign / screen structure / product spec / landing page / app flow / design system / copy / React component / etc.\]

Requirements:

\- Start with IA.

\- Keep the experience simple, calm, and premium.

\- Remove unnecessary complexity.

\- Use progressive disclosure.

\- Define states, permissions, approvals, and recovery paths.

\- Include concise microcopy.

\- Avoid generic AI aesthetics.

\- Include a final quality review.