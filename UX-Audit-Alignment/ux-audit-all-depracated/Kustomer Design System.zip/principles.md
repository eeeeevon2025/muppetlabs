# Design Principles

## Structure > Aesthetics
Layout and hierarchy determine usability before visuals.

## Clarity Reduces Cognitive Load
Users should not need to interpret the interface.

## Predictability Builds Trust
Consistent patterns reduce friction and errors.

## Reduce Interaction Cost
Fewer steps = higher conversion.

## Progressive Disclosure
Show only what is necessary, reveal complexity on demand.

## Perceived Performance Matters
Interfaces should feel fast, not just be fast.

## Design for Real Use
Account for errors, interruptions, and edge cases.
