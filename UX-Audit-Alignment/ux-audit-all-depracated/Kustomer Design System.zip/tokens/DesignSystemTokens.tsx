import { useDesignSystemTokens } from './hooks';

const DesignSystemTokens = () => {
  useDesignSystemTokens();

  return null;
};

export default DesignSystemTokens;
