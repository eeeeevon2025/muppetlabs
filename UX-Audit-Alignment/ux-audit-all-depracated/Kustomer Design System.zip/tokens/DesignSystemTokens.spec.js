import { render } from '@testing-library/react';
import DesignSystemTokens from '../DesignSystemTokens';
import * as hooks from '../hooks';

jest.mock('../hooks', () => ({
  useDesignSystemTokens: jest.fn(),
}));

describe('DesignSystemTokens', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render null', () => {
    const { container } = render(<DesignSystemTokens />);
    expect(container.firstChild).toBeNull();
  });

  it('should call useDesignSystemTokens hook', () => {
    render(<DesignSystemTokens />);
    expect(hooks.useDesignSystemTokens).toHaveBeenCalled();
  });
});
