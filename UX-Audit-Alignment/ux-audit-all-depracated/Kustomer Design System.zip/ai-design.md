# AI Product Design Knowledge Base
### For Enterprise SaaS — Kustomer Design System

> Always align with Kustomer Design Rules. Body: #ffffff. Font: Inter only. No all caps. Color minimal. Cognitive load first.

---

## 1. Think Like an AI Designer

AI design is not UI design with a chat window bolted on. It is a fundamental shift in how the product does work — and how the interface communicates that work to the user.

**The core mental shift:**

| Traditional UI Thinking | AI Designer Thinking |
|---|---|
| User triggers action → System responds | System acts → User reviews or overrides |
| Every step is a UI decision | Most steps should be automatic |
| More controls = more power | Fewer controls = better AI trust |
| Errors stop the user | AI errors surface without blocking flow |
| The user does the work | The AI does the work; the user approves |

**The AI designer's primary question is not:** "How does the user do this?"
**It is:** "Should the user have to do this at all?"

If the answer is no — automate it. Surface the result. Let the user confirm, override, or ignore.

---

## 2. Default to Automation. UI is a Fallback.

Every piece of UI you add to an AI product is a cost. It means the AI couldn't handle it, or you didn't trust it to.

**Automation-first decision ladder:**

1. **Can the AI do this without user input?** → Do it. Surface the result.
2. **Does the user need to approve before it executes?** → Show a confirmation with scope and impact.
3. **Does the user need to configure it?** → Show the minimum viable configuration surface. Pre-fill what you can.
4. **Does the user need to build it from scratch?** → This is a failure state. Flag it as a product gap.

**Apply this to every screen you design or review.** If a panel has 6 fields and the AI knows 4 of them, show 2 fields. Auto-populate the rest. Expose the pre-filled values in a collapsed "review" section — don't hide them entirely, but don't force the user to interact with them.

**Design principle:** The AI should make a decision. The user should be able to unmake it.

---

## 3. Hierarchy of AI Surface Types

Not all AI moments are equal. Map every AI interaction to one of these surface types before designing it.

### 3.1 Ambient AI (No UI Required)
AI running silently in the background. Sentiment detection, intent classification, auto-tagging, routing, summarization that happens on open.

- No interaction surface
- No settings surface unless the user explicitly manages it
- Status only: a small indicator or badge that AI ran
- Correction is possible but not prominent

### 3.2 Suggestive AI (Low-friction UI)
AI proposes something. User accepts, edits, or ignores. Response suggestions, smart field pre-fill, next-action recommendations.

- Present the suggestion in-context, not in a modal
- Accept/dismiss interaction only — no multi-step setup
- Confidence indicators only if failure is high-stakes
- Inline, not interruptive

### 3.3 Configurable AI (Configuration UI)
User defines rules, scope, or behavior that governs how AI runs. Workflow automation, routing rules, AI personas, threshold configuration.

- Preview before activation is mandatory
- Scope and impact must be explicit: what will this affect? how many? under what conditions?
- Activation and configuration are always separate steps
- Destructive/irreversible configurations require a distinct visual treatment

### 3.4 Agentic AI (Approval + Monitoring UI)
AI takes multi-step actions autonomously. Users set guardrails, approve decision branches, or override in-progress actions.

- Every agentic action must have a visible scope statement before it runs
- Approval UI must clearly show: what will happen, what it will touch, whether it can be undone
- Live monitoring must be available at all times while the agent is running
- Failure and partial completion must surface as distinct states — not generic errors

---

## 4. The 5 AI UI Anti-Patterns to Eliminate

### 4.1 The Wizard That Shouldn't Exist
A multi-step setup flow for something the AI could infer. If the AI has the data, use it. Present a review step instead of a build step.

### 4.2 The Confidence Theater
Showing percentage scores, probability bars, or confidence meters on every AI output. These create noise unless the user has a clear action to take based on the number. Surface confidence indicators only when the recommended action changes based on threshold (e.g., "below 70% — requires human review").

### 4.3 The Disclaimer Dump
Stacking legal-style copy ("AI may be inaccurate. Results may vary. Please verify.") as a substitute for designing trust. Disclaimers must be one line, placed contextually, and only where the risk is genuinely high. Design structural trust — don't outsource it to text.

### 4.4 The Overwhelming Dashboard
A dashboard with 12 AI metrics, 4 charts, and 3 activation CTAs on load. AI dashboards should answer one question at the top: "Is the AI working?" Everything else is subordinate. Lead with system status, not analytics.

### 4.5 The Silent Failure
AI ran, something went wrong, nothing surfaced. AI errors must always appear — but they must not block the user. Show the failure state, show the fallback, show the recovery path. Silence is worse than a graceful error.

---

## 5. AI State Design

Every AI feature exists in one of these operational states. Each state requires a distinct visual and copy treatment. Designing for the "enabled and working" state only is incomplete.

| State | Visual Treatment | Copy Principle |
|---|---|---|
| **Not configured** | Empty state with one clear CTA | Name what becomes possible |
| **Configured, not active** | Muted/draft visual | Show what will happen when enabled |
| **Preview / Sandbox** | Consistent preview badge on all affected surfaces | State scope and data boundaries explicitly |
| **Active / Live** | Status indicator — subtle, not dominant | Reinforce that it's running. Don't advertise it. |
| **Degraded** | Warning state — amber, non-blocking | Say what's reduced; give a recovery action |
| **Failed** | Error state — red, contained | Name the failure. Give next steps. Never blame the user. |
| **Processing** | Inline skeleton or spinner — never modal-blocking | Show progress only if it takes >2s |
| **Completed** | Transient success indicator | Confirm the action. Don't announce it. |

**Rule:** An AI surface with no visible state is an unfinished AI surface.

---

## 6. Automation Configuration UI Principles

When the user must configure automation, follow this structure:

### Panel Anatomy (in order)
1. **What this does** — one sentence, outcome-first, no marketing language
2. **Scope selector** — what will it apply to? (channels, teams, queue, all)
3. **Conditions** — if/when logic. Keep to 2–3 condition fields. Use progressive disclosure for advanced options.
4. **Behavior** — what happens when conditions are met. Be specific: "Assign to Team: Tier 2 Support" not "Route intelligently."
5. **Preview** — show estimated impact before activation. "Will affect ~340 conversations/day based on last 30 days."
6. **Activate** — a single, clearly scoped CTA. Separate from Save.

### Rules
- Never combine Save and Activate into the same action
- Always show estimated scope before activation
- Pre-fill conditions from existing data where possible
- If scope cannot be calculated, say "Scope unavailable — verify before enabling"
- Undo/deactivate must always be accessible from the same surface as activation

---

## 7. Trust Architecture for AI Products

Trust is not built through copy. It is built through structural design decisions.

**Trust signals in AI UI:**

| Signal | Implementation |
|---|---|
| **Traceability** | Show why the AI made a recommendation ("Based on: last 30 days of CSAT data") |
| **Override accessibility** | Every AI decision must have a visible override path — never buried |
| **Scope transparency** | Always show what the AI is acting on before it acts |
| **Auditability** | Show a log or history of what the AI did, even if minimal |
| **Graceful degradation** | When AI is uncertain, surface the uncertainty without panic |
| **Human checkpoints** | High-stakes agentic actions should require explicit human approval at defined thresholds |

**The trust test:** Can a skeptical admin understand what the AI is doing, why it's doing it, who configured it, and how to stop it — without leaving the current screen?

If no → redesign.

---

## 8. Copy Rules for AI Surfaces (Kustomer-aligned)

Pulled from Basic UX Principles. AI copy must meet a higher standard than standard admin copy because AI behavior is less predictable and trust is harder to establish.

### Framing
- AI assists. It does not decide — unless it has been explicitly configured to, and the user has explicitly confirmed that.
- Never imply autonomy you don't have.
- Never use the word "intelligent" or "smart" in UI copy. These are marketing words inside an operational surface. Use specific, literal capability descriptions instead.

### Disclaimers
- Maximum one disclaimer per AI surface
- Must be one sentence
- Must not undermine the primary action
- Correct: "Results are based on the last 30 days of data."
- Incorrect: "AI may produce inaccurate results. Always verify before taking action. Kustomer is not responsible for automated decisions."

### CTAs for AI Activation
- Name the consequence: "Enable Auto-Routing" not "Turn On"
- Include scope where possible: "Enable for all inbound conversations" not "Enable"
- Activation and preview are always separate buttons

### Empty States
- Name what will appear, not what is missing
- Explain when it will appear
- Give one clear next step
- Avoid: "No data yet." → Use: "Sentiment scores will appear here once 10 or more conversations are resolved."

---

## 9. AI Feature Review Checklist

Use this checklist on every AI surface before considering it complete.

**Automation**
- [ ] Is every manual step that the AI could handle already automated?
- [ ] Is configuration pre-filled from available data?
- [ ] Is there a preview step before activation?
- [ ] Are Save and Activate separated?

**State Design**
- [ ] Are all 8 operational states accounted for? (Not configured / Configured / Preview / Active / Degraded / Failed / Processing / Completed)
- [ ] Does every state have a distinct visual treatment?
- [ ] Are failures non-blocking with recovery paths?

**Trust Architecture**
- [ ] Is the AI's data source or reasoning visible?
- [ ] Is override accessible from the primary surface?
- [ ] Is scope shown before any automation executes?
- [ ] Is there an audit trail or history?

**Copy**
- [ ] Does every AI surface have outcome-first copy?
- [ ] Is AI framed as assistive, not autonomous (unless explicitly configured otherwise)?
- [ ] Is there at most one disclaimer, one sentence, non-undermining?
- [ ] Are CTAs scoped and consequence-named?

**Density and Hierarchy**
- [ ] Is there one dominant question the AI surface answers?
- [ ] Is system status the most prominent element on dashboards?
- [ ] Does the layout reduce decision burden rather than add to it?
- [ ] Are confidence scores or probability metrics only shown when actionable?

---

## 10. Kustomer-Specific AI Design Constraints

These rules are non-negotiable and override general AI design guidance where they conflict.

- **Surface background: #FFFFFF always.** No tinted backgrounds on AI surfaces, even to signal AI-specific context. (App canvas still follows `layout-lock.md`: `#F7F8FA`.)
- **Font: Inter only.** No display font variations for AI output or suggestion text.
- **No all caps.** This includes AI status labels, automation state badges, and confidence indicators.
- **Color use is minimal.** Use color only to communicate system state (error, warning, active). Do not use color to differentiate "AI content" from "human content" decoratively.
- **AI is not decorated.** No gradient auras, animated sparkle icons, or AI-specific icon flourishes. If Kustomer's design system has an AI icon, use that. If not, use a standard system icon.
- **Only change what the prompt specifies.** Never rebuild surrounding UI to accommodate an AI feature. Add the AI surface to the existing structure.
- **Cognitive load is the primary design constraint** on all AI dashboards and configuration panels. Density must be earned — every element must justify its presence.
- **AI surfaces = concise capability framing + clear disclaimers.**
- **An AI surface must feel powerful but controlled.** Power comes from scope and capability. Control comes from structural transparency, not from adding more toggles.

---

## 11. Suggested AI Feature Patterns for Kustomer Context

These are patterns that should be considered when designing any Kustomer AI feature. Use these as structural starting points, not as templates.

### Inline Suggestion Strip
For response suggestions, topic recommendations, or next-action prompts. Appears below or adjacent to the primary work area. One suggestion shown at a time. Accept / See more / Dismiss. No configuration required at the point of use.

### Automation Rule Builder
Condition → Action → Preview → Activate. Scope shown at preview step. Estimated impact shown (conversations/day, customers affected). Activation requires a named, scoped CTA. Deactivation accessible from the same panel.

### AI Health Dashboard
Top-level: system status (one of: Active / Degraded / Inactive). Below: key operational metrics (deflection rate, accuracy, volume handled). Further below: configuration and management. System status must be scannable in <2 seconds.

### Agent Action Approval Panel
Used for agentic workflows where the AI proposes a multi-step action. Shows: action summary, scope, affected records, reversibility, and two actions — Approve and Reject. Optionally: Edit before approving. Never auto-executes without this panel having been displayed.

### AI Configuration Preview Panel
Shown before any automation goes live. Answers: What will this do? What will it affect? When will it run? What happens if it fails? Estimated impact. One Activate CTA. One link back to Edit.

---

*This document is a living knowledge base. Extend it as new AI surface patterns emerge. Always verify against `docs/design-system-lock.md`, `docs/typography-lock.md`, and `docs/layout-lock.md` before implementation.*
