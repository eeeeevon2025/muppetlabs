# Kustomer Design System

The single source of truth for Kustomer product design — fonts, colors, layout, components, and the rules that govern them.

> **New here?** Read this README first. Everything you need is linked below.

---

## What this is

A complete design system for **Kustomer** — the AI-powered customer service CRM. This repo contains:

- **Design tokens** (colors, type, spacing, shadows, motion) in CSS variables
- **Brand assets** (logos, avatars, Kusty the mascot)
- **Governance rules** that every design and prototype must follow
- **Reference documentation** for typography, components, and patterns
- **Runnable skills** for design + UX audits and information architecture
- **A consolidated reference doc** (`design.md`) you can drop into any project

---

## 🚀 Quick Start

### If you're using this in Cursor / Claude Code / Claude.ai
1. The lock files and design rules **auto-load via `CLAUDE.md`** — you don't need to do anything to get them applied
2. To invoke a specific workflow, **run a skill** (see "Skills" below)
3. To reference the full system in another project, copy **`design.md`**

### If you're building a design or prototype here
1. Reference tokens from `colors_and_type.css`
2. Follow the lock files in `docs/` — no improvising
3. Run the **Design Audit** skill before declaring anything done

---

## 🛠️ Skills (Runnable Prompts)

Skills are prompt-driven workflows you invoke by name. They live in `skills/` and produce deliverables (audits, IA plans, etc.).

**How to use:** just say *"run the [name] skill"* in chat and I'll ask for the inputs I need.

| Skill | Invocation | Returns |
|---|---|---|
| **UX Audit** | "Run the UX audit skill on this [prototype / screenshots / PRD]" | Flow inventory, missing UX requirements, error/empty state matrix, accessibility audit, priority matrix |
| **Design Audit** | "Run the design audit skill on this [design / screenshot]" | 15-point quality checklist with PASS / FAIL verdict |
| **IA Design** | "Run the IA design skill" — then paste product, user, job, agentic behavior, and output needed | Information architecture, screen structure, states, microcopy, quality review |
| **Tour Copy** | "Run the tour copy skill for [feature / flow]" or "Audit this tour copy" | Tour copy in structured format — assumptions, step-by-step copy (heading, body, CTA), risk-aware notes |
| **Email Copy** | "Run the email copy skill for [email type / persona / goal]" | 3 subject options, preheader, body copy, primary CTA |
| **Trial Lifecycle Emails** | "Run the trial lifecycle skill" — specify which stage(s) you need | Full 5-stage trial sequence (or specific stages) tuned for agentic software |
| **Senior UX Writer Review** | "Run the senior UX writer review on this copy" | Verdict (ship / revise / blocking), findings by criterion, rewrite recommendations |

### Adding a new skill
1. Drop a `.md` file into `skills/`
2. Add a row to the table above and to `CLAUDE.md`

---

## 🔒 Always-Apply Rules (Auto-Loaded)

These files apply to **every** design and prototype in this project. Loaded automatically via `CLAUDE.md`.

### Lock files (zero-tolerance enforcement)
| File | What it locks |
|---|---|
| **`docs/design-system-lock.md`** | Fonts, logo, colors, components, asset handling |
| **`docs/typography-lock.md`** | Typography tokens, hierarchy, weights, forbidden behaviors |
| **`docs/layout-lock.md`** | Three-column page structure, backgrounds, spacing |

### UX copy reference (`docs/ux-copy/`)
Consult when writing or reviewing UX copy — auto-loaded for copy work.

| File | Purpose |
|---|---|
| `docs/ux-copy/training-guide.md` | Master UX copy reference — principles, microcopy, errors, structure |
| `docs/ux-copy/error-handling.md` | Error copy contract — taxonomy, severity, placement, retry rules |
| `docs/ux-copy/risk-analysis.md` | Risk framework — levels, signals, copy adjustments |
| `docs/ux-copy/lifecycle-phases.md` | Agentic lifecycle phases — onboarding, preview, enable, live, recovery |
| `docs/ux-copy/decision-vs-information.md` | Decision vs information copy rules |
| `docs/ux-copy/preview-testing-eval.md` | Preview/shadow/eval mode copy rules |
| `docs/ux-copy/trust-best-practices.md` | Trust-building checklist (general + AI-specific) |
| `docs/ux-copy/conversion-best-practices.md` | Conversion principles — primary action clarity |
| `docs/ux-copy/engagement-best-practices.md` | Engagement principles — progress, predictability |
| `docs/ux-copy/ai-agent-heuristics.md` | AI agent heuristics — agency, control, transparency |

### Design rules
| File | Purpose |
|---|---|
| **`principles.md`** | Foundational mindset — clarity, hierarchy, predictability |
| **`rules.md`** | Non-negotiables — 1 primary action, required states, fail conditions |
| **`patterns.md`** | Approved patterns — dashboard, form, table, AI surface, empty state |
| **`outputs.md`** | Output format rules — design generation, review, UX specs, AI feature design |
| **`ai-design.md`** | AI surface design — automation-first, trust architecture, state coverage |

### Single-file reference
**`design.md`** — consolidated everything in one place. Drop this into any Cursor project (or paste into Claude.ai) to bring the full system with you.

---

## 📚 Reference Docs

Reference material in `docs/` — read when you need detail.

| File | Contents |
|---|---|
| `docs/typography.md` | Full typography spec, all tokens, common patterns |
| `docs/components.md` | Component system overview (Komponents, KomponentsV2, KomponentsSmartV2) |
| `docs/AGENTS.md` | Engineering standards (TypeScript, testing, i18n, etc.) |

---

## 🎨 Tokens & Assets

| File / Folder | Contents |
|---|---|
| `colors_and_type.css` | All CSS variables — colors, type, spacing, radii, shadows, motion |
| `tokens/` | TypeScript design token definitions |
| `fonts/` | Inter variable font files (loaded locally) |
| `assets/` | Logos, Kusty, avatars — reference as-is, never recreate |
| `icons/` | Brand iconography |
| `ui_kits/agent_desktop/` | Hi-fi recreation of the Kustomer agent desktop UI |
| `preview/` | Visual preview cards for the design system |

---

## 📁 Project Structure

```
kustomer-design-system/
├── README.md              ← you are here
├── CLAUDE.md              ← project instructions (auto-loaded)
├── design.md              ← consolidated single-file reference
│
├── principles.md          ← always-apply rules
├── rules.md
├── patterns.md
├── outputs.md
├── ai-design.md
│
├── colors_and_type.css    ← all design tokens
│
├── docs/                  ← reference + lock files
│   ├── design-system-lock.md
│   ├── typography-lock.md
│   ├── layout-lock.md
│   ├── typography.md
│   ├── components.md
│   ├── AGENTS.md
│   └── ux-copy/           ← UX copy knowledge base
│       ├── training-guide.md
│       ├── error-handling.md
│       ├── risk-analysis.md
│       ├── lifecycle-phases.md
│       ├── decision-vs-information.md
│       ├── preview-testing-eval.md
│       ├── trust-best-practices.md
│       ├── conversion-best-practices.md
│       ├── engagement-best-practices.md
│       └── ai-agent-heuristics.md
│
├── skills/                ← runnable workflows
│   ├── ux-audit.md
│   ├── design-audit.md
│   ├── ia-design.md
│   ├── tour-copy.md
│   ├── email-copy.md
│   ├── trial-lifecycle-emails.md
│   └── senior-ux-writer-review.md
│
├── assets/                ← logos, Kusty, avatars
├── fonts/                 ← Inter variable font
├── icons/                 ← brand iconography
├── tokens/                ← TS design tokens
├── ui_kits/               ← hi-fi product mockups
└── preview/               ← design system preview cards
```

---

## 🤝 Working with this system

### In chat (Claude Design / Claude Code / Cursor)
- Just start designing — `CLAUDE.md` is auto-loaded
- All lock files apply automatically
- Invoke skills by name when you need them

### In Claude.ai (regular chat)
- Upload `design.md` (or attach the full folder) to a Project
- Reference it explicitly: *"Following the Kustomer Design System..."*
- For skills, paste the skill content into the chat

### Adding new rules or patterns
1. Decide: is it a **rule** (always-apply) or a **skill** (run on demand)?
   - Rule → governs how to design → add to `docs/` or root
   - Skill → produces a deliverable → add to `skills/`
2. Update `CLAUDE.md` so it's discoverable
3. Update this README so humans find it

---

## ❓ When in doubt

1. **Reuse the closest existing token** — never invent
2. **Check the relevant lock file** — they're zero-tolerance for a reason
3. **Ask before adding new patterns, sections, or layouts**

The system is intentionally strict. Consistency > novelty.
