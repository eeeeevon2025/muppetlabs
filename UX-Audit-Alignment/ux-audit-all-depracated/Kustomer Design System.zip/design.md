# Kustomer Design System — Master Reference

> **Single-file reference** for the Kustomer Design System. Use this as a `design.md` in any Cursor project (or as an Agent rule file) to ensure consistency and governance with Kustomer brand + product standards.
>
> **Version:** 2026 (typography refresh, 13px base scale)
> **Last updated:** May 5, 2026
> **Source of truth:** This file consolidates `README.md`, `rules.md`, `principles.md`, `patterns.md`, `docs/typography.md`, `docs/components.md`, `docs/design-system-lock.md`, `docs/AGENTS.md`, and `colors_and_type.css`.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Design Principles](#2-design-principles)
3. [Design Rules (Non-Negotiable)](#3-design-rules-non-negotiable)
4. [Design System Lock (Strict Enforcement)](#4-design-system-lock-strict-enforcement)
5. [Content Fundamentals (Voice & Tone)](#5-content-fundamentals-voice--tone)
6. [Color System](#6-color-system)
7. [Typography (2026)](#7-typography-2026)
8. [Layout System](#8-layout-system)
9. [Spacing, Radii, Shadows, Motion](#9-spacing-radii-shadows-motion)
10. [Iconography](#10-iconography)
11. [Component System](#11-component-system)
12. [Design Patterns](#12-design-patterns)
13. [Engineering Standards](#13-engineering-standards)
14. [Full CSS Tokens](#14-full-css-tokens)

---

## 1. Project Overview

**Kustomer** is the AI-powered customer service CRM that unifies customer conversations, data, history and context in a single timeline.

- **Product:** Customer service CRM built around the *customer*, not the ticket. Core surface is the **Timeline** — a chronological single-pane view of every email, chat, call and order for a given customer.
- **AI layer:** *Kustomer IQ* — AI Agents (automation, customer-facing) and AI Copilots (real-time rep assist: summarization, suggested replies, next-best-action).
- **Other surfaces:** Team Pulse (manager real-time dashboard), Queues & Routing, App Directory (Shopify, Salesforce, Stripe, etc.), Chat Widgets.
- **Audience:** Mid-market + enterprise CX teams. eCommerce-heavy.

### Brand Anchors
- **Sunshine Yellow** + **Periwinkle** + **Slate Green Ink** palette
- **Kusty** the smiling logomark
- Warmth, optimism, energy — but always calm and competent in product

---

## 2. Design Principles

### Structure > Aesthetics
Layout and hierarchy determine usability before visuals.

### Clarity Reduces Cognitive Load
Users should not need to interpret the interface.

### Predictability Builds Trust
Consistent patterns reduce friction and errors.

### Reduce Interaction Cost
Fewer steps = higher conversion.

### Progressive Disclosure
Show only what is necessary, reveal complexity on demand.

### Perceived Performance Matters
Interfaces should feel fast, not just be fast.

### Design for Real Use
Account for errors, interruptions, and edge cases.

---

## 3. Design Rules (Non-Negotiable)

### Core Structure
- Exactly **1 primary action** per screen
- Maximum **2 secondary actions** visible
- Primary action must be visually dominant

### Clarity
- All labels must be specific and outcome-based
- No vague CTAs ("Submit", "Continue")
- A new user must understand the screen in <5 seconds

### Hierarchy
- One focal point per screen
- No competing CTAs
- Visual weight must reflect importance

### Consistency
- No one-off components
- All UI must match design system tokens and patterns
- Same actions behave identically everywhere

### Interaction
- Every action must have immediate feedback
- No action should leave users uncertain of outcome
- Hover/click states must be visible

### States (Required)
Every UI must include:
- **Empty**
- **Loading**
- **Error**
- **Success**

Fail if any are missing.

### Responsiveness
- Must work on mobile, tablet, desktop
- No fixed layouts that break
- Touch targets ≥ 44×44px

### Accessibility
- Text must be readable (≥13px UI, never below 10px)
- Sufficient contrast (4.5:1 minimum body)
- Interactive elements identifiable

### Data Handling
- Must support empty + large datasets
- No overwhelming data dumps
- Use progressive disclosure

### Fail Conditions
A design **automatically fails** if:
- No clear primary action
- Missing states
- Multiple competing CTAs
- Requires explanation to understand
- Breaks on smaller screens

---

## 4. Design System Lock (Strict Enforcement)

**No interpretation, approximation, or creativity at the brand/system layer.**

### 4.1 Fonts (Non-Negotiable)
- ONLY use approved fonts:
  - Primary: **Inter** (variable, loaded locally from `fonts/Inter-VariableFont_opsz_wght.ttf`)
  - Display: **Fraunces** (substituting licensed Quincy CF)
  - Mono: **JetBrains Mono**
- Do NOT substitute fonts under any circumstance
- Do NOT infer or approximate fonts
- Do NOT use Roboto, system-ui, Neutral Std, or any other family
- Do NOT mix serif and sans-serif fonts in product UI

### 4.2 Logo Usage (Critical)
- ONLY use provided logo assets exactly as-is:
  - Wordmark: `assets/kustomer-logo-ink.svg` / `assets/kustomer-logo-white.png`
  - Logomark (Kusty): `assets/kusty-logomark.svg`
  - Avatars: `assets/kustomer-avatar-stone.png` / `assets/kustomer-avatar-white.png`
- Do NOT recreate, simplify, reinterpret SVG paths, or generate a new logo
- Always reference the original file directly

### 4.3 Colors (Token-Based Only)
- ONLY use defined color tokens (see [Section 6](#6-color-system))
- Full ramps: Gray, Blue, Purple, Red, Yellow, Green, Teal (steps 10–130)
- Do NOT approximate hex values, generate new shades, or adjust opacity arbitrarily

### 4.4 Components
- ONLY use existing components from the system
- Engineering: prefer `komponentsV2/` over native HTML or legacy `komponents/`
- Do NOT invent new components unless explicitly allowed
- If missing: compose from existing primitives

### 4.5 Typography (Zero-Tolerance)
Typography is a **governed system, not a creative area.** Full rules live in `docs/typography-lock.md` — same enforcement weight as the zero-tolerance policy in §4.7.

Summary of non-negotiables:
- ONLY use `--text-*` and `--leading-*` tokens — no hardcoded sizes or weights
- ONLY use **Inter** — no mixing serif/sans, no substitutions in product UI
- Heading hierarchy must be semantically correct: H1 > H2 > H3 > H4
- H1 appears **once per page** (page title only)
- Do NOT invent intermediate heading levels, new font sizes, or new font weights
- Do NOT use typography decoratively or to approximate hierarchy visually
- When uncertain: reuse the closest existing token; do not improvise
- Do NOT use legacy `--fs-*` tokens in new product UI

**Decision priority when there is conflict:**
1. Semantic correctness
2. Token consistency
3. Readability
4. Visual aesthetics — aesthetic improvement must never override semantic hierarchy

**Validation checklist — verify before finalizing any UI:**
- [ ] Only approved `--text-*` tokens are used
- [ ] Heading hierarchy is semantically correct (no skipped levels)
- [ ] No new font sizes were introduced
- [ ] No new font weights were introduced
- [ ] Body text is not used as a heading surrogate
- [ ] Metadata stays in Accent (`--text-accent`)
- [ ] Tags and supplemental data stay in Value (`--text-value`)
- [ ] KPI numbers use `--text-data`; KPI units use `--text-data-unit`
- [ ] The `html` base font-size system remains unchanged

❌ Fail if:
- Any font size or weight is not from the approved scale
- Heading levels are skipped or used for aesthetics
- A new typographic treatment is introduced without a token
- `--fs-*` legacy tokens appear in new product UI

→ **Full token tables, component notes, forbidden behaviors: `docs/typography-lock.md`**

### 4.6 Spacing
- Must follow defined scale (no arbitrary values)
- No "close enough" sizing

### 4.7 Asset Handling
All provided assets (SVG, icons, logos) must be **referenced, not interpreted**:
- Use exact files (e.g., `<img src="logo.svg">`)
- Do NOT rewrite SVG code
- Do NOT simplify or redraw assets

### 4.8 Zero-Tolerance Policy
A design FAILS immediately if:
- Fonts are incorrect
- Logo is modified or regenerated
- Colors are off-token
- Components are invented

---

## 5. Content Fundamentals (Voice & Tone)

**Overall vibe:** Warm + competent. Kustomer writes the way a thoughtful teammate talks — short sentences, no hedging, no jargon when a plain word exists. Product side leans *calm and technical*; brand side leans *optimistic and human*. **Every word earns its place.**

### Voice
- **Human first, tech second.** Declarative, benefit-forward.
- **Active voice, second person.** Default to "you" when addressing customers/admins. Never "the user".
- **Customer, not ticket.** Prefer *conversation*, *customer*, *journey* over *ticket*, *case*, *issue*.
- **Confident, not boastful.** Says what it does; doesn't beg for applause.

### Tone by Surface
| Surface | Tone | Example |
|---|---|---|
| Marketing hero | Optimistic, aspirational | "Make every conversation meaningful." |
| Product UI | Neutral, efficient | "Assigned to you · Replied 2m ago" |
| Empty states | Warm, encouraging | "Nothing in your queue. Nice work." |
| Errors | Matter-of-fact, owned | "We couldn't load that conversation. Try again?" |
| AI / Copilot | Helpful, deferential | "Suggested reply — review before sending." |

### Casing
- **Sentence case everywhere.** Buttons ("Save changes"), headers ("Team pulse"), menus ("New conversation"). Never Title Case in-product. Marketing H1s are sentence case too.
- Proper nouns capitalized: **Kustomer**, **Kusty**, **Kustomer IQ**, **AI Agents**, **AI Copilot**, **Timeline**, **Team Pulse**.

### Copy Rules
- **Short > long.** Primary action labels: 1–3 words. Headlines under ~10 words.
- **Contractions are welcome.** "Don't", "we'll", "you're".
- **Numbers.** Numerals always ("3 open conversations", not "three").
- **Oxford comma.** Yes.
- **Ellipses.** Only for truncation / typing indicators ("Loading…").

### Emoji
- **Not used in product UI.** Brand expresses warmth through Kusty, color, and type.
- **Sparingly in marketing/social.** Never in slide decks or in-app strings.

---

## 6. Color System

Three brand anchors — **Sunshine Yellow**, **Periwinkle**, **Slate Green Ink** — with a warm cream backdrop.

### 6.1 Brand Anchors
- **Sunshine Yellow** (`--yellow-60` / `#F4CC10`) — primary brand color, hero buttons, highlight fills. **Not** for body text or icons. Pair with Ink for any text on top.
- **Slate Green Ink** (`--gray-120` / `#1F242D`) — neutral dark; carries >90% of text, icon, and structural weight.
- **Periwinkle** (`--blue-40` / `#77A7FF`) — cool foil for secondary actions, info states, AI-assist surfaces. Deep variant (`--blue-70` / `#006CEC`) for links + focus.
- **Cream** (`--gray-15` / `#FAFBFE`) — default app canvas; warmer than white.
- **Coral** (`--red-50` / `#FF4C55`) — legacy nod, used in illustrations only.

### 6.2 Primitive Color Ramps

Each ramp runs **10 → 130** in 5-step increments. The **70 step** is the default rest state for that hue.

#### Gray (neutral)
```
--gray-10:  #FCFDFF    --gray-80:  #7C8596
--gray-15:  #FAFBFE    --gray-85:  #747D8E
--gray-20:  #F6F7FA    --gray-90:  #697182
--gray-25:  #F2F3F7    --gray-95:  #5F6675
--gray-30:  #E8EAF0    --gray-100: #545B68
--gray-35:  #E2E5ED    --gray-105: #4D535F
--gray-40:  #DCE0E9    --gray-110: #3F444F
--gray-45:  #D7DBE5    --gray-115: #2E333D
--gray-50:  #D1D6E1    --gray-120: #1F242D   /* primary text */
--gray-55:  #BBC2D2    --gray-125: #1C212B
--gray-60:  #B3BBCB    --gray-130: #161B25
--gray-65:  #A7B0C0    --gray-135: #121720
--gray-70:  #9099AB    --gray-140: #0D1119
--gray-75:  #8992A4    --gray-145: #080B11
                       --gray-150: #010307   /* Ink */
```

#### Blue (primary action)
```
--blue-10:  #EBF1FF    --blue-70:  #006CEC   /* default action */
--blue-15:  #DBE7FF    --blue-75:  #0165E4
--blue-20:  #CBDCFF    --blue-80:  #005BD8
--blue-25:  #BBD1FF    --blue-85:  #0152CA
--blue-30:  #A3C1FF    --blue-90:  #0047B9
--blue-35:  #93B8FF    --blue-95:  #0140AE
--blue-40:  #77A7FF    --blue-100: #00349A
--blue-45:  #5C9AFF    --blue-105: #0E3280
--blue-50:  #3F8CFF    --blue-110: #0D2873
--blue-55:  #2886FF    --blue-115: #11225E
--blue-60:  #007CFF    --blue-120: #00105B
--blue-65:  #0175F6    --blue-125: #010C4B
                       --blue-130: #00022C
```

#### Purple
```
--purple-10:  #FAF4FF    --purple-70:  #B31DF0
--purple-15:  #F5EBFD    --purple-75:  #A821E1
--purple-20:  #EBD2FF    --purple-80:  #9A24CD
--purple-25:  #E7C7FF    --purple-85:  #8E24BD
--purple-30:  #DDAFFF    --purple-90:  #7B22A4
--purple-35:  #D8A6FA    --purple-95:  #6E2092
--purple-40:  #D189FF    --purple-100: #5E1D7D
--purple-45:  #CD7DFC    --purple-105: #521A6D
--purple-50:  #C65DFF    --purple-110: #43165A
--purple-55:  #C455FB    --purple-115: #38124C
--purple-60:  #C139FF    --purple-120: #2B0D3B
--purple-65:  #BA34F4    --purple-125: #210A2E
                         --purple-130: #0E0316
```

#### Red (danger)
```
--red-10:  #FFF4F4    --red-70:  #E21325
--red-15:  #FFE8E9    --red-75:  #CD1D2B
--red-20:  #FFD0D2    --red-80:  #C41923
--red-25:  #FFC3C5    --red-85:  #B01921
--red-30:  #FFAAAD    --red-90:  #9E181E
--red-35:  #FF9B9F    --red-95:  #8E171C
--red-40:  #FF8186    --red-100: #7A1518
--red-45:  #FF6F75    --red-105: #6B1315
--red-50:  #FF4C55    --red-110: #590F11
--red-55:  #F53F4E    --red-115: #490C0D
--red-60:  #FF0526    --red-120: #3A0909
--red-65:  #EB132B    --red-125: #29070F
                      --red-130: #160202
```

#### Yellow (warning + brand)
```
--yellow-10:  #FFFEF2    --yellow-70:  #F1C91E
--yellow-15:  #FFFDE5    --yellow-75:  #E7C11F
--yellow-20:  #FEFAD2    --yellow-80:  #DBB71E
--yellow-25:  #FEF8C3    --yellow-85:  #CCAB1E
--yellow-30:  #FDF4B2    --yellow-90:  #AF931D
--yellow-35:  #FDF1A4    --yellow-95:  #9B831D
--yellow-40:  #FCED92    --yellow-100: #826F1C
--yellow-45:  #FBE775    --yellow-105: #79681D
--yellow-50:  #F9DF53    --yellow-110: #6C5E1C
--yellow-55:  #F7D530    --yellow-115: #584E1C
--yellow-60:  #F4CC10    --yellow-120: #403A1B
--yellow-65:  #F3CB18    --yellow-125: #2E261A
                         --yellow-130: #1F1F1A
```

#### Green (success)
```
--green-10:  #EAFBED    --green-70:  #008435
--green-15:  #DBF5E0    --green-75:  #017C32
--green-20:  #91F0A5    --green-80:  #00732E
--green-25:  #87E79C    --green-85:  #016A2A
--green-30:  #75D58A    --green-90:  #005D24
--green-35:  #6CCB81    --green-95:  #015520
--green-40:  #5BBA71    --green-100: #00481A
--green-45:  #4FB267    --green-105: #013F16
--green-50:  #35A153    --green-110: #003411
--green-55:  #209C4B    --green-115: #012B0D
--green-60:  #00943D    --green-120: #002108
--green-65:  #018E3A    --green-125: #011606
                        --green-130: #000A02
```

#### Teal (chat / info-secondary)
```
--teal-10:  #EAFBFA    --teal-70:  #00C9E0
--teal-15:  #DEF7FA    --teal-75:  #01C1D7
--teal-20:  #B9EEF9    --teal-80:  #00B6CC
--teal-25:  #9EEEFA    --teal-85:  #01A8BC
--teal-30:  #8FF4FF    --teal-90:  #0096A8
--teal-35:  #7EF2FF    --teal-95:  #018B9C
--teal-40:  #66EFFF    --teal-100: #007B8A
--teal-45:  #50E9FA    --teal-105: #016E7C
--teal-50:  #29E9FF    --teal-110: #005966
--teal-55:  #1AE2F9    --teal-115: #014C58
--teal-60:  #00E5FF    --teal-120: #003D47
--teal-65:  #01DCF5    --teal-125: #012F37
                       --teal-130: #001D24
```

### 6.3 Channel Colors
Per-channel brand stamps for conversation chips, timeline icons, routing badges:

```
--channel-chat:              var(--teal-90)    /* #0096A8 */
--channel-email:             var(--blue-70)
--channel-sms:               var(--green-50)
--channel-voice:             var(--red-40)
--channel-note:              var(--yellow-70)
--channel-forward:           var(--yellow-50)
--channel-empty-convo:       var(--gray-70)
--channel-multichannel:      var(--purple-70)
--channel-facebook:          #7747FD
--channel-facebook-wallpost: #0082FF
--channel-instagram-dm:      #B31DF0
--channel-instagram-comment: #CD486B
--channel-twitter:           #00AEF3
--channel-twitter-dm:        #27C8CE
--channel-whatsapp:          #00AC4F
--channel-zipwhip:           #FB713F
--channel-gmail:             #D44638
--channel-slack:             #3235C5
--channel-form:              #007CFF
--channel-portal:            #F4A11A
--channel-tiktok-shop:       #FE2858
--channel-other-apps:        var(--gray-50)
```

### 6.4 Semantic Tokens (Light Theme)

Product UI should consume these — primitives are the source of truth, but components reference semantic tokens so dark-mode swaps work cleanly.

#### Backgrounds
```
--bg-primary:           #FFFFFF
--bg-primary-inverse:   var(--gray-150)
--bg-primary-hover:     var(--gray-20)
--bg-primary-active:    var(--gray-30)
--bg-secondary:         var(--gray-20)
--bg-secondary-hover:   var(--gray-30)
--bg-tertiary:          var(--gray-30)
--bg-tertiary-hover:    var(--gray-40)
```

#### Text
```
--text-primary:         var(--gray-120)   /* #1F242D */
--text-primary-inverse: var(--gray-10)
--text-secondary:       var(--gray-100)   /* #545B68 */
--text-secondary-hover: var(--gray-110)
--text-hint:            var(--blue-70)
--text-link:            var(--blue-70)    /* #006CEC */
--text-link-hover:      var(--blue-90)
--text-info:            var(--blue-70)
```

#### Icons
```
--icon-primary:          var(--gray-120)
--icon-primary-hover:    var(--gray-70)
--icon-primary-disabled: var(--gray-60)
--icon-active:           var(--blue-70)
```

#### Borders
```
--border-primary: var(--gray-40)
```

#### Forms
```
--form-border:                 var(--gray-40)
--form-border-hover:           var(--blue-70)
--form-border-active:          var(--blue-70)
--form-bubble-bg:              var(--gray-30)
--form-bubble-multi-bg:        var(--gray-50)
--form-bubble-multi-bg-hover:  var(--gray-60)
--form-bg-disabled:            var(--gray-30)
--form-text-disabled:          var(--gray-90)
--form-text-placeholder:       var(--gray-70)
```

#### Toggles
```
--toggle-unselected-marker:        #FFFFFF
--toggle-unselected-bg:            var(--gray-80)
--toggle-unselected-bg-hover:      var(--gray-90)
--toggle-unselected-bg-disabled:   var(--gray-30)
--toggle-selected-marker:          #FFFFFF
--toggle-selected-bg:              var(--blue-70)
--toggle-selected-bg-hover:        var(--blue-80)
--toggle-selected-bg-disabled:     var(--blue-40)
```

#### Controls (Radio / Checkbox)
```
--control-unselected-border:       var(--gray-70)
--control-unselected-border-hover: var(--blue-70)
--control-unselected-bg:           #FFFFFF
--control-unselected-bg-hover:     var(--blue-10)
--control-selected-marker:         #FFFFFF
--control-selected-border:         var(--blue-70)
--control-selected-border-hover:   var(--blue-80)
--control-selected-bg:             var(--blue-70)
--control-selected-bg-hover:       var(--blue-80)
```

#### Semantic State
```
--color-success:    var(--green-70)    --color-success-bg: var(--green-15)
--color-warning:    var(--yellow-70)   --color-warning-bg: var(--yellow-20)
--color-danger:     var(--red-70)      --color-danger-bg:  var(--red-15)
--color-info:       var(--blue-70)     --color-info-bg:    var(--blue-15)
```

#### Backwards-Compat Aliases
```
--fg-1: var(--text-primary)         --bg-app:     var(--gray-15)
--fg-2: var(--text-secondary)       --bg-surface: #FFFFFF
--fg-3: var(--gray-80)              --bg-sunken:  var(--gray-25)
--fg-4: var(--gray-60)              --bg-inverse: var(--gray-150)
--fg-on-yellow: var(--gray-120)     --bg-brand:   var(--yellow-60)
--fg-on-ink:    #FFFFFF

--border-1:      var(--gray-30)
--border-2:      var(--gray-40)
--border-strong: var(--gray-80)
--border-focus:  var(--blue-70)
```

### 6.5 Color Rules
- **Never** use `--gray-80` or lighter for primary body text (fails WCAG AA)
- Minimum contrast: **4.5:1** for body, **3:1** for large text (18px+)
- Use color ramps at **70+** for dark text, **30 and below** for light backgrounds
- No new gradients; gentle Ink → Slate gradients OK on hero CTA backdrops only

---

## 7. Typography (2026)

> **Typography is a governed system, not a creative area.** Use the exact tokens below. Do not invent new hierarchy, sizes, weights, or spacing patterns.

### 7.1 Core Principles
- Use **Inter** only for product UI
- Keep typography **token-driven** and **semantic**
- Prefer **consistency over visual novelty**
- Do not visually approximate hierarchy
- Do not create one-off typography styles for a single screen or component
- When uncertain, reuse an existing token instead of inventing a new one

### 7.2 Font Families

```css
--font-display: "Fraunces", "Quincy CF", "Cooper Light", Georgia, serif;
--font-sans:    "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
--font-mono:    "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
```

#### Primary: Inter (UI & Product)
- Variable font (weight 100–900, optical sizing 8–144px)
- Used weights: 400 Regular, 500 Medium, 600 Semibold, 700 Bold
- Loaded locally from `fonts/Inter-VariableFont_opsz_wght.ttf` + italic variant

#### Secondary: Fraunces (Display / Brand — marketing only)
- High-contrast serif for hero headlines and narrative moments
- Weights 400, 500, 600, 700; used at 28px+ with `clamp()` for responsive scaling
- Substituting licensed Quincy CF until those files are provided

#### Tertiary: JetBrains Mono (Code)
- Monospace for code, API responses, IDs — weights 400, 500

### 7.3 Typography Behavior Rules
- Headings must follow semantic hierarchy: **H1 > H2 > H3 > H4**
- Use **H1 only for page titles** — once per page, never more
- Use **H2** for card and section headers
- Use **H3** for group and layer headers
- Use **H4** for labels that precede forms and controls
- Use **Label** for form labels only
- Use **Body** for all body copy and descriptions
- Use **Value** for tags and supplemental data
- Use **Accent** for timestamps and metadata
- Use **Data Value** for KPI numbers in reporting
- Use **Data Value Unit** for KPI unit labels in reporting

### 7.4 Forbidden Behaviors
Do not:
- Invent intermediate heading levels
- Use font sizes not listed in this document
- Use font weights not listed in this document
- Change hierarchy based on aesthetics alone
- Use typography to add decoration
- Mix serif and sans-serif fonts in product UI
- Center-align long-form body content unless a component explicitly requires it
- Use ALL CAPS headings unless explicitly defined elsewhere
- Treat visual size as a substitute for semantic role
- Create custom spacing for a single component when an existing token can be used

### 7.5 Approved Font Scale

**Base system:** 13px at the S breakpoint.
**Scale model:** Hybrid — Minor Third (1.2×) for headings, Major Second (1.125×) for body and below.

#### Font size tokens
| Token | REM | XXXS (10px) | XXS (11px) | XS (12px) | S (13px) | M (14px) | L (15px) | Change | Weight | Use case |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|
| H1 | 1.692 | 16.92 | 18.61 | 20.30 | **22.00** | 23.69 | 25.38 | +2px | 700 Bold | Page title — one per page |
| H2 | 1.408 | 14.08 | 15.49 | 16.90 | **18.30** | 19.71 | 21.12 | +0.3px | 700 Bold | Card / section header |
| H3 | 1.177 | 11.77 | 12.95 | 14.12 | **15.30** | 16.48 | 17.65 | -0.7px | 700 Bold | Group / layer header |
| H4 | 1.077 | 10.77 | 11.85 | 12.92 | **14.00** | 15.08 | 16.15 | — | 700 Bold | Precedes forms and controls |
| Label | 1.000 | 10.00 | 11.00 | 12.00 | **13.00** | 14.00 | 15.00 | -1px | 600 Semibold | Form labels — input labels |
| Body | 1.000 | 10.00 | 11.00 | 12.00 | **13.00** | 14.00 | 15.00 | — | 400 Regular | All body copy and descriptions |
| Value | 0.889 | 8.89 | 9.78 | 10.67 | **11.56** | 12.44 | 13.33 | -1.44px | 600 Semibold | Tags and supplemental data |
| Accent | 0.790 | 7.90 | 8.69 | 9.48 | **10.27** | 11.06 | 11.85 | -1.73px | 400 Regular | Timestamps and metadata |
| Data Value | 2.615 | 26.15 | 28.77 | 31.38 | **34.00** | 36.62 | 39.23 | — | 700 Bold | KPI metric number in reporting |
| Data Value Unit | 1.615 | 16.15 | 17.77 | 19.38 | **21.00** | 22.62 | 24.23 | — | 700 Bold | KPI unit label in reporting |

#### Line height tokens
| Token | Multiplier | XXXS | XXS | XS | S (13px) | M (14px) | L (15px) |
|---|---:|---:|---:|---:|---:|---:|---:|
| H1 | 1.64 | 27.75 | 30.52 | 33.30 | **36.08** | 38.85 | 41.63 |
| H2 | 1.22 | 17.18 | 18.90 | 20.62 | **22.33** | 24.05 | 25.77 |
| H3 | 1.25 | 14.71 | 16.19 | 17.65 | **19.13** | 20.60 | 22.06 |
| H4 | 1.43 | 15.40 | 16.95 | 18.48 | **20.02** | 21.56 | 23.10 |
| Label | 1.43 | 14.30 | 15.73 | 17.16 | **18.59** | 20.02 | 21.45 |
| Body | 1.43 | 14.30 | 15.73 | 17.16 | **18.59** | 20.02 | 21.45 |
| Value | 1.38 | 12.27 | 13.50 | 14.72 | **15.95** | 17.17 | 18.40 |
| Accent | 1.33 | 10.51 | 11.56 | 12.61 | **13.66** | 14.71 | 15.76 |
| Data Value | 1.24 | 32.43 | 35.67 | 38.91 | **42.16** | 45.41 | 48.64 |
| Data Value Unit | 1.24 | 20.03 | 22.03 | 24.03 | **26.04** | 28.05 | 30.04 |

### 7.6 CSS Tokens

```css
--text-h1:         1.692rem;
--text-h2:         1.408rem;
--text-h3:         1.177rem;
--text-h4:         1.077rem;
--text-label:      1.000rem;
--text-body:       1.000rem;
--text-value:      0.889rem;
--text-accent:     0.790rem;
--text-data:       2.615rem;
--text-data-unit:  1.615rem;

--leading-h1:        1.64;
--leading-h2:        1.22;
--leading-h3:        1.25;
--leading-h4:        1.43;
--leading-label:     1.43;
--leading-body:      1.43;
--leading-value:     1.38;
--leading-accent:    1.33;
--leading-data:      1.24;
--leading-data-unit: 1.24;
```

### 7.7 Letter Spacing

```css
--tr-tight:  -0.02em;   /* Display headlines */
--tr-snug:   -0.01em;   /* Headings, subtle tightening */
--tr-normal:  0;        /* Body, default */
--tr-wide:    0.04em;   /* Eyebrows, labels for emphasis */
```

### 7.8 Component Notes

#### Customer panel field labels
- `font-weight: 500` (medium) + `color: var(--text-secondary)`

#### Customer panel filled values
- `font-weight: 600` (semibold) + `color: var(--text-primary)`

#### Customer panel empty placeholders
- `font-weight: 400` (normal) + `color: var(--fg-3)` + `font-style: italic`

#### Customer panel empty text fields
- Show a **plus icon** before placeholder text

#### Customer panel empty date fields
- Show a **calendar-plus icon** before placeholder text

### 7.9 Common Patterns

**Page Title + Intro**
```html
<h1 class="k-h1">Business Rules</h1>
<p class="k-body">Define automated workflows and routing logic.</p>
```

**Card Header**
```html
<h2 class="k-h2">Routing Configuration</h2>
```

**Group Header**
```html
<h3 class="k-h3">Assignment rules</h3>
```

**Form Section**
```html
<h4 class="k-h4">Condition group</h4>
<label><span class="k-label">Queue name</span><input type="text" /></label>
```

**Metadata / Timestamp**
```html
<p class="k-accent">customer@example.com · 2 min ago</p>
```

**Tag / Supplemental Data**
```html
<span class="k-value">Support - Tier 1</span>
```

**KPI Metric**
```html
<div class="k-data">42,891</div>
<div class="k-data-unit">conversations</div>
```

### 7.10 Implementation Rules
- Do not change the `html` font-size system
- Continue using the existing `--font-size-base` / `--font-scale` system
- Reuse approved tokens; do not introduce alternate sizing scales

### 7.11 Decision Priority
When there is conflict, apply in this order:
1. **Semantic correctness**
2. **Token consistency**
3. **Readability**
4. **Visual aesthetics**

Aesthetic improvement must never override semantic hierarchy.

### 7.12 Recommended Default Mapping
| Token | Default use |
|---|---|
| H1 | Page title |
| H2 | Section header |
| H3 | Subsection or group header |
| H4 | Form / control lead-in |
| Label | Form label |
| Body | Paragraph, description, helper copy |
| Value | Chips, tags, supplemental values |
| Accent | Timestamps, metadata, low-emphasis details |
| Data Value | KPI number |
| Data Value Unit | KPI unit label |

### 7.13 Validation Checklist
Before finalizing any UI, verify:
- [ ] Only approved `--text-*` tokens are used
- [ ] Heading hierarchy is semantically correct (no skipped levels)
- [ ] No new font sizes were introduced
- [ ] No new font weights were introduced
- [ ] Body text is not used as a heading surrogate
- [ ] Metadata stays in Accent (`--text-accent`)
- [ ] Tags and supplemental data stay in Value (`--text-value`)
- [ ] KPI numbers use `--text-data`; KPI units use `--text-data-unit`
- [ ] The `html` base font-size system remains unchanged

### 7.14 Final Rule
If a new use case does not fit these rules cleanly, do not improvise a new typographic treatment. Reuse the closest approved token or escalate the need for a new token.

---

## 8. Layout System

> **Layout is a governed system — not a creative area.** Every page must follow the fixed structure below. Do not invent unique layouts per page, do not use marketing-style spacing, and do not override `typography-lock.md` for aesthetic reasons.

### 8.1 Page Structure

Every page uses this fixed three-column structure:

```
┌─────────────┬──────────────────────────┬──────────────────┐
│ Left        │ Main Content             │ Right Panel      │
│ Sidebar Nav │ (primary workspace)      │ (optional)       │
│ fixed width │ flexible width           │ contextual info  │
└─────────────┴──────────────────────────┴──────────────────┘
```

- **Left sidebar:** Fixed width, slightly darker neutral background than main, contains navigation
- **Main content:** Flexible width, primary workspace — all primary actions live here
- **Right panel:** Optional, secondary contextual information (customer card, insights, AI Copilot)
- Subtle borders/dividers between columns — no floating or overlapping panels

### 8.2 Background Colors

```
App background:      #F7F8FA
Primary surfaces:    #FFFFFF  (cards, panels)
Sidebar background:  slightly darker neutral than app background
Borders/dividers:    very subtle gray (--gray-30 / --border-1)
```

- No pure black backgrounds
- No gradients unless explicitly defined in the token system

### 8.3 Visual Style
- **Minimal enterprise SaaS aesthetic** — readability-first, dense but scannable
- Subtle rounded corners (`--radius-md` / `--radius-lg`)
- Low-contrast borders (`--border-1` / `--border-2`)
- No decorative visual effects, no oversized whitespace, no hero spacing

### 8.4 Spacing
- Use the defined spacing scale — no arbitrary values
- Maintain vertical rhythm throughout
- Align all components to a grid
- Avoid oversized whitespace or hero-style padding

### 8.5 Component Behavior
- **Cards:** subtle border or `--shadow-xs` elevation — no heavy shadows
- **Tags and badges:** compact, use `--text-value` token
- **Tables:** prioritize readability — sorting + filtering required if dataset > 10 items
- **Right panels:** always feel secondary to the primary workflow

### 8.6 Typography in Layout
All typography within layouts strictly follows `docs/typography-lock.md`:
- **H1** — page title only, once per page
- **H2** — section headers
- **H3** — card titles and grouped content headings
- **Body** — default paragraph and description text
- **Accent/Caption** — metadata, timestamps, helper text
- Do not invent custom font sizes, mix weights randomly, or visually approximate hierarchy

### 8.7 Forbidden
- ❌ Marketing-style layouts or hero spacing
- ❌ Oversized typography
- ❌ Decorative gradients or visual effects
- ❌ Unique layouts invented per page
- ❌ Floating or overlapping panels
- ❌ Overriding `typography-lock.md` for aesthetic reasons

---

## 9. Spacing, Radii, Shadows, Motion

### 9.1 Spacing (4px base)
```css
--space-0:  0
--space-1:  4px
--space-2:  8px
--space-3:  12px
--space-4:  16px
--space-5:  20px
--space-6:  24px
--space-8:  32px
--space-10: 40px
--space-12: 48px
--space-16: 64px
--space-20: 80px
--space-24: 96px
```

**Rules:**
- Product density: 12–16px vertical rhythm inside panels; 24–32px between major sections
- Marketing: 96–160px section padding; 12-column grid, generous gutters
- Touch targets ≥ 44×44px

### 9.2 Radii
```css
--radius-xs:  4px       /* Inputs, small chips */
--radius-sm:  8px       /* Inputs */
--radius-md:  12px      /* UI cards, buttons (in product) */
--radius-lg:  16px      /* Large cards */
--radius-xl:  24px
--radius-2xl: 32px
--radius-pill: 999px    /* Marketing CTAs, pills */
--radius-squircle: 32% / 32%   /* Kusty mark, illustrations */
```

**Rules:**
- UI cards: 12–16px (`--radius-md` / `--radius-lg`)
- Buttons: pill (999px) for marketing CTAs; 12px in product chrome
- Inputs: 8px
- Avatars + app-directory logos: ~22% of width (squircle, per Kustomer logo spec)

### 9.3 Shadows
```css
--shadow-xs: 0 1px 2px rgba(31, 42, 46, 0.06)
--shadow-sm: 0 2px 6px rgba(31, 42, 46, 0.08)
--shadow-md: 0 8px 24px rgba(31, 42, 46, 0.10)
--shadow-lg: 0 20px 48px rgba(31, 42, 46, 0.14)
--shadow-xl: 0 32px 80px rgba(31, 42, 46, 0.18)
--shadow-inset-hair: inset 0 0 0 1px rgba(31, 42, 46, 0.08)
```

**Rules:**
- Product surfaces: soft, single-layer shadows (8px blur, 10% ink) over a 1px inner hairline
- No stacked drop shadows. No neumorphism.
- Marketing hero cards: warmer, larger shadow (24–48px blur at 14%)
- Modal scrims: 40% ink. Sticky headers over scroll: 80% white with 12px backdrop-blur. No glassmorphism.

### 9.4 Motion
```css
--ease-standard: cubic-bezier(0.2, 0.7, 0.2, 1)    /* most UI */
--ease-out:      cubic-bezier(0.16, 1, 0.3, 1)     /* enters/reveals */
--ease-in:       cubic-bezier(0.5, 0, 0.75, 0)
--dur-1: 120ms
--dur-2: 180ms
--dur-3: 260ms
--dur-4: 400ms     /* page-level reveals */
```

**Rules:**
- No bounces
- Hover: slight darken (~6–8% toward ink) + 1px lift on cards
- Press: 2% shrink **OR** color shift to "deep" variant — never both
- Focus: 2px periwinkle ring, offset 2px
- Kusty can blink/bob in illustrations — never in agent UI chrome

---

## 10. Iconography

Kustomer uses **Lucide** as a close match to in-product icons (clean geometric feel, friendly geometry).

- **Delivery:** `https://unpkg.com/lucide@latest` for React/JS, or inline SVG copies
- **Sizing:** 16px (inline w/ 14px text), 20px (default UI), 24px (toolbar/nav), 32px (feature tiles)
- **Stroke:** 1.75px standard. Icons inherit `currentColor` so they pick up text color tokens
- **Fill vs outline:** Outline default. Solid fills only for active-nav states and status dots
- **Emoji:** Never used as icons. Brand expresses warmth through Kusty + color.
- **Unicode symbols:** Sparingly for ephemeral marks — `→`, `·`, `•`, `—`. Prefer an icon when available.

### Brand Marks
- `kusty-logomark.svg` — the mascot
- `kustomer-logo-ink.svg` / `.png` — wordmark in Ink
- `kustomer-logo-white.png` — white-on-dark variant
- `kustomer-avatar-stone.png` / `kustomer-avatar-white.png` — pre-rounded squircle versions

---

## 11. Component System

### 10.1 Component Hierarchy
1. **Komponents (Legacy)** — `src/komponents/`. Being phased out.
2. **KomponentsV2** — `src/komponentsV2/`. **Preferred** for all new work. TypeScript, well-typed.
3. **KomponentsSmartV2** — `src/komponentsSmartV2/`. Smart components with business logic + Redux.

### 10.2 Use komponentsV2 over Native HTML
| Instead of | Use |
|------------|-----|
| `<button>` | `ButtonPrimary`, `ButtonSecondary`, `IconButton` |
| `<input>` | `TextInput`, `Select`, `Dropdown` |
| `<h1>`–`<h6>` | `HeaderText` with appropriate `type` |
| `<span>` for text | `Text` component |

**Acceptable native HTML:**
- Layout divs with className
- Semantic HTML (`<section>`, `<article>`, `<nav>`)
- Third-party library wrappers

### 10.3 Component Categories
- **Form:** Input fields, Select dropdowns, Date pickers, File uploaders, Form validation
- **Layout:** Grids, Cards, Modals, Tabs, Navigation
- **Data Display:** Tables, Lists, Charts, Status indicators, Avatars
- **Interactive:** Buttons, Dropdowns, Popovers, Tooltips, Drag-and-drop

### 10.4 Component Structure Convention
```typescript
import * as React from 'react';
import styles from './componentName.scss';
import { ComponentNameProps } from './types';

const ComponentName: React.FC<ComponentNameProps> = ({ prop1, prop2 }) => {
  return (
    <div className={styles.container}>
      {/* Component JSX */}
    </div>
  );
};

export default ComponentName;
```

### 10.5 Component Best Practices
- Keep components in their respective system directories
- File naming: `ComponentName.tsx`
- Tests in `__tests__/` subdirectory
- Styles in `componentName.scss` (CSS Modules; semantic class names)
- Use interfaces for props; mark optional with `?`
- Use `React.FC` type for functional components
- Export prop interfaces when they might be reused
- Test coverage: **80% minimum** (98%+ enforced for many areas)

---

## 12. Design Patterns

### 11.1 Dashboard Pattern
- **Top:** System status (most important)
- **Middle:** Key metrics (3–5 max)
- **Bottom:** Detailed data / controls

**Fail if:** more than one primary question is answered; metrics overwhelm the user.

### 11.2 Form Pattern
**Structure:**
1. Purpose (what this does)
2. Inputs (minimal fields)
3. Defaults (pre-filled where possible)
4. Action (single primary CTA)

**Rules:** Minimize inputs. Use autofill wherever possible. Group logically.

### 11.3 Table Pattern
- **Default:** summarized view
- **Expand:** detailed data
- **Must include:** Sorting, Filtering (if dataset > 10 items)

**Fail if:** Raw data overload; no way to refine results.

### 11.4 AI Surface Pattern
**Types:**
1. **Ambient** (no UI)
2. **Suggestive** (inline suggestions)
3. **Configurable** (rules + setup)
4. **Agentic** (approval + monitoring)

**Rules:**
- Default to automation
- UI is fallback, not primary
- Always show scope before execution
- Always allow override

**Fail if:** User does work AI could do; no preview before activation; scope is unclear.

### 11.5 Empty State Pattern
**Must include:**
- What will appear
- When it appears
- One clear next step

**Avoid:** "No data yet"

### 11.6 Layout Patterns
- **Agent desktop:** fixed left rail (collapsed icons or expanded labels), center conversation timeline, right context panel (customer card, orders, AI Copilot). Nothing floats; everything docks.
- **Marketing:** centered, max-width ~1280px, sections full-bleed background with inner container.

### 11.7 Imagery
- Warm, bright, high-key. Real people (CX agents + shoppers), not stock-y handshake tropes.
- Color grading skews warm — touch of yellow + cream cast.
- When photos aren't available: tile brand shapes (Kusty squircle, wordmark cutouts) at large scale on color blocks.

---

## 13. Engineering Standards

### 12.1 Tech Stack
- **React 18** with functional components and hooks
- **TypeScript** for type safety (migrating from JavaScript)
- **Redux** with thunks for state management
- **SCSS** with CSS modules for styling
- **Jest** + React Testing Library for unit/integration
- **Playwright** for E2E
- **LaunchDarkly** for feature flags
- **react-intl** for internationalization

### 12.2 Always Read Before Editing
- Read current file state before changes
- Understand existing patterns before modifying
- Check related files and tests

### 12.3 Minimal Changes
- Keep edits focused and small
- Don't refactor unrelated code
- Don't add comments about moved/removed functionality
- Preserve existing patterns

### 12.4 Internationalization (CRITICAL)
All user-facing text MUST be internationalized:

```tsx
// Correct
<ButtonPrimary>
  <FormattedMessage defaultMessage="Submit" />
</ButtonPrimary>

// For props
placeholder={intl.formatMessage({ defaultMessage: 'Enter name' })}

// Incorrect — hardcoded strings
<ButtonPrimary>Submit</ButtonPrimary>
```

### 12.5 Import Ordering (ESLint enforced)
1. React and external packages
2. Absolute imports (`types/`, `components/`, `utils/`)
3. Relative imports
4. Style imports

### 12.6 Stable References (Prevent Rerenders)
**Never pass inline `() => {}`, `[]`, or `{}` as JSX props or to setState.** Each creates a new reference on every render, breaking `React.memo`, `useMemo`, `useCallback`.

```typescript
import { DEFAULT_ARRAY, DEFAULT_OBJECT, DEFAULT_FUNCTION } from 'constants/defaults';

// Correct
<Table onRowClick={DEFAULT_FUNCTION} />
<Select options={DEFAULT_ARRAY} />
<Component config={DEFAULT_OBJECT} />
<Component items={data || DEFAULT_ARRAY} />

// Incorrect
<Table onRowClick={() => {}} />
<Select options={[]} />
```

**Safe to leave unchanged:** iteration-only `(data || []).map(...)`, `useEffect` bodies, Redux selectors/reducers, utility functions.

### 12.7 TypeScript Standards
- Never use `any` — use `unknown` or proper types
- Check `src/types/resources/` for existing types before creating new ones
- Use `ConnectedProps<typeof connector>` for Redux-connected components
- Let TypeScript infer return types when obvious

### 12.8 Testing Standards
- Place tests in `__tests__/` directory next to tested file
- Use `.spec.js` extension (prefer JavaScript for tests)
- Use `renderWithStore` for connected components
- Never mock `intl` or `FormattedMessage`
- Never wrap `userEvent` in `act()` — it's already handled

```javascript
import { renderWithStore, screen, user, waitFor } from 'helpers/test/rtl-renderer';

describe('MyComponent', () => {
  it('should handle interaction', async () => {
    await renderWithStore(<MyComponent />);
    await user.click(screen.getByRole('button', { name: 'Submit' }));
    await waitFor(() => {
      expect(screen.getByText('Success')).toBeInTheDocument();
    });
  });
});
```

### 12.9 Test Failure Policy
**ALL unit tests pass 100% on master.** If a test fails after your change, your change caused it. Do not report failures as "pre-existing." Investigate, fix, verify ALL tests pass before complete.

### 12.10 Common Mistakes to Avoid
- ❌ Editing without reading current file state
- ❌ Making overly broad changes
- ❌ Using native HTML when komponents exist
- ❌ Hardcoding UI strings without i18n
- ❌ Using `any` types
- ❌ Skipping test updates when modifying code
- ❌ Wrapping `userEvent` in `act()`
- ❌ Adding dependencies without checking existing implementations
- ❌ Combining migrations with feature changes (use separate PRs)
- ❌ Reporting test failures as "pre-existing"

### 12.11 Feature Flags (LaunchDarkly)
```tsx
import { useFeatureFlag } from 'hooks/useFeatureFlag';

const MyComponent = () => {
  const isFeatureEnabled = useFeatureFlag('my-feature-flag');
  return isFeatureEnabled ? <NewFeature /> : <OldFeature />;
};
```

### 12.12 Logging
Use the `log` module instead of `console.log`:

```javascript
import log from 'log';

log.info('Debug info', { context: 'data' });
log.warn('Warning message');
log.error('Error message');
log.exception(new Error('Exception'), { additionalInfo: 'data' });
```

### 12.13 Repository Structure
```
src/
├── api/                # API integration and services
├── components/         # Reusable React components
├── komponents/         # Legacy component system
├── komponentsV2/       # New component system (prefer this)
├── komponentsSmartV2/  # Smart components with business logic
├── views/              # Page-level components
├── store/              # Redux store configuration
├── routes/             # Application routing
├── styles/             # Global styles and SCSS
├── i18n/               # Internationalization
├── utils/              # Utility functions
├── hooks/              # Custom React hooks
├── services/           # Service layer implementations
└── types/              # TypeScript type definitions
    └── resources/      # Global resource types
```

### 12.14 Common Commands
| Command | Description |
|---------|-------------|
| `yarn start:staging` | Start dev server pointing to staging |
| `yarn test` | Run unit tests |
| `yarn test:changed` | Run tests for changed files |
| `yarn lint` | Run all linters |
| `yarn langs` | Build i18n files (run after changing strings) |
| `yarn type-check` | Run TypeScript type checking |

---

## 14. Full CSS Tokens

> **Drop-in CSS file** — copy this into a `:root` block to get all design tokens. All product code should reference these variables.

```css
:root {
  /* ============================
     PRIMITIVE COLOR RAMPS
     Each ramp 10 → 130 in 5-step increments. 70 step is the default rest state.
     ============================ */

  /* Gray (neutral) */
  --gray-10:  #FCFDFF;  --gray-15:  #FAFBFE;  --gray-20:  #F6F7FA;  --gray-25:  #F2F3F7;
  --gray-30:  #E8EAF0;  --gray-35:  #E2E5ED;  --gray-40:  #DCE0E9;  --gray-45:  #D7DBE5;
  --gray-50:  #D1D6E1;  --gray-55:  #BBC2D2;  --gray-60:  #B3BBCB;  --gray-65:  #A7B0C0;
  --gray-70:  #9099AB;  --gray-75:  #8992A4;  --gray-80:  #7C8596;  --gray-85:  #747D8E;
  --gray-90:  #697182;  --gray-95:  #5F6675;  --gray-100: #545B68;  --gray-105: #4D535F;
  --gray-110: #3F444F;  --gray-115: #2E333D;  --gray-120: #1F242D;  --gray-125: #1C212B;
  --gray-130: #161B25;  --gray-135: #121720;  --gray-140: #0D1119;  --gray-145: #080B11;
  --gray-150: #010307;

  /* Blue (primary action) */
  --blue-10:  #EBF1FF;  --blue-15:  #DBE7FF;  --blue-20:  #CBDCFF;  --blue-25:  #BBD1FF;
  --blue-30:  #A3C1FF;  --blue-35:  #93B8FF;  --blue-40:  #77A7FF;  --blue-45:  #5C9AFF;
  --blue-50:  #3F8CFF;  --blue-55:  #2886FF;  --blue-60:  #007CFF;  --blue-65:  #0175F6;
  --blue-70:  #006CEC;  --blue-75:  #0165E4;  --blue-80:  #005BD8;  --blue-85:  #0152CA;
  --blue-90:  #0047B9;  --blue-95:  #0140AE;  --blue-100: #00349A;  --blue-105: #0E3280;
  --blue-110: #0D2873;  --blue-115: #11225E;  --blue-120: #00105B;  --blue-125: #010C4B;
  --blue-130: #00022C;

  /* Purple */
  --purple-10:  #FAF4FF;  --purple-15:  #F5EBFD;  --purple-20:  #EBD2FF;  --purple-25:  #E7C7FF;
  --purple-30:  #DDAFFF;  --purple-35:  #D8A6FA;  --purple-40:  #D189FF;  --purple-45:  #CD7DFC;
  --purple-50:  #C65DFF;  --purple-55:  #C455FB;  --purple-60:  #C139FF;  --purple-65:  #BA34F4;
  --purple-70:  #B31DF0;  --purple-75:  #A821E1;  --purple-80:  #9A24CD;  --purple-85:  #8E24BD;
  --purple-90:  #7B22A4;  --purple-95:  #6E2092;  --purple-100: #5E1D7D;  --purple-105: #521A6D;
  --purple-110: #43165A;  --purple-115: #38124C;  --purple-120: #2B0D3B;  --purple-125: #210A2E;
  --purple-130: #0E0316;

  /* Red (danger) */
  --red-10:  #FFF4F4;  --red-15:  #FFE8E9;  --red-20:  #FFD0D2;  --red-25:  #FFC3C5;
  --red-30:  #FFAAAD;  --red-35:  #FF9B9F;  --red-40:  #FF8186;  --red-45:  #FF6F75;
  --red-50:  #FF4C55;  --red-55:  #F53F4E;  --red-60:  #FF0526;  --red-65:  #EB132B;
  --red-70:  #E21325;  --red-75:  #CD1D2B;  --red-80:  #C41923;  --red-85:  #B01921;
  --red-90:  #9E181E;  --red-95:  #8E171C;  --red-100: #7A1518;  --red-105: #6B1315;
  --red-110: #590F11;  --red-115: #490C0D;  --red-120: #3A0909;  --red-125: #29070F;
  --red-130: #160202;

  /* Yellow (warning + brand) */
  --yellow-10:  #FFFEF2;  --yellow-15:  #FFFDE5;  --yellow-20:  #FEFAD2;  --yellow-25:  #FEF8C3;
  --yellow-30:  #FDF4B2;  --yellow-35:  #FDF1A4;  --yellow-40:  #FCED92;  --yellow-45:  #FBE775;
  --yellow-50:  #F9DF53;  --yellow-55:  #F7D530;  --yellow-60:  #F4CC10;  --yellow-65:  #F3CB18;
  --yellow-70:  #F1C91E;  --yellow-75:  #E7C11F;  --yellow-80:  #DBB71E;  --yellow-85:  #CCAB1E;
  --yellow-90:  #AF931D;  --yellow-95:  #9B831D;  --yellow-100: #826F1C;  --yellow-105: #79681D;
  --yellow-110: #6C5E1C;  --yellow-115: #584E1C;  --yellow-120: #403A1B;  --yellow-125: #2E261A;
  --yellow-130: #1F1F1A;

  /* Green (success) */
  --green-10:  #EAFBED;  --green-15:  #DBF5E0;  --green-20:  #91F0A5;  --green-25:  #87E79C;
  --green-30:  #75D58A;  --green-35:  #6CCB81;  --green-40:  #5BBA71;  --green-45:  #4FB267;
  --green-50:  #35A153;  --green-55:  #209C4B;  --green-60:  #00943D;  --green-65:  #018E3A;
  --green-70:  #008435;  --green-75:  #017C32;  --green-80:  #00732E;  --green-85:  #016A2A;
  --green-90:  #005D24;  --green-95:  #015520;  --green-100: #00481A;  --green-105: #013F16;
  --green-110: #003411;  --green-115: #012B0D;  --green-120: #002108;  --green-125: #011606;
  --green-130: #000A02;

  /* Teal (chat / info-secondary) */
  --teal-10:  #EAFBFA;  --teal-15:  #DEF7FA;  --teal-20:  #B9EEF9;  --teal-25:  #9EEEFA;
  --teal-30:  #8FF4FF;  --teal-35:  #7EF2FF;  --teal-40:  #66EFFF;  --teal-45:  #50E9FA;
  --teal-50:  #29E9FF;  --teal-55:  #1AE2F9;  --teal-60:  #00E5FF;  --teal-65:  #01DCF5;
  --teal-70:  #00C9E0;  --teal-75:  #01C1D7;  --teal-80:  #00B6CC;  --teal-85:  #01A8BC;
  --teal-90:  #0096A8;  --teal-95:  #018B9C;  --teal-100: #007B8A;  --teal-105: #016E7C;
  --teal-110: #005966;  --teal-115: #014C58;  --teal-120: #003D47;  --teal-125: #012F37;
  --teal-130: #001D24;

  /* Channel colors */
  --channel-chat:                var(--teal-90);
  --channel-email:               var(--blue-70);
  --channel-sms:                 var(--green-50);
  --channel-voice:               var(--red-40);
  --channel-note:                var(--yellow-70);
  --channel-forward:             var(--yellow-50);
  --channel-empty-convo:         var(--gray-70);
  --channel-multichannel:        var(--purple-70);
  --channel-facebook:            #7747FD;
  --channel-facebook-wallpost:   #0082FF;
  --channel-instagram-dm:        #B31DF0;
  --channel-instagram-comment:   #CD486B;
  --channel-twitter:             #00AEF3;
  --channel-twitter-dm:          #27C8CE;
  --channel-whatsapp:            #00AC4F;
  --channel-zipwhip:             #FB713F;
  --channel-gmail:               #D44638;
  --channel-slack:               #3235C5;
  --channel-form:                #007CFF;
  --channel-portal:              #F4A11A;
  --channel-tiktok-shop:         #FE2858;
  --channel-other-apps:          var(--gray-50);

  /* Semantic state */
  --color-success:    var(--green-70);  --color-success-bg: var(--green-15);
  --color-warning:    var(--yellow-70); --color-warning-bg: var(--yellow-20);
  --color-danger:     var(--red-70);    --color-danger-bg:  var(--red-15);
  --color-info:       var(--blue-70);   --color-info-bg:    var(--blue-15);

  /* Semantic tokens — light theme */
  --bg-primary:           #FFFFFF;
  --bg-primary-inverse:   var(--gray-150);
  --bg-primary-hover:     var(--gray-20);
  --bg-primary-active:    var(--gray-30);
  --bg-secondary:         var(--gray-20);
  --bg-secondary-hover:   var(--gray-30);
  --bg-tertiary:          var(--gray-30);
  --bg-tertiary-hover:    var(--gray-40);

  --text-primary:           var(--gray-120);
  --text-primary-inverse:   var(--gray-10);
  --text-secondary:         var(--gray-100);
  --text-secondary-hover:   var(--gray-110);
  --text-hint:              var(--blue-70);
  --text-link:              var(--blue-70);
  --text-link-hover:        var(--blue-90);
  --text-info:              var(--blue-70);

  --icon-primary:           var(--gray-120);
  --icon-primary-hover:     var(--gray-70);
  --icon-primary-disabled:  var(--gray-60);
  --icon-active:            var(--blue-70);

  --border-primary: var(--gray-40);

  --form-border:                 var(--gray-40);
  --form-border-hover:           var(--blue-70);
  --form-border-active:          var(--blue-70);
  --form-bubble-bg:              var(--gray-30);
  --form-bubble-multi-bg:        var(--gray-50);
  --form-bubble-multi-bg-hover:  var(--gray-60);
  --form-bg-disabled:            var(--gray-30);
  --form-text-disabled:          var(--gray-90);
  --form-text-placeholder:       var(--gray-70);

  --toggle-unselected-marker:        #FFFFFF;
  --toggle-unselected-bg:            var(--gray-80);
  --toggle-unselected-bg-hover:      var(--gray-90);
  --toggle-unselected-bg-disabled:   var(--gray-30);
  --toggle-selected-marker:          #FFFFFF;
  --toggle-selected-bg:              var(--blue-70);
  --toggle-selected-bg-hover:        var(--blue-80);
  --toggle-selected-bg-disabled:     var(--blue-40);

  --control-unselected-border:       var(--gray-70);
  --control-unselected-border-hover: var(--blue-70);
  --control-unselected-bg:           #FFFFFF;
  --control-unselected-bg-hover:     var(--blue-10);
  --control-selected-marker:         #FFFFFF;
  --control-selected-border:         var(--blue-70);
  --control-selected-border-hover:   var(--blue-80);
  --control-selected-bg:             var(--blue-70);
  --control-selected-bg-hover:       var(--blue-80);

  /* Backwards-compat aliases */
  --fg-1:         var(--text-primary);
  --fg-2:         var(--text-secondary);
  --fg-3:         var(--gray-80);
  --fg-4:         var(--gray-60);
  --fg-on-yellow: var(--gray-120);
  --fg-on-ink:    #FFFFFF;
  --bg-app:       var(--gray-15);
  --bg-surface:   #FFFFFF;
  --bg-sunken:    var(--gray-25);
  --bg-inverse:   var(--gray-150);
  --bg-brand:     var(--yellow-60);
  --border-1:      var(--gray-30);
  --border-2:      var(--gray-40);
  --border-strong: var(--gray-80);
  --border-focus:  var(--blue-70);

  /* Type families */
  --font-display: "Fraunces", "Quincy CF", "Cooper Light", "Iowan Old Style", Georgia, serif;
  --font-sans:    "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --font-mono:    "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;

  /* Type scale (NEW 2026 — 13px base) */
  --text-h1:         1.692rem;   /* 22px */
  --text-h2:         1.408rem;   /* 18.3px */
  --text-h3:         1.177rem;   /* 15.3px */
  --text-h4:         1.077rem;   /* 14px */
  --text-label:      1.000rem;   /* 13px */
  --text-body:       1.000rem;   /* 13px */
  --text-value:      0.889rem;   /* 11.6px */
  --text-accent:     0.790rem;   /* 10.3px */
  --text-data:       2.615rem;   /* 34px */
  --text-data-unit:  1.615rem;   /* 21px */

  /* Line heights */
  --leading-h1:        1.64;
  --leading-h2:        1.22;
  --leading-h3:        1.25;
  --leading-h4:        1.43;
  --leading-label:     1.43;
  --leading-body:      1.43;
  --leading-value:     1.38;
  --leading-accent:    1.33;
  --leading-data:      1.24;
  --leading-data-unit: 1.24;

  /* Legacy scale (deprecated for product UI; OK for marketing/display) */
  --fs-12: 0.75rem;   --fs-13: 0.8125rem; --fs-14: 0.875rem;  --fs-15: 0.9375rem;
  --fs-16: 1rem;      --fs-18: 1.125rem;  --fs-20: 1.25rem;   --fs-24: 1.5rem;
  --fs-28: 1.75rem;   --fs-32: 2rem;      --fs-40: 2.5rem;    --fs-48: 3rem;
  --fs-64: 4rem;      --fs-80: 5rem;      --fs-96: 6rem;

  --lh-tight: 1.05;  --lh-snug: 1.2;  --lh-body: 1.5;  --lh-loose: 1.65;
  --tr-tight: -0.02em;  --tr-snug: -0.01em;  --tr-normal: 0;  --tr-wide: 0.04em;

  /* Spacing */
  --space-0: 0;     --space-1: 4px;   --space-2: 8px;   --space-3: 12px;
  --space-4: 16px;  --space-5: 20px;  --space-6: 24px;  --space-8: 32px;
  --space-10: 40px; --space-12: 48px; --space-16: 64px; --space-20: 80px; --space-24: 96px;

  /* Radii */
  --radius-xs: 4px;   --radius-sm: 8px;    --radius-md: 12px;
  --radius-lg: 16px;  --radius-xl: 24px;   --radius-2xl: 32px;
  --radius-pill: 999px;
  --radius-squircle: 32% / 32%;

  /* Elevation */
  --shadow-xs: 0 1px 2px rgba(31, 42, 46, 0.06);
  --shadow-sm: 0 2px 6px rgba(31, 42, 46, 0.08);
  --shadow-md: 0 8px 24px rgba(31, 42, 46, 0.10);
  --shadow-lg: 0 20px 48px rgba(31, 42, 46, 0.14);
  --shadow-xl: 0 32px 80px rgba(31, 42, 46, 0.18);
  --shadow-inset-hair: inset 0 0 0 1px rgba(31, 42, 46, 0.08);

  /* Motion */
  --ease-standard: cubic-bezier(0.2, 0.7, 0.2, 1);
  --ease-out:      cubic-bezier(0.16, 1, 0.3, 1);
  --ease-in:       cubic-bezier(0.5, 0, 0.75, 0);
  --dur-1: 120ms;  --dur-2: 180ms;  --dur-3: 260ms;  --dur-4: 400ms;
}

/* ============================
   BASE TYPE ROLES
   ============================ */
html { font-size: 13px; }   /* NEW BASE */
body {
  font-family: var(--font-sans);
  font-size: var(--text-body);
  line-height: var(--leading-body);
  color: var(--text-primary);
  background: var(--bg-app);
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}

/* Display (Fraunces) — marketing only */
.k-display-xl { font-family: var(--font-display); font-weight: 500; font-size: clamp(3.5rem, 7vw, var(--fs-96)); line-height: var(--lh-tight); letter-spacing: var(--tr-tight); }
.k-display-lg { font-family: var(--font-display); font-weight: 500; font-size: clamp(2.75rem, 5vw, var(--fs-80)); line-height: var(--lh-tight); letter-spacing: var(--tr-tight); }
.k-display-md { font-family: var(--font-display); font-weight: 500; font-size: var(--fs-64); line-height: var(--lh-tight); letter-spacing: var(--tr-snug); }
.k-display-sm { font-family: var(--font-display); font-weight: 500; font-size: var(--fs-48); line-height: var(--lh-snug); letter-spacing: var(--tr-snug); }

/* Headings (Inter, 700 Bold) — NEW SCALE */
h1, .k-h1 { font-family: var(--font-sans); font-weight: 700; font-size: var(--text-h1); line-height: var(--leading-h1); color: var(--text-primary); }
h2, .k-h2 { font-family: var(--font-sans); font-weight: 700; font-size: var(--text-h2); line-height: var(--leading-h2); color: var(--text-primary); }
h3, .k-h3 { font-family: var(--font-sans); font-weight: 700; font-size: var(--text-h3); line-height: var(--leading-h3); color: var(--text-primary); }
h4, .k-h4 { font-family: var(--font-sans); font-weight: 700; font-size: var(--text-h4); line-height: var(--leading-h4); color: var(--text-primary); }

/* Labels (600 Semibold) */
.k-label { font-family: var(--font-sans); font-weight: 600; font-size: var(--text-label); line-height: var(--leading-label); color: var(--text-secondary); }

/* Body */
p, .k-body { font-size: var(--text-body); line-height: var(--leading-body); color: var(--text-secondary); text-wrap: pretty; }

/* Values & Metadata */
.k-value  { font-family: var(--font-sans); font-weight: 600; font-size: var(--text-value); line-height: var(--leading-value); color: var(--text-primary); }
.k-accent, .k-caption { font-size: var(--text-accent); line-height: var(--leading-accent); color: var(--fg-3); }

/* Data Display (KPIs) */
.k-data       { font-family: var(--font-sans); font-weight: 700; font-size: var(--text-data); line-height: var(--leading-data); color: var(--text-primary); }
.k-data-unit  { font-family: var(--font-sans); font-weight: 700; font-size: var(--text-data-unit); line-height: var(--leading-data-unit); color: var(--text-primary); }

/* Utility */
.k-mono, code, kbd, samp { font-family: var(--font-mono); font-size: 0.92em; }
code { background: var(--bg-sunken); padding: 2px 6px; border-radius: var(--radius-xs); }

/* Links */
a { color: var(--text-link); text-decoration: none; }
a:hover { color: var(--text-link-hover); text-decoration: underline; text-underline-offset: 3px; }

/* Selection */
::selection { background: var(--yellow-60); color: var(--gray-120); }
```

---

## Appendix: Quick Reference Cheatsheet

### Most-Used Tokens
| Need | Token |
|------|-------|
| Primary text | `--text-primary` (`#1F242D`) |
| Secondary text | `--text-secondary` (`#545B68`) |
| Hint/metadata text | `--fg-3` (`#7C8596`) |
| Link | `--text-link` (`#006CEC`) |
| App background | `--bg-app` |
| Card background | `--bg-surface` |
| Border (default) | `--border-primary` (`--gray-40`) |
| Brand (Sunshine Yellow) | `--bg-brand` (`--yellow-60`) |
| Success | `--color-success` (`--green-70`) |
| Danger | `--color-danger` (`--red-70`) |

### Most-Used Type
| Need | Class |
|------|-------|
| Page title | `<h1 class="k-h1">` (22px / 700) |
| Section header | `<h2 class="k-h2">` (18.3px / 700) |
| Card title | `<h4 class="k-h4">` (14px / 700) |
| Form label | `<span class="k-label">` (13px / 600) |
| Body text | `<p class="k-body">` (13px / 400) |
| Tag / data value | `<span class="k-value">` (11.6px / 600) |
| Timestamp | `<span class="k-accent">` (10.3px / 400) |
| KPI number | `<div class="k-data">` (34px / 700) |

### Spacing Cheatsheet
- 4px (`--space-1`) — tight, between icon + label
- 8px (`--space-2`) — within a row
- 12px (`--space-3`) — between fields in form
- 16px (`--space-4`) — between unrelated elements
- 24px (`--space-6`) — between sections
- 48px (`--space-12`) — between major page sections (marketing)

---

**End of design.md** · For preview cards, see `/preview/` directory in the source project. For code reference, see `colors_and_type.css`.
