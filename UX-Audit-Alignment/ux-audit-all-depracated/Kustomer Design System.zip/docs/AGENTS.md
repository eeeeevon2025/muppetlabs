# AI Agent Guidelines for Kustomer Web

This document provides guidance for AI coding agents working with the Kustomer Web codebase.

## Project Overview

Kustomer Web is a large-scale React/TypeScript frontend application for customer service software. The codebase contains 27,000+ files and follows specific patterns and standards.

## Tech Stack

- **React 18** with functional components and hooks
- **TypeScript** for type safety (migrating from JavaScript)
- **Redux** with thunks for state management
- **SCSS** with CSS modules for styling
- **Jest** + React Testing Library for unit/integration tests
- **Playwright** for E2E tests
- **LaunchDarkly** for feature flags
- **react-intl** for internationalization

## Key Development Rules

### 1. Always Read Before Editing

- Read current file state before making any changes
- Understand existing patterns before modifying
- Check related files and tests

### 2. Minimal Changes

- Keep edits focused and small
- Don't refactor unrelated code
- Don't add comments about moved/removed functionality
- Preserve existing patterns and conventions

### 3. Design System Usage

**Use `komponentsV2/` components instead of native HTML elements:**

| Instead of | Use |
|------------|-----|
| `<button>` | `ButtonPrimary`, `ButtonSecondary`, `IconButton` |
| `<input>` | `TextInput`, `Select`, `Dropdown` |
| `<h1>`-`<h6>` | `HeaderText` with appropriate `type` |
| `<span>` for text | `Text` component |

**Exceptions (acceptable):**
- Layout divs with className
- Semantic HTML (`<section>`, `<article>`, `<nav>`)
- Third-party library wrappers

### 4. Internationalization (CRITICAL)

All user-facing text MUST be internationalized:

```tsx
// Correct
<ButtonPrimary>
  <FormattedMessage defaultMessage="Submit" />
</ButtonPrimary>

// For props
placeholder={intl.formatMessage({ defaultMessage: 'Enter name' })}

// Incorrect - hardcoded strings
<ButtonPrimary>Submit</ButtonPrimary>
```

### 5. Import Ordering

Follow this order (ESLint enforced):
1. React and external packages
2. Absolute imports (`types/`, `components/`, `utils/`, etc.)
3. Relative imports
4. Style imports

Use blended imports (types + regular imports on same line when possible).

### 6. Stable References (Prevent Unnecessary Rerenders)

**Never pass inline `() => {}`, `[]`, or `{}` as JSX props or to setState.** Each creates a new reference on every render, breaking `React.memo`, `useMemo`, and `useCallback`.

Always import from `constants/defaults`:

```typescript
import { DEFAULT_ARRAY, DEFAULT_OBJECT, DEFAULT_FUNCTION } from 'constants/defaults';

// Correct
<Table onRowClick={DEFAULT_FUNCTION} />
<Select options={DEFAULT_ARRAY} />
<Component config={DEFAULT_OBJECT} />
<Component items={data || DEFAULT_ARRAY} />
useState(data || DEFAULT_ARRAY);

// Incorrect - new reference every render
// <Table onRowClick={() => {}} />
// <Select options={[]} />
// <Component items={data || []} />
```

**Safe to leave unchanged:** iteration-only `(data || []).map(...)`, `useEffect` bodies, Redux selectors/reducers, utility functions.

### 7. TypeScript Standards

- Never use `any` - use `unknown` or create proper types
- Check `src/types/resources/` for existing types before creating new ones
- Use `ConnectedProps<typeof connector>` for Redux-connected components
- Let TypeScript infer return types when obvious

### 7. Testing Standards

- Place tests in `__tests__/` directory next to tested file
- Use `.spec.js` extension (prefer JavaScript for tests)
- Use `renderWithStore` for connected components
- Never mock `intl` or `FormattedMessage`
- Never wrap `userEvent` in `act()` - it's already handled

```javascript
// RTL test example
import { renderWithStore, screen, user, waitFor } from 'helpers/test/rtl-renderer';

describe('MyComponent', () => {
  it('should handle interaction', async () => {
    await renderWithStore(<MyComponent />);
    
    await user.click(screen.getByRole('button', { name: 'Submit' }));
    
    await waitFor(() => {
      expect(screen.getByText('Success')).toBeInTheDocument();
    });
  });
});
```

### 8. SCSS Variables

The complete SCSS variable reference is in `.cursor/rules/kustomer-scss-variables.mdc`, which auto-loads for all `.scss` files. Only use variables listed in that reference. Do not invent or guess variable names.

## Repository Structure

```
src/
├── api/              # API integration and services
├── components/       # Reusable React components
├── komponents/       # Legacy component system
├── komponentsV2/     # New component system (prefer this)
├── komponentsSmartV2/# Smart components with business logic
├── views/            # Page-level components
├── store/            # Redux store configuration
├── routes/           # Application routing
├── styles/           # Global styles and SCSS
├── i18n/             # Internationalization
├── utils/            # Utility functions
├── hooks/            # Custom React hooks
├── services/         # Service layer implementations
├── types/            # TypeScript type definitions
│   └── resources/    # Global resource types
```

## Commands

| Command | Description |
|---------|-------------|
| `yarn start:staging` | Start dev server pointing to staging |
| `yarn start:qa1` | Start dev server pointing to QA |
| `yarn test` | Run unit tests |
| `yarn test:changed` | Run tests for changed files |
| `yarn lint` | Run all linters |
| `yarn langs` | Build i18n files (run after changing strings) |
| `yarn type-check` | Run TypeScript type checking |

## Documentation References

- **Component System**: `./components.md`
- **Testing Guide**: `./testing.md`
- **Forms**: `./forms.md`
- **Cursor Rules**: `.cursor/rules/` - Always-applied and glob-scoped rules
- **Cursor Skills**: `.cursor/skills/` - Context-specific guidance
- **AI Code Review Guidelines**: `.ai/ai-code-review-guidelines.md`

### Always-Applied Rules

The following rules are automatically applied to all files:
- **Testing Enforcement**: 98%+ test coverage requirement (`.cursor/rules/kustomer-testing-enforcement.mdc`)
- **Minimal Changes**: Keep edits focused and minimal (`.cursor/rules/kustomer-minimal-changes.mdc`)
- **Import Ordering**: Strict import organization standards (`.cursor/rules/kustomer-import-ordering.mdc`)
- **Skill Detection**: Guidance on when to use each Cursor skill (`.cursor/rules/kustomer-skill-detection.mdc`)

### Glob-Scoped Rules

These rules automatically apply based on file patterns:
- **TypeScript Standards**: For `**/*.{ts,tsx}` files (`.cursor/rules/kustomer-typescript-standards.mdc`)
- **Design System Usage**: For component files (`.cursor/rules/kustomer-design-system-usage.mdc`)
- **Text Standards**: For component/view files (`.cursor/rules/kustomer-text-standards.mdc`)
- **SCSS Variables**: For `**/*.scss` files (`.cursor/rules/kustomer-scss-variables.mdc`)

## AI-Specific Guidelines

### When Making Changes

1. **Plan first** - For complex changes, outline approach before coding
2. **Present options** - For large refactors, present multiple approaches with pros/cons
3. **Test immediately** - Run tests after modifications
4. **Check lints** - Save with formatting to trigger Prettier, then check for lint errors

### Test Failure Policy

**ALL unit tests pass 100% on master. There are no "pre-existing" test failures in this codebase.**

If a test fails after your changes, your change caused it. Do not:
- Report failures as "pre-existing"
- Suggest the failure existed before your changes
- Skip or ignore failing tests

Instead: investigate, fix, and verify ALL tests pass before considering work complete.

### Common Mistakes to Avoid

- ❌ Editing without reading current file state
- ❌ Making overly broad changes
- ❌ Using native HTML when komponents exist
- ❌ Hardcoding UI strings without i18n
- ❌ Using `any` types
- ❌ Skipping test updates when modifying code
- ❌ Wrapping `userEvent` in `act()`
- ❌ Adding dependencies without checking existing implementations
- ❌ Combining migrations with feature changes (use separate PRs)
- ❌ Reporting test failures as "pre-existing" — all tests pass on master

### When Suggesting Large Changes

Always present multiple approaches with:
- Pros and cons of each
- Effort estimation (scope, not timeline)
- Risk assessment
- Let the user decide which approach to take

## Feature Flags

Feature flags are managed via LaunchDarkly. Use the `useFeatureFlag` hook:

```tsx
import { useFeatureFlag } from 'hooks/useFeatureFlag';

const MyComponent = () => {
  const isFeatureEnabled = useFeatureFlag('my-feature-flag');
  
  if (isFeatureEnabled) {
    return <NewFeature />;
  }
  return <OldFeature />;
};
```

## Logging

Use the `log` module instead of `console.log`:

```javascript
import log from 'log';

log.info('Debug info', { context: 'data' });
log.warn('Warning message');
log.error('Error message');
log.exception(new Error('Exception'), { additionalInfo: 'data' });
```

## Cursor Cloud specific instructions

### Environment prerequisites

- **Caddy** must be installed (`apt install caddy`) and given bind capability (`sudo setcap 'cap_net_bind_service=+ep' $(which caddy)`) for HTTPS on port 443.
- **`/etc/hosts`** must contain `127.0.0.1 kustomer.helpapp.io` for the staging dev server.
- **`~/.npmrc`** must contain `//registry.npmjs.org/:_authToken=$NPM_TOKEN` for private `@kustomer/*` packages. The `NPM_TOKEN` secret is injected as an env var.
- **Google Translate credentials** are needed for `yarn langs`. The `GOOGLE_TRANSLATE_CREDENTIALS` secret is injected as an env var and must be written to `~/.gcloud/google_translate_application_credentials.json`.

### First-time setup (after `yarn install`)

1. `yarn setup:https` — trusts Caddy root certificates for local HTTPS. Run once after initial install. Requires Caddy to have bind capability (`sudo setcap 'cap_net_bind_service=+ep' $(which caddy)`).
2. `yarn langs` — builds i18n files (required before first build; writes to `build/lang/split/`). If Google creds are missing, `yarn langs:split-only` can split existing translations from `build/lang/langs.json`.

### Running the dev server

1. `yarn start:staging` — starts the dev server and Caddy together. This is the **only** command you should use to start the dev server. **Never run rspack or caddy commands directly.**
2. Open `https://kustomer.helpapp.io/` in the browser.

### Secrets

| Secret | Purpose |
|--------|---------|
| `NPM_TOKEN` | Auth for private `@kustomer/*` npm packages |
| `GOOGLE_TRANSLATE_CREDENTIALS` | Google Translate JSON credentials for `yarn langs` — write to `~/.gcloud/google_translate_application_credentials.json` |
| `KUSTOMER_TEST_EMAIL` | Test account email for staging login |
| `KUSTOMER_TEST_PASSWORD` | Test account password for staging login |

### Gotchas

- The first build takes ~90-120 seconds. HMR rebuilds are fast after that.
- `yarn langs` requires Google Translate credentials. For local development, retrieve them via AWS SSO. In Cursor Cloud VMs, the credential JSON is already injected as the `GOOGLE_TRANSLATE_CREDENTIALS` environment variable, so AWS SSO is not required there. In CI or any Cloud VM, write the `GOOGLE_TRANSLATE_CREDENTIALS` value to `~/.gcloud/google_translate_application_credentials.json` before running `yarn langs` to mirror local behavior.
- If the app is not responding, it's OK to kill Caddy (`pkill caddy`) and restart via `yarn start:staging`.
- **Never run rspack or caddy commands directly.** Always use the yarn scripts (e.g. `yarn start:staging`, `yarn setup:https`).
