# Kustomer Typography Rules

## Overview

Kustomer's typographic system uses **Inter** as the primary product typeface, with **Fraunces** (substituting the licensed Quincy CF) for display/marketing moments, and **JetBrains Mono** for code and technical content.

All font files are served locally (`/fonts/`) to ensure performance and consistency; web fonts are used only as fallbacks.

**NEW (2026):** The type scale has been updated to a **13px base** with a hybrid scale (Minor Third for headings, Major Second for body text and below). This tighter scale improves density and hierarchy in the product UI.

---

## Font Families

### Primary: Inter (UI & Product)
- **Variable font** with weight axis (100–900) and optical sizing (8–144px)
- Used for all product interfaces, buttons, form labels, body text, and UI labels
- Weights used in practice: 400 (regular), 500 (medium), 600 (semibold), 700 (bold)
- Loaded as: `@font-face` from `fonts/Inter-VariableFont_opsz_wght.ttf` + italic variant

### Secondary: Fraunces (Display / Brand)
- **Serif, high-contrast display face** for hero headlines and narrative moments
- Weights: 400, 500, 600, 700
- Used at 28px and above (clamp rules apply for responsive scaling)
- Imported from Google Fonts as fallback: `fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700`
- **Note:** Kustomer has a licensed **Quincy CF** serif for premium contexts; substitute Fraunces until Quincy files are provided

### Tertiary: JetBrains Mono (Code)
- **Monospace** for code blocks, terminal output, and technical content
- Weights: 400, 500
- Imported from Google Fonts: `fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500`

---

## Type Scale (NEW 2026)

All sizes are based on a **13px base** with a hybrid progression:
- **Minor Third (1.2×)** for headings (H1–H4)
- **Major Second (1.125×)** for body text and smaller

Use the CSS variables below:

```css
/* NEW PRODUCT UI SCALE */
--text-h1:         1.692rem;   /* 22px @ 13px base */
--text-h2:         1.408rem;   /* 18.3px @ 13px base */
--text-h3:         1.177rem;   /* 15.3px @ 13px base */
--text-h4:         1.077rem;   /* 14px @ 13px base */
--text-label:      1.000rem;   /* 13px @ 13px base */
--text-body:       1.000rem;   /* 13px @ 13px base */
--text-value:      0.889rem;   /* 11.6px @ 13px base */
--text-accent:     0.790rem;   /* 10.3px @ 13px base */
--text-data:       2.615rem;   /* 34px @ 13px base — KPI numbers */
--text-data-unit:  1.615rem;   /* 21px @ 13px base — KPI units */
```

**Rule:** Always reference `--text-*` variables for product UI; do not hardcode pixel sizes.

### Legacy Scale (Deprecated)
The old 16px-based `--fs-*` tokens remain for backwards compatibility but should not be used in new work:

```css
--fs-12 through --fs-96  /* DEPRECATED — use --text-* tokens */
```

---

## Type Roles (NEW 2026)

### Display (Fraunces)
Used for **hero headings, narrative marketing moments, and brand statements**.

| Role | Size | Weight | Line Height | Letter Spacing | Use Case |
|------|------|--------|-------------|----------------|----------|
| `.k-display-xl` | clamp(3.5rem, 7vw, 6rem) | 500 | 1.05 (tight) | -0.02em | Hero headlines on landing pages |
| `.k-display-lg` | clamp(2.75rem, 5vw, 5rem) | 500 | 1.05 (tight) | -0.02em | Section headings (marketing) |
| `.k-display-md` | 4rem (64px) | 500 | 1.05 (tight) | -0.01em | Large feature headings |
| `.k-display-sm` | 3rem (48px) | 500 | 1.2 (snug) | -0.01em | Sub-headings (marketing) |

**Note:** Display uses `clamp()` for fluid scaling on smaller viewports — no media queries needed.

### Headings (Inter, Sans) — NEW SCALE
Used for **product sections, page titles, and information hierarchy**.

| Role | Token | Size @ 13px base | Weight | Line Height | Use Case |
|------|-------|------------------|--------|-------------|----------|
| `h1` / `.k-h1` | `--text-h1` | 22px | 700 Bold | 1.64 | Page title — one per page |
| `h2` / `.k-h2` | `--text-h2` | 18.3px | 700 Bold | 1.22 | Card / section header |
| `h3` / `.k-h3` | `--text-h3` | 15.3px | 700 Bold | 1.25 | Group / layer header |
| `h4` / `.k-h4` | `--text-h4` | 14px | 700 Bold | 1.43 | Precedes forms and controls |

**Changes from old scale:**
- H1: 20px → 22px (+2px)
- H2: 18px → 18.3px (+0.3px)
- H3: 16px → 15.3px (-0.7px)
- H4: unchanged at 14px
- All headings now **700 Bold** (was 600 Semibold)

### Labels & Body Text (Inter) — NEW SCALE
Used for **all product UI, prose, and information**.

| Role | Token | Size @ 13px base | Weight | Line Height | Use Case |
|------|-------|------------------|--------|-------------|----------|
| `.k-label` | `--text-label` | 13px | 600 Semibold | 1.43 | Form labels, input labels |
| `.k-body` / `p` | `--text-body` | 13px | 400 Regular | 1.43 | All body copy and descriptions |
| `.k-value` | `--text-value` | 11.6px | 600 Semibold | 1.38 | Tags and supplemental data |
| `.k-accent` / `.k-caption` | `--text-accent` | 10.3px | 400 Regular | 1.33 | Timestamps and metadata |

**Changes from old scale:**
- Label: 14px → 13px (-1px), weight 600 Semibold (was 400 Regular or 600 context-dependent)
- Body: 16px → 13px (-3px at old base, but matches product reality)
- Value: 13px → 11.6px (-1.4px) — new token for tags/data
- Accent: 12px → 10.3px (-1.7px) — new token for timestamps

### Data Display (KPIs) — NEW
Used for **reporting metrics and dashboard numbers**.

| Role | Token | Size @ 13px base | Weight | Line Height | Use Case |
|------|-------|------------------|--------|-------------|----------|
| `.k-data` | `--text-data` | 34px | 700 Bold | 1.24 | KPI metric number (e.g. "42,891") |
| `.k-data-unit` | `--text-data-unit` | 21px | 700 Bold | 1.24 | KPI unit label (e.g. "conversations") |

**Color:** Body text uses `--text-secondary` (secondary text, `#545B68`) by default; use `--text-primary` for emphasis.

### Code & Technical (JetBrains Mono)
Used for **code blocks, variables, API references**.

| Role | Size | Weight | Use Case |
|------|------|--------|----------|
| `.k-mono` / `code` | 0.92em (relative) | 400 | Inline code or code blocks |
| `kbd` | 0.92em (relative) | 400 | Keyboard input labels |

**Styling:** Code blocks receive a light background (`--bg-sunken`) and 4px border-radius by default.

---

## Line Height Scale (NEW 2026)

Control vertical rhythm with these line-height variables:

```css
/* NEW PRODUCT SCALE — unitless multipliers */
--leading-h1:      1.64;
--leading-h2:      1.22;
--leading-h3:      1.25;
--leading-h4:      1.43;
--leading-label:   1.43;
--leading-body:    1.43;
--leading-value:   1.38;
--leading-accent:  1.33;
--leading-data:    1.24;
--leading-data-unit: 1.24;

/* LEGACY (Display/Marketing only) */
--lh-tight: 1.05;   /* Display text, tight spacing */
--lh-snug:  1.2;    /* Headings, compact stacks */
--lh-body:  1.5;    /* Body paragraphs, comfortable reading */
--lh-loose: 1.65;   /* Wide spacing for emphasis or accessibility */
```

**Rule:** Use `--leading-*` variables for product UI; `--lh-*` is for display/marketing only.

---

## Letter Spacing

Control emphasis and readability with these tracking variables:

```css
--tr-tight: -0.02em;  /* Display headlines, visual compression */
--tr-snug:  -0.01em;  /* Headings, subtle tightening */
--tr-normal: 0;       /* Body, default spacing */
--tr-wide:  0.04em;   /* Eyebrows, labels, buttons for emphasis */
```

**Rule:** Use `--tr-*` variables; do not invent letter-spacing values.

---

## Color & Contrast

### Text Colors
- **Primary text** (`--fg-1` / `#1F242D`): Headings, UI labels, high-contrast information
- **Secondary text** (`--fg-2` / `#545B68`): Body paragraphs, supporting information
- **Hint text** (`--fg-3` / `#7C8596`): Disabled state, metadata, timestamps
- **Link text** (`--text-link` / `#006CEC` blue-70): Hyperlinks; use underline on hover

### Emphasis & Contrast
- **Never** use gray-80 or lighter for primary body text — fails WCAG AA contrast
- **Minimum 4.5:1 ratio** for body text (16px+) on light backgrounds
- **Minimum 3:1 ratio** for large text (18px+)
- Use color ramps at 70+ for dark text; 30 and below for light backgrounds

---

## HTML Markup Rules

### Always Use Semantic Elements
- `<h1>`, `<h2>`, `<h3>`, `<h4>` for structural headings (never skip levels)
- `<p>` for paragraphs
- `<strong>` for emphasis (not `<b>`)
- `<em>` for italic (not `<i>`)
- `<code>` for inline code
- `<kbd>` for keyboard input

### Apply Styles Sparingly
```html
<!-- Good: semantic + class for style refinement -->
<h2 class="k-h2">Section Title</h2>
<p class="k-body">Paragraph text here.</p>

<!-- Avoid: divs with typo classes -->
<div class="k-h2">Not a heading</div>
<span class="k-body">Not a paragraph</span>
```

---

## Responsive Typography

### Mobile-First Approach
- **Base sizes:** 12–16px (all text sizes readable on mobile)
- **Scaling:** Use `clamp()` for fluid type on Display role only
- **No media queries** needed for type scale (clamp handles this)

### Example: Responsive Display
```css
.k-display-xl {
  font-size: clamp(3.5rem, 7vw, 6rem); /* min: 56px → max: 96px */
}
```

---

## Common Patterns (NEW 2026)

### Page Title + Intro
```html
<h1 class="k-h1">Business Rules</h1>
<p class="k-body">Define automated workflows and routing logic.</p>
```

### Card Component
```html
<div class="card">
  <h4 class="k-h4">Condition group</h4>
  <p class="k-accent">Updated 4 min ago</p>
</div>
```

### Form Label + Input
```html
<label>
  <span class="k-label">Queue name</span>
  <input type="text" />
</label>
```

### Data Value (Tag / Metadata)
```html
<span class="k-value">Updated 4 min ago</span>
```

### Timestamp / Metadata
```html
<p class="k-accent">customer@example.com · 2 min ago</p>
```

### KPI Metric Display
```html
<div class="metric">
  <div class="k-data">42,891</div>
  <div class="k-data-unit">conversations</div>
</div>
```

### Customer Panel Field (NEW)
```html
<!-- Field label: medium (500) + text-secondary -->
<label style="font-weight: 500; color: var(--text-secondary);">Queue name</label>

<!-- Filled value: semibold (600) + text-primary -->
<div style="font-weight: 600; color: var(--text-primary);">Support Queue</div>

<!-- Empty placeholder: italic + text-tertiary -->
<div style="font-style: italic; color: var(--fg-3);">
  <span class="icon">+</span> Add description
</div>
```

---

## Accessibility Guidelines

1. **Contrast:** Always test text on its background for WCAG AA compliance (4.5:1 minimum)
2. **Size:** Never go below 12px for body text; 14px is preferred
3. **Line Height:** Maintain at least 1.5x line height for paragraphs
4. **Links:** Always underline links or use color + another visual cue (icon, weight change)
5. **Avoid:** Don't use color alone to convey meaning; pair with text or icon

---

## CSS Variables Quick Reference (NEW 2026)

```css
/* Fonts */
--font-display: "Fraunces", serif;
--font-sans:    "Inter", sans-serif;
--font-mono:    "JetBrains Mono", monospace;

/* NEW Type Scale (13px base) */
--text-h1, --text-h2, --text-h3, --text-h4
--text-label, --text-body, --text-value, --text-accent
--text-data, --text-data-unit

/* NEW Line Heights */
--leading-h1, --leading-h2, --leading-h3, --leading-h4
--leading-label, --leading-body, --leading-value, --leading-accent
--leading-data, --leading-data-unit

/* Legacy (Display/Marketing) */
--fs-12 through --fs-96  /* DEPRECATED for product UI */
--lh-tight, --lh-snug, --lh-body, --lh-loose

/* Letter Spacing */
--tr-tight, --tr-snug, --tr-normal, --tr-wide

/* Text Colors */
--text-primary (#1F242D), --text-secondary (#545B68), --fg-3 (#7C8596)
--text-link, --text-link-hover
```

---

## Non-Negotiables (Design System Lock) — UPDATED 2026

❌ **Do NOT:**
- Use fonts other than Inter, Fraunces, JetBrains Mono
- Hardcode font sizes — always use `--text-*` variables for product UI
- Hardcode line heights — always use `--leading-*` variables for product UI
- Create new type roles without design system review
- Use color other than `--text-*` / `--fg-*` for text
- Go below 10px for UI text (smallest is `--text-accent` at 10.3px)
- Use sizes between the defined scale
- Use old `--fs-*` tokens in new product UI (marketing/display only)

✅ **DO:**
- Reference CSS variables for all type properties (`--text-*`, `--leading-*`)
- Use semantic HTML (`<h1>`, `<p>`, `<strong>`)
- Test contrast ratios (4.5:1 minimum for body text)
- Use 700 Bold for all headings (H1–H4)
- Use 600 Semibold for labels and values
- Use 400 Regular for body text and metadata
- Use `clamp()` for responsive Display text only

---

## Resources

- **Preview Cards:** `/preview/type-display.html`, `/preview/type-headings.html`, `/preview/type-body.html`
- **Color Tokens:** `/colors_and_type.css` (CSS root variables)
- **Figma Reference:** See the **Kanvas Design Library** > Typography page
- **Brand Voice:** `/principles.md`, `/rules.md`
