# 🔒 Design System Lock (Strict Enforcement)

This file defines **non-negotiable rules** for design system fidelity.
No interpretation, approximation, or creativity is allowed at the brand/system layer.

---

## 1. Fonts (Non-Negotiable)
- ONLY use approved fonts:
  - Primary: **Inter** (variable, loaded locally from `fonts/Inter-VariableFont_opsz_wght.ttf`)
  - Secondary (mono): **JetBrains Mono** (loaded from Google Fonts)
- Do NOT substitute fonts under any circumstance
- Do NOT infer or approximate fonts
- Do NOT use Fraunces, Neutral Std, Quincy CF, Roboto, system-ui, or any other family

❌ Fail if:
- Any other font is used
- Inter is loaded from a CDN instead of `fonts/`

---

## 2. Logo Usage (Critical)
- ONLY use provided logo assets exactly as-is:
  - Wordmark: `assets/kustomer-logo-ink.svg` / `assets/kustomer-logo-white.png`
  - Logomark (Kusty): `assets/kusty-logomark.svg`
  - Avatars: `assets/kustomer-avatar-stone.png` / `assets/kustomer-avatar-white.png`
- Do NOT:
  - recreate
  - simplify
  - reinterpret SVG paths
  - generate a new logo
- Always reference the original file directly

❌ Fail if:
- Logo is modified in any way
- Logo is re-rendered instead of reused

---

## 3. Colors (Token-Based Only)
- ONLY use defined color tokens from `colors_and_type.css`
- Full ramps available: Gray, Blue, Purple, Red, Yellow, Green, Teal (steps 10–130)
- Do NOT:
  - approximate hex values
  - generate new shades
  - adjust opacity arbitrarily

❌ Fail if:
- Any color is not from the system

---

## 4. Components
- ONLY use existing components from the system (see `preview/` cards and `docs/components.md`)
- Engineering: prefer `komponentsV2/` over native HTML or legacy `komponents/`
- Do NOT invent new components unless explicitly allowed

If missing:
- Compose from existing primitives
- Do NOT create net-new patterns

---

## 5. Typography (Zero-Tolerance — see `typography-lock.md`)
Typography is a **governed system, not a creative area.** Full rules, token tables, forbidden behaviors, and a validation checklist live in `docs/typography-lock.md`. That document has the same enforcement weight as §7 of this file.

Summary of non-negotiables:
- ONLY use `--text-*` and `--leading-*` tokens — no hardcoded sizes or weights
- ONLY use **Inter** — no mixing serif/sans, no substitutions
- Heading hierarchy must be semantically correct: H1 > H2 > H3 > H4
- H1 appears **once per page** (page title only)
- Do NOT invent intermediate heading levels, new font sizes, or new font weights
- Do NOT use typography decoratively or to approximate hierarchy visually
- When uncertain: reuse the closest existing token; do not improvise

❌ Fail if:
- Any font size or weight is not from the approved scale
- Heading levels are skipped or used for aesthetics
- A new typographic treatment is introduced without a token
- `--fs-*` legacy tokens are used in new product UI

→ **Full enforcement rules, complete token tables, component notes, and validation checklist: `docs/typography-lock.md`**

## 5c. Layout (Zero-Tolerance — see `layout-lock.md`)
Layout is a **governed system**. Full rules live in `docs/layout-lock.md`. Same enforcement weight as §7.

Summary of non-negotiables:
- Every page uses: **left sidebar nav · main content column · optional right panel**
- No floating or overlapping panels
- No marketing-style layouts, hero spacing, or oversized whitespace
- No decorative gradients or visual effects
- No unique layouts invented per page — reuse the fixed structure
- `typography-lock.md` always overrides aesthetic layout decisions
- Backgrounds: app `#F7F8FA`, surfaces/cards `#FFFFFF`, subtle gray borders only

❌ Fail if:
- A page invents its own layout structure
- Marketing-style or hero spacing is used
- `typography-lock.md` rules are overridden for visual reasons
- Gradients, shadows, or decorative effects are added outside the token system

→ **Full rules: `docs/layout-lock.md`**

## 5b. Spacing
- Must follow defined scale (no arbitrary values) — see `preview/spacing-scale.html`
- No "close enough" sizing

---

## 6. Asset Handling Rule
- All provided assets (SVG, icons, logos) must be:
  → referenced, not interpreted

Meaning:
- Use exact files (e.g., `<img src="logo.svg">`)
- Do NOT rewrite SVG code
- Do NOT simplify or redraw assets

---

## 7. Zero-Tolerance Policy

A design FAILS immediately if:
- Fonts are incorrect
- Logo is modified or regenerated
- Colors are off-token
- Components are invented

---

## 8. Enforcement

Before returning ANY output:
- Validate against this file
- If any violation exists → fix before output
- Do NOT return partially compliant designs
