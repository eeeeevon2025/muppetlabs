# Design Audit vs. UX Audit — Quick Guide

How to choose between the two audit skills, when to use each, and what they produce.

## TL;DR
- **`design-audit.md`** → *"Is this screen good enough to ship?"* — a fast, scored quality gate on what's **already designed**.
- **`ux-audit.md`** → *"Is this whole experience complete and resilient?"* — a deep architectural review that finds what's **missing or broken** across flows.

---

## 🟦 design-audit.md

**What it does**
Runs a **15-point quality checklist** against your design and returns a hard **PASS / FAIL** verdict. Each criterion is marked ✅ Pass / ❌ Fail / ⚠️ Risk — and *any single ❌ means the whole thing FAILS.* It evaluates clarity, hierarchy, consistency, states, accessibility, UX writing, performance perception, and more (plus AI-specific checks when relevant).

**When to use it**
- A screen or prototype is "done" and you want a **ship/no-ship gate**
- Final QA before handoff or release
- Quick, objective sanity check on a single design or small set of screens
- You want a **score and a verdict**, not a redesign

**How to use it — say:**
> *"Run the design-audit skill on these screenshots."*

**What you get back**
A pass/fail scorecard with specific evidence for every ❌ and ⚠️.

**Time/depth:** Fast, focused, evaluative.

---

## 🟪 ux-audit.md

**What it does**
Performs a **comprehensive UX architecture audit**. It reverse-engineers your product logic, **maps every flow**, and hunts for what's undefined: missing screens, transitions, error/empty/loading states, dead ends, confusing paths, and recovery gaps. It assumes *"this ships to millions of users — every undefined behavior matters."* Output includes a flow inventory, a missing-UX-requirements list, an error/empty-state matrix, accessibility + resilience findings, and a **Critical/High/Medium/Low priority matrix.**

**When to use it**
- Early-to-mid design, when the **flow isn't fully built yet**
- You suspect there are **holes** — unhandled errors, missing states, edge cases
- Reviewing a PRD, a multi-screen flow, or a complex interaction system
- You want a **roadmap of what to fix**, not just a grade

**How to use it — say:**
> *"Run the ux-audit skill on this flow / PRD / prototype."*

**What you get back**
An executive summary, full flow inventory, missing-requirements list, error/empty-state matrix, and a prioritized fix list.

**Time/depth:** Deep, exploratory, generative.

---

## 🧭 How to choose

| Situation | Use |
|---|---|
| "Tell me if this is good enough to ship." | **Design Audit** |
| "Find everything we forgot to design." | **UX Audit** |
| Single screen, final polish | **Design Audit** |
| Multi-screen flow, PRD, or complex system | **UX Audit** |
| I want a **score / verdict** | **Design Audit** |
| I want a **map + priority list** | **UX Audit** |
| Early in the process | **UX Audit** |
| Right before handoff | **Design Audit** |

**Best practice — run both in sequence:**
1. **UX Audit first** → find and fill the gaps (flows, states, edge cases).
2. **Design Audit last** → confirm the finished screens pass the quality gate.
