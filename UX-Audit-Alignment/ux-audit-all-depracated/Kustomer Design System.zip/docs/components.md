# Kustomer Component System

## Overview

The Kustomer web application uses a multi-layered component system to maintain consistency and reusability across the application. This document outlines the different component systems and their usage.

## Component Systems

### 1. Komponents (Legacy)

Location: `src/komponents/`

- Original component system
- Contains basic UI components
- Being phased out in favor of newer systems

### 2. KomponentsV2

Location: `src/komponentsV2/`

- Second generation component system
- Improved TypeScript support
- Better prop typing and documentation
- Core UI components used throughout the application

### 3. KomponentsSmartV2

Location: `src/komponentsSmartV2/`

- Smart components with business logic
- Built on top of KomponentsV2
- Handles complex business rules and data transformations
- Often includes Redux integration

## Component Categories

### Form Components

- Input fields
- Select dropdowns
- Date pickers
- File uploaders
- Form validation

### Layout Components

- Grids
- Cards
- Modals
- Tabs
- Navigation elements

### Data Display Components

- Tables
- Lists
- Charts
- Status indicators
- Avatars

### Interactive Components

- Buttons
- Dropdowns
- Popovers
- Tooltips
- Drag and drop elements

## Best Practices

1. **Component Organization**

   - Keep components in their respective system directories
   - Use consistent file naming: `ComponentName.tsx`
   - Include tests in `__tests__` subdirectory
   - Include styles in `componentName.scss`

2. **Component Structure**

   ```typescript
   import * as React from 'react';
   import styles from './componentName.scss';
   import { ComponentNameProps } from './types';

   const ComponentName: React.FC<ComponentNameProps> = ({ prop1, prop2 }) => {
     // Component logic
     return (
       <div className={styles.container}>
         {/* Component JSX */}
       </div>
     );
   };

   export default ComponentName;
   ```

3. **TypeScript Guidelines**

   - Use interfaces for component props
   - Make props optional with `?` when appropriate
   - Use `React.FC` type for functional components
   - Leverage TypeScript's built-in types when possible
   - Avoid using PropTypes in new components
   - Use type inference where it improves readability
   - Export prop interfaces when they might be reused

4. **Styling Guidelines**

   - Use SCSS modules for component-specific styles
   - Use simple, semantic class names (CSS Modules handles namespacing automatically)
   - All styles are automatically scoped to their component
   - Use variables from global style system

5. **Testing Requirements**
   - Unit tests for all components
   - Snapshot tests for UI components
   - Integration tests for complex components
   - Test coverage requirements: 80% minimum

## Common Patterns

### Higher-Order Components (HOCs)

```typescript
const withFeature = (Component) => {
  return class extends React.Component {
    // HOC logic
    render() {
      return <Component {...this.props} />;
    }
  };
};
```

## Resources

- [Component Library](internal-link-to-component-library)
- [Design System](internal-link-to-design-system)
- [Component Testing Guide](internal-link-to-testing-guide)
