LAYOUT SYSTEM

Use a clean enterprise SaaS layout with fixed structural consistency across all pages.

IMPORTANT

\- Always follow the rules defined in \`typography-lock.md\`

\- Typography rules in \`typography-lock.md\` override aesthetic decisions

\- Do not invent typography styles outside the approved token system

\- Reuse existing typography roles and spacing rules exactly as defined

PAGE STRUCTURE

\- Left sidebar navigation

\- Main content column

\- Optional right utility/insights panel

\- Content should feel dense but organized

\- Preserve strong alignment and spacing rhythm

COLUMN LAYOUT

\- Left sidebar: fixed width, light background

\- Main content: flexible width, primary workspace

\- Right panel: secondary contextual information

\- Use subtle borders/dividers between columns

\- Avoid floating or overlapping panels

BACKGROUND COLORS

\- App background: #F7F8FA

\- Primary surfaces/cards: #FFFFFF

\- Sidebar background: slightly darker neutral than main background

\- Borders/dividers: very subtle gray

\- Avoid pure black backgrounds

\- Avoid gradients unless explicitly defined

TYPOGRAPHY RULES

All typography must strictly follow \`typography-lock.md\`.

Use ONLY approved typography tokens.

H1

\- Reserved for page titles only

H2

\- Section headers

H3

\- Card titles and grouped content headings

Body

\- Default paragraph and description text

Caption

\- Metadata, timestamps, helper text, labels

Typography Constraints

\- Maintain strict hierarchy

\- Do not invent custom font sizes

\- Do not randomly mix weights

\- Do not create new heading patterns

\- Do not visually approximate hierarchy

\- Consistency is more important than novelty

VISUAL STYLE

\- Minimal enterprise SaaS aesthetic

\- Subtle rounded corners

\- Low-contrast borders

\- Readability-first UI

\- Dense but highly scannable layout

SPACING

\- Use consistent spacing scale

\- Maintain vertical rhythm

\- Align all components to a grid

\- Avoid oversized whitespace or hero spacing

COMPONENT BEHAVIOR

\- Cards should use subtle borders or elevation

\- Tags and badges remain compact

\- Tables prioritize readability

\- Right panels feel secondary to the primary workflow

DO NOT

\- Create marketing-style layouts

\- Use oversized typography

\- Use decorative visual effects

\- Invent unique layouts per page

\- Add unnecessary gradients/shadows

\- Override typography-lock.md for aesthetic reasons