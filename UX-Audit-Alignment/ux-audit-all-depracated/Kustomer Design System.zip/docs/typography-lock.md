# Typography Lock Document

## Purpose
This document defines the only approved typography system for Kustomer UI work. Typography is a governed system, not a creative area. Use the exact tokens below and do not invent new hierarchy, sizes, weights, or spacing patterns.

## Core principles
- Use **Inter** only.
- Keep typography **token-driven** and **semantic**.
- Prefer **consistency over visual novelty**.
- Do not visually approximate hierarchy.
- Do not create one-off typography styles for a single screen or component.
- When uncertain, reuse an existing token instead of inventing a new one.

## Typography behavior rules
- Headings must follow semantic hierarchy: H1 > H2 > H3 > H4.
- Use **H1 only for page titles** and only once per page.
- Use **H2 for card and section headers**.
- Use **H3 for group and layer headers**.
- Use **H4 for labels that precede forms and controls**.
- Use **Label** for form labels only.
- Use **Body** for all body copy and descriptions.
- Use **Value** for tags and supplemental data.
- Use **Accent** for timestamps and metadata.
- Use **Data Value** for KPI numbers in reporting.
- Use **Data Value Unit** for KPI unit labels in reporting.

## Forbidden behaviors
Do not:
- invent intermediate heading levels
- use font sizes not listed in this document
- use font weights not listed in this document
- change hierarchy based on aesthetics alone
- use typography to add decoration
- mix serif and sans-serif fonts
- center-align long-form body content unless a component explicitly requires it
- use ALL CAPS headings unless explicitly defined elsewhere
- treat visual size as a substitute for semantic role
- create custom spacing for a single component when an existing token can be used

## Approved font scale
**Base system:** 13px at the S breakpoint.
**Scale model:** Hybrid system using Minor Third (1.2x) for headings and Major Second (1.125x) for body and below.

### Font size tokens
| Token | REM | XXXS (10px) | XXS (11px) | XS (12px) | S (13px) | M (14px) | L (15px) | Change vs Production | Weight | Use case |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|
| H1 | 1.692 | 16.92 | 18.61 | 20.30 | 22.00 | 23.69 | 25.38 | +2px | 700 Bold | Page title — one per page |
| H2 | 1.408 | 14.08 | 15.49 | 16.90 | 18.30 | 19.71 | 21.12 | +0.3px | 700 Bold | Card / section header |
| H3 | 1.177 | 11.77 | 12.95 | 14.12 | 15.30 | 16.48 | 17.65 | -0.7px | 700 Bold | Group / layer header |
| H4 | 1.077 | 10.77 | 11.85 | 12.92 | 14.00 | 15.08 | 16.15 | — | 700 Bold | Precedes forms and controls |
| Label | 1.000 | 10.00 | 11.00 | 12.00 | 13.00 | 14.00 | 15.00 | -1px | 600 Semibold | Form labels — input labels |
| Body | 1.000 | 10.00 | 11.00 | 12.00 | 13.00 | 14.00 | 15.00 | — | 400 Regular | All body copy and descriptions |
| Value | 0.889 | 8.89 | 9.78 | 10.67 | 11.56 | 12.44 | 13.33 | -1.44px | 600 Semibold | Tags and supplemental data |
| Accent | 0.790 | 7.90 | 8.69 | 9.48 | 10.27 | 11.06 | 11.85 | -1.73px | 400 Regular | Timestamps and metadata |
| Data Value | 2.615 | 26.15 | 28.77 | 31.38 | 34.00 | 36.62 | 39.23 | — | 700 Bold | KPI metric number in reporting |
| Data Value Unit | 1.615 | 16.15 | 17.77 | 19.38 | 21.00 | 22.62 | 24.23 | — | 700 Bold | KPI unit label in reporting |

## Line height tokens
Use the following line-height multipliers with the corresponding text tokens.

| Token | Multiplier | XXXS (10px) | XXS (11px) | XS (12px) | S (13px) | M (14px) | L (15px) |
|---|---:|---:|---:|---:|---:|---:|---:|
| H1 | 1.64 | 27.75 | 30.52 | 33.30 | 36.08 | 38.85 | 41.63 |
| H2 | 1.22 | 17.18 | 18.90 | 20.62 | 22.33 | 24.05 | 25.77 |
| H3 | 1.25 | 14.71 | 16.19 | 17.65 | 19.13 | 20.60 | 22.06 |
| H4 | 1.43 | 15.40 | 16.95 | 18.48 | 20.02 | 21.56 | 23.10 |
| Label | 1.43 | 14.30 | 15.73 | 17.16 | 18.59 | 20.02 | 21.45 |
| Body | 1.43 | 14.30 | 15.73 | 17.16 | 18.59 | 20.02 | 21.45 |
| Value | 1.38 | 12.27 | 13.50 | 14.72 | 15.95 | 17.17 | 18.40 |
| Accent | 1.33 | 10.51 | 11.56 | 12.61 | 13.66 | 14.71 | 15.76 |
| Data Value | 1.24 | 32.43 | 35.67 | 38.91 | 42.16 | 45.41 | 48.64 |
| Data Value Unit | 1.24 | 20.03 | 22.03 | 24.03 | 26.04 | 28.05 | 30.04 |

## CSS tokens
Use these tokens in `fonts.css` inside the `@theme` block.

```css
--text-h1: 1.692rem;
--text-h2: 1.408rem;
--text-h3: 1.177rem;
--text-h4: 1.077rem;
--text-label: 1.000rem;
--text-body: 1.000rem;
--text-value: 0.889rem;
--text-accent: 0.790rem;
--text-data-unit: 1.615rem;
--text-data: 2.615rem;

--leading-h1: 1.64;
--leading-h2: 1.22;
--leading-h3: 1.25;
--leading-h4: 1.43;
--leading-label: 1.43;
--leading-body: 1.43;
--leading-value: 1.38;
--leading-accent: 1.33;
--leading-data: 1.24;
--leading-data-unit: 1.24;
```

## Component notes
### Customer panel field labels
- Use `font-medium` (500)
- Use `text-secondary`

### Customer panel filled values
- Use `font-semibold` (600)
- Use `text-primary`
- No additional change needed unless the component spec says otherwise

### Customer panel empty placeholders
- Use `font-normal` (400)
- Use `text-tertiary`
- Use italic style

### Customer panel empty text fields
- Show a plus icon before the placeholder text

### Customer panel empty date fields
- Show a calendar-plus icon before the placeholder text

## Implementation rules
- Do not change the `html` font-size system.
- Continue using the existing `--font-size-base` and `--font-scale` system.
- Reuse the approved tokens above instead of introducing alternate sizing scales.

## Decision priority
When there is conflict, apply this order:
1. Semantic correctness
2. Token consistency
3. Readability
4. Visual aesthetics

Aesthetic improvement must never override semantic hierarchy.

## Validation checklist
Before finalizing UI, verify:
- Only approved typography tokens are used
- Heading hierarchy is semantically correct
- No new font sizes were introduced
- No new font weights were introduced
- Body text remains body text, not a heading surrogate
- Metadata stays in Accent
- Tags and supplemental data stay in Value
- KPI numbers and units use the reporting tokens
- The html base font sizing system remains unchanged

## Recommended default mapping
- H1: page title
- H2: section header
- H3: subsection or group header
- H4: form/control lead-in
- Label: form label
- Body: paragraph, description, helper copy
- Value: chips, tags, supplemental values
- Accent: timestamps, metadata, low-emphasis details
- Data Value: KPI number
- Data Value Unit: KPI unit label

## Final instruction
If a new use case does not fit these rules cleanly, do not improvise a new typographic treatment. Reuse the closest approved token or escalate the need for a new token.
