# Preview, Testing & Eval Mode Copy

> **Purpose:** Prevent preview states from accidentally sounding authoritative or autonomous.

Preview, eval mode, and shadow modes exist to **build trust without action**.

---

## Preview copy must:
- Clearly state that no action was taken
- Use conditional language ("would have", "based on")
- Encourage review, not approval

## Preview copy must never:
- Sound confident or final
- Imply correctness
- Imply the system "knows best"
- Use execution verbs ("sent", "resolved", "closed")

---

## Good Preview Language
- "The agent would have replied with…"
- "Based on recent conversations, the agent suggests…"
- "This example shows how the agent interprets context."

## Bad Preview Language (Blocking)
- "The agent handled this correctly"
- "The agent resolved the issue"
- "The best response is…"

---

## Preview Rule

> If preview copy could reasonably be mistaken for live execution, **it is blocking**.
