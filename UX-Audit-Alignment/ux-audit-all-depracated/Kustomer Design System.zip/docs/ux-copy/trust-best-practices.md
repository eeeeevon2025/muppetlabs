# Trust-Building UX Checklist

> Use this checklist when reviewing or generating UX copy and interactions. Treat failures in **High-Risk items** as blocking.

---

## A. General UX Trust Checklist (All Products)

### 1. Predictability
- [ ] Same action produces the same result every time
- [ ] Terminology and verbs are consistent across the flow
- [ ] No surprise state changes or hidden side effects

### 2. Consequence Clarity (Before Action)
- [ ] Copy names what will change, who it affects, and when
- [ ] CTAs describe outcomes (not generic verbs)
- [ ] Confirmation strength matches impact

### 3. Decision Legibility
- [ ] Users can predict the outcome before clicking
- [ ] Defaults are intentional and safe
- [ ] Optional vs required choices are explicit

### 4. Error Handling & Recovery
- [ ] Errors explain what happened in plain language
- [ ] Next steps are clear and actionable
- [ ] No generic or blame-shifting messages

### 5. Information Load
- [ ] High-risk actions are explained clearly
- [ ] Low-risk actions are not over-explained
- [ ] Progressive disclosure is used appropriately

### 6. Behavioral Accuracy
- [ ] Copy aligns with actual system behavior
- [ ] No overpromising or marketing language in operational UI
- [ ] Labels, buttons, and confirmations are truthful

### 7. Transparency Where It Matters
- [ ] Rationale is shown for important decisions
- [ ] Rules or criteria are surfaced when relevant
- [ ] Optional depth is available via "Learn more"

---

## B. AI-Specific Trust Checklist

### 1. Agency Clarity (Critical)
- [ ] Clear distinction between *suggests* vs *acts*
- [ ] Execution is never implied when the system only recommends
- [ ] User approval steps are explicit

### 2. Scope & Limits
- [ ] What the AI can do is explicit
- [ ] What the AI cannot do is stated or implied clearly
- [ ] Triggers, timing, and frequency are named

### 3. Language Discipline
- [ ] No anthropomorphic language (intent, emotion, judgment)
- [ ] Capability-based framing ("The agent can…")
- [ ] Calm, professional, system-level tone

### 4. Rationale & Inputs
- [ ] High-level explanation of why the AI acted or recommended
- [ ] Inputs or signals are named in plain language
- [ ] No black-box or "AI knows best" phrasing

### 5. Uncertainty & Failure States
- [ ] Uncertainty is acknowledged where appropriate
- [ ] Failure, pause, or timeout behavior is explained
- [ ] Users know what to do if the AI fails

### 6. Human Control & Reversibility
- [ ] Users can review before execution
- [ ] Clear controls to pause, edit, disable, or override
- [ ] Undo or rollback is available or its absence is explicit

### 7. Risk-Matched Safeguards
- [ ] Higher risk → more precise language
- [ ] Consequences are named explicitly for high-impact actions
- [ ] Confirmations scale with severity

---

## C. Blocking Conditions (Fail = Do Not Ship)

- [ ] AI behavior is unclear from copy alone
- [ ] Automation scope or consequences are ambiguous
- [ ] Users could mistake a recommendation for execution
- [ ] Safety depends on long explanations or warnings

---

## Anchor Test

> **If a reasonable user misunderstands this, who gets hurt — and would they realize it before acting?**

If unclear, trust requirements are not met.
