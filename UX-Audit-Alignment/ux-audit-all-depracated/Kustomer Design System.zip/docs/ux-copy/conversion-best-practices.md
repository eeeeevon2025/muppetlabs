# UX Best Practices for Conversion

> Getting users to complete a primary action.

---

## 1. Make the primary action unmistakable
- One clear primary CTA per screen
- Visually dominant and consistently placed
- Outcome-based labels ("Create rule," "Start trial," "Save changes")

## 2. Reduce decision load at the moment of action
- Remove secondary options near the primary CTA
- Delay advanced settings behind "Advanced" or "Optional"
- Defaults should be safe, sensible, and reversible

## 3. Front-load value before asking for commitment
- Explain what happens next before the click
- Answer "Why should I do this now?" in one sentence
- Show immediate benefit, not future promises

## 4. Eliminate ambiguity about consequences
- Users must predict the outcome before acting
- Name scope, impact, and reversibility explicitly
- Avoid vague verbs ("Submit," "Proceed," "Continue")

## 5. Minimize form friction
- Ask only for information required right now
- Avoid optional fields unless clearly labeled
- Inline validation beats post-submit errors

## 6. Match confirmation strength to risk
- Low risk → instant action
- Medium risk → lightweight review or confirmation
- High risk → explicit consequence naming + strong confirmation

## 7. Remove anxiety at the point of no return
- Reassure with facts ("You can edit this later")
- Show escape hatches ("Cancel," "Back," "Undo")
- Never rely on fine print for critical details
