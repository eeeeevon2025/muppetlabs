# Decision vs Information Copy

Not all UX copy carries the same risk. Determine whether the copy is **informational** or **decision-making**.

---

## Information Copy

**Definition:** Copy that explains, previews, or describes without causing irreversible change.

**Characteristics:**
- No immediate system change
- No customer-visible impact
- No automation triggered
- Fully reversible or read-only

**Language expectations:**
- Calm, explanatory
- Uses conditional or preview framing
- Must not imply authority or execution

**Examples:**
- "The agent would have replied with…"
- "Based on recent conversations, the agent suggests…"
- "You can review how this works before enabling it."

---

## Decision Copy

**Definition:** Copy that asks the user to approve, enable, or trigger a change with real impact.

**Characteristics:**
- Irreversible or partially reversible outcomes
- Automation, permissions, customer-visible actions
- User becomes accountable for the outcome

**Language requirements (non-negotiable):**
- Must name what will happen
- Must name scope and impact
- Must state reversibility or lack of it
- Must slow the user down proportionally to risk

**Examples:**
- "Enable AI replies for customer emails"
- "This will send responses to customers automatically"
- "You can pause or disable this at any time"

---

## Blocking Rule

> If decision copy does not clearly name **consequences, scope, and responsibility**, it is blocking and must be rewritten or escalated as a product issue.
