# UX Best Practices for Engagement

> Keeping users active, confident, and returning.

---

## 1. Make progress visible
- Show users what they've completed and what's left
- Use milestones, not percentages, for complex workflows
- Completion states should feel conclusive, not ambiguous

## 2. Reinforce competence, not delight
- Confirm success with clear outcomes ("Rule is active")
- Avoid celebratory language in professional tools
- Confidence comes from predictability, not personality

## 3. Reduce cognitive effort over time
- Remember user preferences and past choices
- Surface relevant next steps automatically
- Don't make users re-learn patterns across sessions

## 4. Teach through doing, not explaining
- Inline guidance beats onboarding modals
- Show examples only when the user is stuck
- Progressive disclosure > upfront education

## 5. Keep system behavior predictable
- Same action → same result every time
- Stable terminology across the product
- No surprise automation or background actions

## 6. Handle failure states with clarity and momentum
Always explain:
- What happened
- Why (if useful)
- What to do next

Errors should guide recovery, not halt progress.

## 7. Respect the user's time
- Fast perceived performance matters as much as real speed
- Loading states should explain what's happening
- Avoid unnecessary confirmations or interruptions
