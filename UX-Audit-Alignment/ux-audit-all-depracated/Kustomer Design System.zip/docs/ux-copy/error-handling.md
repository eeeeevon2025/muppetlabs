# UX Error Handling Contract — SaaS & Agentic Systems

> **Non-negotiable rules** for writing, reviewing, and validating error copy in SaaS systems, especially those involving automation, AI, permissions, or high-stakes workflows.

## Purpose

The goal of error copy is to:
- Preserve trust
- Protect correct mental models
- Make system behavior explicit
- Enable safe recovery when possible

**Clarity and honesty always override brevity or reassurance.**

---

## Error Taxonomy (Required)

Every error must belong to exactly one category.

### 1. Validation Errors (User-Correctable)

**Definition:** Input is invalid, incomplete, or malformed. System state is healthy.

**Examples:**
- Missing required field
- Invalid format
- Value out of range

**Rules:**
- Display inline at the point of failure
- Do not block unrelated actions
- Do not imply system failure
- No retry language

**Copy must:**
- State what's wrong
- State how to fix it

**Pattern:** "Enter a valid email address." / "Password must be at least 12 characters."

---

### 2. Constraint Errors (Blocked by System Rules)

**Definition:** User intent is valid. System rules prevent execution.

**Examples:**
- Permission denied
- Plan limits exceeded
- Feature disabled
- Resource locked

**Rules:**
- Shown at the moment of action
- Must name the blocking rule
- Must clarify whether the user can resolve it

**Copy must:**
- Name the constraint explicitly
- State next steps or escalation path

**Pattern:** "You don't have permission to edit automations." / "Your plan allows up to 5 workflows."

---

### 3. System Errors (User Cannot Fix)

**Definition:** Backend, infrastructure, or dependency failure. No corrective action available to the user.

**Examples:**
- API timeout
- Job execution failure
- Service unavailable

**Rules:**
- Never imply user fault
- Must confirm whether the action ran or not
- Must protect trust in system state

**Copy must:**
- Acknowledge the failure
- State system outcome clearly
- Offer recovery path if one exists

**Pattern:** "We couldn't save your changes due to a system issue. No updates were applied."

---

### 4. Partial Failures (High Risk, Often Mishandled)

**Definition:** Some operations succeeded, others failed.

**Examples:**
- Bulk actions
- Imports
- Automation runs

**Rules:**
- Never collapse into a single generic error
- Must quantify impact
- Must expose scope clearly

**Copy must:**
- Separate success from failure
- State what completed and what did not
- Provide follow-up actions

**Pattern:** "17 records were updated. 3 failed due to missing permissions."

---

## Error Severity Levels

| Severity | Meaning | Treatment |
|---|---|---|
| **Blocking** | Task cannot continue | Disable action, inline guidance |
| **Recoverable** | User can fix or retry | Inline + next step |
| **Informational** | No action required | Passive notice |
| **Critical** | Data or trust risk | Prominent, explicit |

**Rule:** If severity is ambiguous, treat as higher severity.

---

## Decision vs. Information Rule

### Information Errors
- Describe system state
- Do not imply execution
- Do not require confirmation

### Decision Errors
- Occur during irreversible or high-impact actions
- Must explicitly state:
  - Consequences
  - Scope
  - Responsibility

**Hard Rule:** Any error during a decision must answer: *Did anything already happen?* If this is unclear, the error copy is incomplete.

---

## Placement Rules

### Inline (Preferred)
- Validation errors
- Single-step actions

### Section-Level
- Multi-field conflicts
- Rule violations

### Global / Banner
- System outages
- Account-level issues

### Modal (Last Resort)
Only when:
- Action is destructive
- Context cannot be preserved
- User must make a decision

---

## Copy Requirements (Strict)

Every error message **must include**:
1. What failed
2. Why (if known)
3. What happened or did not happen
4. What the user can do next

Every error message **must not**:
- Say "Something went wrong"
- Use blame language
- Mask system behavior
- Use passive voice without clarity

---

## Retry & Recovery Rules

### Retry Allowed Only If
- Action is idempotent
- No partial execution occurred
- Scope is unchanged

**Required copy:** "Retry will attempt the same action again."

### Retry Forbidden When
- Partial success occurred
- Side effects may exist
- User intent may need revision

In these cases:
- Offer review, rollback, or support paths
- Do not offer retry

---

## Automation & AI Error Rules (High Risk)

Automation or AI-related errors must state:
- Whether execution occurred
- Which step failed
- Whether retries are automatic or manual
- Whether future runs are affected

**Unacceptable:** "Automation failed."

**Required:** "The automation stopped at step 3 due to a permission error. No further actions were taken."

### AI Language Constraints
- Do not anthropomorphize
- Do not imply intent or understanding
- Describe observable system behavior only

---

## Reference IDs (System Errors)

For system or critical errors:
- Include a neutral reference ID
- Do not expose stack traces
- Do not require users to interpret it

**Pattern:** "Reference ID: 8F2A9"

---

## Product Escalation Rule

Escalate instead of writing copy when:
- The error occurs frequently
- The user cannot predict it
- The system created the risk
- Copy requires repeated warnings or legal framing

**Rule:** If error copy starts sounding like a disclaimer, the UX is broken.

---

## Acceptance Checklist

An error is acceptable only if:
- [ ] Error category is clear
- [ ] Severity is appropriate
- [ ] Ownership is explicit
- [ ] Scope is stated
- [ ] Outcome is unambiguous
- [ ] Recovery path is honest
- [ ] System behavior is not masked
