# UX Copywriting Training Guide

> **Source of truth for UX copy.** Consolidates and deduplicates best practices for microcopy, error messages, and functional UX writing.

The goal of UX copy is simple: help users understand **what to do, what will happen, and how to recover** — as quickly and safely as possible.

---

## 1. Core Principles (Non-Negotiable)

### Clarity
- Users must understand the meaning on first scan
- Use simple, familiar language
- Avoid jargon unless the audience clearly expects it

### Brevity
- Every word must earn its place
- Remove filler, redundancy, and over-explanation
- Short sentences > long sentences

### Usefulness
- Copy must help the user take action or make a decision
- Descriptive text without guidance is a failure

### Action Orientation
- Use specific verbs that describe the outcome
- Prefer "Create account," "Save changes," "Send reply" over vague labels like "Submit" or "Continue"

### Consistency
- Use the same terms for the same concepts everywhere
- Avoid synonyms for identical actions
- Stable language creates predictable mental models

### Empathy & Tone
- Tone must match context:
  - Normal tasks → direct, neutral
  - Errors or loss of work → calm, empathetic
- Never use humor or playfulness in high-risk moments

---

## 2. How Users Read

Users scan before they read. Copy must be:
- **Scannable**
- **Chunked**
- **Front-loaded** with the most important information

Flag copy that:
- Appears in dense paragraphs
- Hides key information mid-sentence
- Requires careful reading to proceed

---

## 3. Where Microcopy Appears

Microcopy includes (but is not limited to):
- Button labels
- Form labels, placeholders, and helper text
- Error messages and validation feedback
- Confirmation and success messages
- Tooltips and contextual instructions
- Progress and loading indicators

Treat all of these as **functional product behavior, not decoration**.

---

## 4. Good vs. Bad Microcopy

### Good Microcopy
- Helps users complete tasks easily
- Uses plain, concrete language
- Anticipates likely questions or concerns
- Reduces anxiety and uncertainty
- Makes next steps obvious

### Bad Microcopy
- Uses jargon, passive voice, or internal terms
- Leaves users unsure what happens next
- Feels generic or evasive
- Softens or hides risk
- Requires interpretation

---

## 5. Error Message Best Practices

Errors are part of the user journey and must be handled deliberately.

Every error message must answer:
1. **What happened** (in plain language)
2. **Why it happened** (if helpful and safe to explain)
3. **What to do next**

### Rules
- Never use generic messages like "Something went wrong"
- Avoid technical error codes unless the user can act on them
- Balance transparency with constraints (e.g., security)

### Tone by Severity
- Low friction → neutral
- High friction or loss of work → empathetic and reassuring

---

## 6. Structure & Decision Support

**Headings, labels, buttons, and links are promises.** Users should be able to predict the outcome of an action before clicking.

Flag copy that:
- Uses generic CTAs
- Describes without guiding
- Forces users to guess consequences

---

## 7. Progressive Disclosure

- Do not show all information upfront
- Introduce explanations only when they become relevant
- Use "Learn more" or secondary links sparingly and descriptively
- Over-explaining early increases doubt and cognitive load

---

## 8. Language Mechanics

Apply consistently:
- Use **active voice**
- Write in **present tense**
- Avoid double negatives
- Use numerals where faster to scan ("2 notifications")
- Match language to platform (tap vs click)
- Prefer relative time ("today," "yesterday") when helpful

---

## 9. Strict Evaluation Rules

When evaluating or generating UX copy:
- Treat clarity, plain language, and scannability violations as **high-impact issues**
- Always provide rewrite-ready recommendations for problems found
- Call out when copy is compensating for unclear product behavior

> If copy must work this hard to explain something, the interaction itself may be the issue.

---

## 10. Core Definition (Anchor Rule)

> **UX writing exists to help users understand what to do and how to do it in as little time as possible — without confusion, risk, or surprise.**
>
> If the copy does not clearly support that goal, it fails.
