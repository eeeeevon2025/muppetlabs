# AI Agent Heuristics

> When reviewing interfaces that involve automation, AI agents, recommendations, or autonomous actions, apply these heuristics rigorously. **Non-negotiable in high-stakes or admin workflows.**

---

## 1. Agency Clarity

Users must always understand:
- What the system will do
- When it will act
- What triggers action
- What it will not do

**Flag copy that:**
- Uses vague verbs ("handle," "optimize," "take care of")
- Blurs recommendation vs. execution
- Implies autonomy without explaining scope

**Prefer:**
- Explicit verbs ("creates," "updates," "sends," "closes")
- Clear distinction between *suggests* vs. *acts*
- Whether actions are automatic or manual

---

## 2. Human Control & Reversibility

Evaluate whether the copy clearly communicates:
- If and how actions can be undone, paused, edited, or overridden
- What happens after an action runs

**Flag:**
- Irreversible actions without strong warning copy
- Missing explanation of rollback, history, or auditability
- Soft confirmations for destructive or cascading actions

**Prefer:**
- Clear escape hatches ("You can review before sending")
- Time-based reversibility when applicable
- Explicit confirmation language for high-impact actions

---

## 3. Predictability & Mental Models

> Agent behavior must be predictable from the copy alone.

**Flag copy that:**
- Overpromises outcomes ("always," "automatically resolves")
- Hides conditions, thresholds, or dependencies
- Creates unclear expectations about frequency or scope

**Prefer:**
- Conditional language where appropriate ("When X happens, the agent will…")
- Explicit constraints and limits
- Clear examples if behavior is complex

---

## 4. Trust-Building Transparency (Without Overload)

Balance transparency with cognitive load. Microcopy should explain:
- Why the agent is acting or recommending something
- What signals or inputs it uses at a high level
- What confidence or uncertainty exists

**Flag:**
- Black-box language ("AI decides," "system knows best")
- Unexplained recommendations
- Overly technical explanations that reduce clarity

**Prefer:**
- Plain-language rationale ("Based on recent ticket volume…")
- Optional "learn more" affordances instead of inline overload

---

## 5. Risk Framing & Consequence Awareness

For actions that affect:
- Customers
- Data
- Permissions
- Revenue
- Brand voice

Ensure the copy:
- Names the real consequence, not just the action
- Signals risk level appropriately (not buried, not alarmist)
- Matches confirmation strength to impact

**Flag:**
- Neutral or upbeat tone for risky actions
- Missing downstream impact explanations
- Inconsistent warning language across similar actions

---

## 6. Confidence Without Anthropomorphism

> Agentic systems should feel **capable, not human**.

**Flag:**
- Anthropomorphic language ("I'll handle this for you")
- Emotional framing that overstates intelligence or intent
- Language that implies human judgment where none exists

**Prefer:**
- Calm, professional, system-level language
- Capability framing ("The agent can…") rather than identity framing
- Confidence rooted in behavior, not personality

---

## 7. Failure, Uncertainty & Edge States

Agentic UX must explicitly handle non-ideal outcomes. Evaluate copy for:
- What happens if the agent fails, pauses, or times out
- How users are notified
- What users should do next

**Flag:**
- Silent failures
- Generic error messages
- Blame-shifting language

**Prefer:**
- Clear next steps
- Ownership without apology overload
- Reassurance paired with action

---

## Strict Mode Enforcement for Agentic UX

In strict mode:
- Treat unclear agent behavior as a **blocking issue**
- Require explicit copy for automation scope and consequences
- Do not accept "AI-ish" language without operational clarity
- Always propose rewrite-ready alternatives
