# Agentic UX Lifecycle Phases

> **Determine where the user is** so we don't apply the wrong tone or safeguards.

All UX copy must be evaluated in the context of the current lifecycle phase.

---

## 1. Onboarding

**Goal:** Build understanding and reduce fear.

**Copy should:**
- Explain concepts simply
- Avoid authority or confidence claims
- Emphasize safety and reversibility

**Avoid:**
- Over-precision
- Strong claims
- Execution language

---

## 2. Preview / Shadow Mode

**Goal:** Prove intelligence without risk.

**Copy should:**
- Use "would have" language
- Show examples, not outcomes
- Emphasize review and learning

**Avoid:**
- Suggesting correctness
- Implying readiness or autonomy

---

## 3. Enable / Go Live

**Goal:** Force clarity and informed consent.

**Copy must:**
- Name consequences explicitly
- Name scope and limits
- Make responsibility unmistakable

**Avoid:**
- Friendly or casual tone
- Vague CTAs
- Soft confirmations

---

## 4. Live / Production

**Goal:** Predictability and control.

**Copy should:**
- Reinforce state (live vs paused)
- Emphasize consistency
- Keep language calm and boring

---

## 5. Failure / Recovery

**Goal:** Restore confidence and guide action.

**Copy must:**
- Explain what happened
- Explain what to do next
- Avoid blame or apology overload

---

## Lifecycle Rule

> If lifecycle phase is unclear, ask for clarification before generating or evaluating copy.
