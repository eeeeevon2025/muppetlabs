# UX Copy Risk Framework

> **Reference standard.** Defines how to identify, assess, and apply risk when evaluating or writing UX copy for SaaS products — especially admin, automation, and agentic workflows.

**Risk is not optional context.** It determines tone, precision, confirmation strength, and whether copy alone is sufficient.

---

## What "Risk" Means in UX Copy

Risk is the likelihood that misunderstanding the copy could cause harm, including:
- User frustration or lost work
- Customer-facing mistakes
- Data or permission issues
- Revenue or trust impact
- Irreversible or cascading outcomes

UX copy must scale in **explicitness and caution** as risk increases.

---

## Risk Levels

### Low Risk

**Characteristics:**
- Fully reversible
- Affects only the current user
- No automation or background execution
- No sensitive data or permissions involved

**Examples:**
- Personal preferences
- UI display settings
- Drafts or previews

**Copy expectations:**
- Minimal explanation
- Direct CTAs
- No warnings or confirmations

---

### Medium Risk

**Characteristics:**
- Partially reversible
- Affects workflows or multiple users
- User-triggered automation
- Configuration or internal data changes

**Examples:**
- Workflow settings
- Bulk actions with preview
- Automation rules requiring manual start

**Copy expectations:**
- Clear scope naming
- Explicit description of the change
- Light confirmation or review step

---

### High Risk

**Characteristics:**
- Irreversible or unclear reversibility
- Customer-visible impact
- Autonomous or scheduled execution
- Data, permissions, billing, or access changes
- Scales automatically or repeatedly
- AI agents acting on behalf of users

**Examples:**
- Auto-closing or sending to customers
- Permission changes
- Org-wide or bulk irreversible actions

**Copy expectations:**
- Explicit consequence naming
- Strong, unambiguous confirmation
- Clear reversibility (or lack of it)
- Blocking if copy cannot make the action safe

---

## Risk Signals (Used to Infer Risk)

When risk is not explicitly provided, assess it using these signals.

### 1. Reversibility
- Fully undoable → lower risk
- Partially undoable → medium risk
- Irreversible or unclear → high risk

### 2. Scope of Impact
- Single user → low
- Team or workflow → medium
- Customers, accounts, org-wide → high

### 3. Automation / Agency
- Informational or recommendation-only → low
- User-triggered automation → medium
- Autonomous, scheduled, or background execution → high

### 4. Data & Permissions
- No data change → low
- Internal config data → medium
- Customer data, permissions, billing, access → high

### 5. Frequency & Amplification
- One-time action → lower risk
- Bulk or recurring → higher risk
- Continuous or self-repeating → high risk

---

## Risk Tier Determination Rule

- If any one signal is **High**, treat the overall risk as High
- Mixed Low/Medium → Medium
- Mostly Low → Low

> Risk should always be stated explicitly when inferred.

---

## Risk-Driven Copy Adjustments

As risk increases:
- Precision increases
- Vague language decreases
- Consequences must be named
- Confirmation strength increases

> Risk should change copy behavior, not just add warnings.

---

## Agentic & AI-Specific Risk Rules

For agentic or AI-driven actions:
- Tone becomes calmer and more explicit
- Clearly distinguish *suggests* vs *acts*
- Explicitly state when the agent runs
- Name scope, limits, and triggers
- Avoid anthropomorphic language
- Never overpromise outcomes
- Always explain what happens if the agent fails

**Unclear agent behavior is always high risk.**

---

## Blocking Conditions

Treat as blocking issues if:
- High-risk actions lack explicit consequence naming
- Reversibility is unclear
- Automation scope is ambiguous
- Copy softens or hides risk
- Safety depends on long explanations

In these cases, flag a **product design issue**, not a copy issue.

---

## Anchor Risk Test

Always evaluate copy using this question:

> **"If this goes wrong, who gets hurt — and will the user understand that before acting?"**

If the answer is unclear, risk handling is insufficient.

---

## Final Principle

> Good UX copy does not eliminate risk.
> It makes risk **understandable, deliberate, and avoidable** where possible.
